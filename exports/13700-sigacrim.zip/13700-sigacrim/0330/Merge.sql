DECLARE
    v_dummy number;
    last_id number;

BEGIN

    -- Pre deflagracao

    --
    last_id := upsert_resposta_etapa(p_id_operacao => :P330_ID_OPERACAO, p_cd_campo => 'cadastro_gpol', p_st_resposta => :ITEM_CADASTRO_GPOL);
    IF (:ITEM_CADASTRO_GPOL = 1) THEN
        upsert_resposta_etapa_sis_gpol(last_id, :ITEM_CADASTRO_GPOL, :ITEM_CADASTRO_GPOL_IDGPOL);
    END IF;

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P330_ID_OPERACAO, p_cd_campo => 'pre_busca_domiciliar', p_st_resposta => :ITEM_PRE_BUSCA_DOMICILIAR, p_qt_resposta => :ITEM_PRE_BUSCA_DOMICILIAR_QTD);

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P330_ID_OPERACAO, p_cd_campo => 'pre_prisao_temporaria', p_st_resposta => :ITEM_PRE_PRISAO_TEMPORARIA, p_qt_resposta => :ITEM_PRE_PRISAO_TEMPORARIA_QTD);

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P330_ID_OPERACAO, p_cd_campo => 'pre_prisao_preventiva', p_st_resposta => :ITEM_PRE_PRISAO_PREVENTIVA, p_qt_resposta => :ITEM_PRE_PRISAO_PREVENTIVA_QTD);

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P330_ID_OPERACAO, p_cd_campo => 'pre_sequestro', p_st_resposta => :ITEM_PRE_SEQUESTRO, p_vl_resposta => to_number(replace(replace(:ITEM_PRE_SEQUESTRO_VALOR, 'R$', ''), '.', ''), '999G999G999G999G990D00'));

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P330_ID_OPERACAO, p_cd_campo => 'pre_medidas_cautelares', p_st_resposta => :ITEM_PRE_MEDIDAS_CAUTELARES);

    --
    last_id := upsert_resposta_etapa(p_id_operacao => :P330_ID_OPERACAO, p_cd_campo => 'pre_auxilio_orgao', p_st_resposta => :ITEM_PRE_AUXILIO_ORGAO);
    IF (:ITEM_PRE_AUXILIO_ORGAO = 1) THEN
        upsert_resposta_etapa_orgao_cooperacao(last_id, :ITEM_PRE_AUXILIO_ORGAO, :ITEM_PRE_AUXILIO_ORGAO_ORGAOS);
    END IF;

    --
    last_id := upsert_resposta_etapa(p_id_operacao => :P330_ID_OPERACAO, p_cd_campo => 'pre_auxilio_tatico', p_st_resposta => :ITEM_PRE_AUXILIO_TATICO);
    IF (:ITEM_PRE_AUXILIO_TATICO = 1) THEN
        upsert_resposta_etapa_grupo_tatico(last_id, :ITEM_PRE_AUXILIO_TATICO, :ITEM_PRE_AUXILIO_TATICO_GRUPOS);
    END IF;

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P330_ID_OPERACAO, p_cd_campo => 'pre_envolv_advogados', p_st_resposta => :ITEM_PRE_ENVOLV_ADVOGADOS);

    --
    last_id := upsert_resposta_etapa(p_id_operacao => :P330_ID_OPERACAO, p_cd_campo => 'pre_envolv_funcionarios', p_st_resposta => :ITEM_PRE_ENVOLV_FUNCIONARIOS);
    IF (:ITEM_PRE_ENVOLV_FUNCIONARIOS = 1) THEN
        upsert_resposta_etapa_orgao_cooperacao(last_id, :ITEM_PRE_ENVOLV_FUNCIONARIOS, :ITEM_PRE_ENVOLV_FUNCIONARIOS_ORGAOS);
    END IF;

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P330_ID_OPERACAO, p_cd_campo => 'pre_envolv_foro', p_st_resposta => :ITEM_PRE_ENVOLV_FORO);

    -- marca flag ok
    UPDATE tb_operacao SET st_pre_deflagracao_saved = 1 WHERE id_operacao = :P330_ID_OPERACAO;

EXCEPTION
    WHEN OTHERS THEN
        raise_application_error(-20002, 'Não foi possível salvar (pré-deflagração): ' || sqlerrm);

END;