declare

    general_id number;

begin



    ----
    -- Pre deflagracao
      --
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_CADASTRO_GPOL from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P330_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'cadastro_gpol';
        -- select listagg(ID_SIS_GPOL_FK, ':') into :ITEM_CADASTRO_GPOL_IDGPOL from TB_RESPOSTA_ETAPA_SIS_GPOL tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P330_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'cadastro_gpol';
        exception when no_data_found then null;
    end;

    --
    --
    begin
        select ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA into :ITEM_PRE_BUSCA_DOMICILIAR, :ITEM_PRE_BUSCA_DOMICILIAR_QTD from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P330_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'pre_busca_domiciliar';
        exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA into :ITEM_PRE_PRISAO_TEMPORARIA, :ITEM_PRE_PRISAO_TEMPORARIA_QTD from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P330_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'pre_prisao_temporaria';
        exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA into :ITEM_PRE_PRISAO_PREVENTIVA, :ITEM_PRE_PRISAO_PREVENTIVA_QTD from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P330_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'pre_prisao_preventiva';
        exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA, TO_CHAR(VL_RESPOSTA_ETAPA, '999G999G999G999G990D00') into :ITEM_PRE_SEQUESTRO, :ITEM_PRE_SEQUESTRO_VALOR from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P330_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'pre_sequestro';
        exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_PRE_MEDIDAS_CAUTELARES from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P330_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'pre_medidas_cautelares';
        exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_PRE_AUXILIO_ORGAO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P330_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'pre_auxilio_orgao';
        select listagg(ID_ORGAO_COOPERACAO_FK, ':') into :ITEM_PRE_AUXILIO_ORGAO_ORGAOS from TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P330_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'pre_auxilio_orgao';
        exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_PRE_AUXILIO_TATICO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P330_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'pre_auxilio_tatico';
        select listagg(ID_GRUPO_TATICO_FK, ':') into :ITEM_PRE_AUXILIO_TATICO_GRUPOS from TB_RESPOSTA_ETAPA_GRUPO_TATICO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P330_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'pre_auxilio_tatico';
        exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_PRE_ENVOLV_ADVOGADOS from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P330_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'pre_envolv_advogados';
        exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_PRE_ENVOLV_FUNCIONARIOS from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P330_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'pre_envolv_funcionarios';
        select listagg(ID_ORGAO_COOPERACAO_FK, ':') into :ITEM_PRE_ENVOLV_FUNCIONARIOS_ORGAOS from TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P330_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'pre_envolv_funcionarios';
        exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_PRE_ENVOLV_FORO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P330_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'pre_envolv_foro';
        exception when no_data_found then null;
    end;


exception when others then
    raise_application_error(-20303, 'Não foi possível recuperar os dados no momento (pré-deflagração). Caso o problema persista, por favor, entre em contato com o suporte.', false);
end;