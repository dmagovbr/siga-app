declare

    shuttle wwv_flow_global.vc_arr2;
    last_id number;

begin

    -- Pre deflagracao

	--
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P330_ID_OPERACAO and cd_campo_etapa_fk = 'cadastro_gpol')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_CADASTRO_GPOL when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P330_ID_OPERACAO, 'cadastro_gpol', :ITEM_CADASTRO_GPOL);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P330_ID_OPERACAO and cd_campo_etapa_fk = 'cadastro_gpol';
        delete from TB_RESPOSTA_ETAPA_SIS_GPOL where ID_RESPOSTA_ETAPA_SIS_GPOL IN (select ID_RESPOSTA_ETAPA_SIS_GPOL from TB_RESPOSTA_ETAPA_SIS_GPOL tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P330_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'cadastro_gpol');
        if (:ITEM_CADASTRO_GPOL = 1) then
            shuttle := apex_util.string_to_table(:ITEM_CADASTRO_GPOL_IDGPOL);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_SIS_GPOL (ID_RESPOSTA_ETAPA_FK, ID_SIS_GPOL_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
        exception when no_data_found then null;
    end;
    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P330_ID_OPERACAO and cd_campo_etapa_fk = 'pre_busca_domiciliar')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_PRE_BUSCA_DOMICILIAR, QT_RESPOSTA_ETAPA = :ITEM_PRE_BUSCA_DOMICILIAR_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P330_ID_OPERACAO, 'pre_busca_domiciliar', :ITEM_PRE_BUSCA_DOMICILIAR, :ITEM_PRE_BUSCA_DOMICILIAR_QTD);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P330_ID_OPERACAO and cd_campo_etapa_fk = 'pre_prisao_temporaria')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_PRE_PRISAO_TEMPORARIA, QT_RESPOSTA_ETAPA = :ITEM_PRE_PRISAO_TEMPORARIA_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P330_ID_OPERACAO, 'pre_prisao_temporaria', :ITEM_PRE_PRISAO_TEMPORARIA, :ITEM_PRE_PRISAO_TEMPORARIA_QTD);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P330_ID_OPERACAO and cd_campo_etapa_fk = 'pre_prisao_preventiva')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_PRE_PRISAO_PREVENTIVA, QT_RESPOSTA_ETAPA = :ITEM_PRE_PRISAO_PREVENTIVA_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P330_ID_OPERACAO, 'pre_prisao_preventiva', :ITEM_PRE_PRISAO_PREVENTIVA, :ITEM_PRE_PRISAO_PREVENTIVA_QTD);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P330_ID_OPERACAO and cd_campo_etapa_fk = 'pre_sequestro')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_PRE_SEQUESTRO, VL_RESPOSTA_ETAPA = CAST(REPLACE(REPLACE(:ITEM_PRE_SEQUESTRO_VALOR, 'R$', ''), '.', '') AS NUMBER(16, 2)) when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, VL_RESPOSTA_ETAPA) values (:P330_ID_OPERACAO, 'pre_sequestro', :ITEM_PRE_SEQUESTRO, CAST(REPLACE(REPLACE(:ITEM_PRE_SEQUESTRO_VALOR, 'R$', ''), '.', '') AS NUMBER(16, 2)));
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P330_ID_OPERACAO and cd_campo_etapa_fk = 'pre_medidas_cautelares')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_PRE_MEDIDAS_CAUTELARES when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P330_ID_OPERACAO, 'pre_medidas_cautelares', :ITEM_PRE_MEDIDAS_CAUTELARES);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P330_ID_OPERACAO and cd_campo_etapa_fk = 'pre_auxilio_orgao')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_PRE_AUXILIO_ORGAO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P330_ID_OPERACAO, 'pre_auxilio_orgao', :ITEM_PRE_AUXILIO_ORGAO);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P330_ID_OPERACAO and cd_campo_etapa_fk = 'pre_auxilio_orgao';
        delete from TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO where ID_RESPOSTA_ETAPA_ORGAO_COOPERACAO IN (select ID_RESPOSTA_ETAPA_ORGAO_COOPERACAO from TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P330_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'pre_auxilio_orgao');
        if (:ITEM_PRE_AUXILIO_ORGAO = 1) then
            shuttle := apex_util.string_to_table(:ITEM_PRE_AUXILIO_ORGAO_ORGAOS);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO (ID_RESPOSTA_ETAPA_FK, ID_ORGAO_COOPERACAO_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P330_ID_OPERACAO and cd_campo_etapa_fk = 'pre_auxilio_tatico')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_PRE_AUXILIO_TATICO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P330_ID_OPERACAO, 'pre_auxilio_tatico', :ITEM_PRE_AUXILIO_TATICO);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P330_ID_OPERACAO and cd_campo_etapa_fk = 'pre_auxilio_tatico';
        delete from TB_RESPOSTA_ETAPA_GRUPO_TATICO where ID_RESPOSTA_ETAPA_GRUPO_TATICO IN (select ID_RESPOSTA_ETAPA_GRUPO_TATICO from TB_RESPOSTA_ETAPA_GRUPO_TATICO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P330_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'pre_auxilio_tatico');
        if (:ITEM_PRE_AUXILIO_TATICO = 1) then
            shuttle := apex_util.string_to_table(:ITEM_PRE_AUXILIO_TATICO_GRUPOS);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_GRUPO_TATICO (ID_RESPOSTA_ETAPA_FK, ID_GRUPO_TATICO_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P330_ID_OPERACAO and cd_campo_etapa_fk = 'pre_envolv_advogados')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_PRE_ENVOLV_ADVOGADOS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P330_ID_OPERACAO, 'pre_envolv_advogados', :ITEM_PRE_ENVOLV_ADVOGADOS);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P330_ID_OPERACAO and cd_campo_etapa_fk = 'pre_envolv_funcionarios')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_PRE_ENVOLV_FUNCIONARIOS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P330_ID_OPERACAO, 'pre_envolv_funcionarios', :ITEM_PRE_ENVOLV_FUNCIONARIOS);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P330_ID_OPERACAO and cd_campo_etapa_fk = 'pre_envolv_funcionarios';
        delete from TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO where ID_RESPOSTA_ETAPA_ORGAO_COOPERACAO IN (select ID_RESPOSTA_ETAPA_ORGAO_COOPERACAO from TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P330_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'pre_envolv_funcionarios');
        if (:ITEM_PRE_ENVOLV_FUNCIONARIOS = 1) then
            shuttle := apex_util.string_to_table(:ITEM_PRE_ENVOLV_FUNCIONARIOS_ORGAOS);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO (ID_RESPOSTA_ETAPA_FK, ID_ORGAO_COOPERACAO_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P330_ID_OPERACAO and cd_campo_etapa_fk = 'pre_envolv_foro')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_PRE_ENVOLV_FORO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P330_ID_OPERACAO, 'pre_envolv_foro', :ITEM_PRE_ENVOLV_FORO);
        exception when no_data_found then null;
    end;


    -- marca flag ok
    update tb_operacao set ST_PRE_DEFLAGRACAO_SAVED = 1 where id_operacao = :P330_ID_OPERACAO;

exception when others then
    raise_application_error(-20002, 'Não foi possível salvar (pré-deflagração): ' || SQLERRM);
end;