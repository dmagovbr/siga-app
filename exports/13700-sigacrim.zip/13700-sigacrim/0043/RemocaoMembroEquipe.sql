DECLARE
    total INTEGER;
    tipo_membro_sendo_removido VARCHAR(25);

BEGIN

    --
    IF (:P43_ID_EQUIPE IS NULL) THEN RETURN; END IF;

    BEGIN

        -- total de proprietarios
        SELECT count(*) INTO total FROM tb_equipe WHERE id_operacao_fk = :P43_ID_OPERACAO AND CD_TIPO_MEMBRO = 'Proprietário';

        -- tipo do membro removido   --Alterado por michell.moq 20250901
        --select CD_TIPO_MEMBRO into tipo_membro_sendo_removido from tb_equipe where id_operacao_fk = :P43_ID_OPERACAO and id_matricula_fk = :P310_ID_MATRICULA__REMOVER;
        SELECT CD_TIPO_MEMBRO INTO tipo_membro_sendo_removido FROM tb_equipe WHERE id_equipe = :P43_ID_EQUIPE;
        --
        IF (tipo_membro_sendo_removido = 'Proprietário' AND total <= 1) THEN
            apex_error.add_error(p_message => 'Não foi possível remover o membro da equipe. É necessário pelo menos um membro proprietário.', p_display_location => apex_error.c_inline_in_notification);
            RETURN;
        END IF;

    END;

    -- remove membro da equipe se passou parametro
    IF (:P43_ID_EQUIPE IS NOT NULL) THEN
        DELETE FROM tb_equipe WHERE id_equipe = :P43_ID_EQUIPE ;
    END IF;

END;