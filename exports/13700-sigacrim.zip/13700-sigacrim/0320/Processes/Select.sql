declare

    general_id number;

begin



    ----
    -- Medidas extraordinarias

    --
    --Comentado em atendimento à tarefa 3137 - michell.moq em 08/01/2025
    --===================================================================
    --begin
    --    select ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA into :ITEM_UTILIZACAO_RIF, :ITEM_UTILIZACAO_RIF_QTD from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'utilizacao_rif';
    --    select listagg(ID_TIPO_RIF_FK, ':') into :ITEM_UTILIZACAO_RIF_TIPO from TB_RESPOSTA_ETAPA_TIPO_RIF tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'utilizacao_rif';
    --    select listagg(ID_SIS_RIF_FK, ':') into :ITEM_UTILIZACAO_RIF_IDS from TB_RESPOSTA_ETAPA_SIS_RIF tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'utilizacao_rif';
    --    exception when no_data_found then null;
    --end;
    -- alterado para:
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_UTILIZACAO_RIF from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'utilizacao_rif';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_COOP_POLICIAL_INTERNACIONAL from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'coop_policial_internacional';
        select listagg(ID_PAIS_FK, ':') into :ITEM_COOP_POLICIAL_INTERNACIONAL_PAISES from TB_RESPOSTA_ETAPA_PAIS tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'coop_policial_internacional';
        select listagg(ID_ORGAO_COOPERACAO_FK, ':') into :ITEM_COOP_POLICIAL_INTERNACIONAL_ORGAOS from TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'coop_policial_internacional';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_COOP_JURIDICA_INTERNACIONAL from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'coop_juridica_internacional';
        select listagg(ID_PAIS_FK, ':') into :ITEM_COOP_JURIDICA_INTERNACIONAL_PAISES from TB_RESPOSTA_ETAPA_PAIS tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'coop_juridica_internacional';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_GEOPROCESSAMENTO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'geoprocessamento';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_MATERIAL_GENETICO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'material_genetico';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA into :ITEM_AUXILIO_ORGAO_EXTERNO, :ITEM_AUXILIO_ORGAO_EXTERNO_ORGAOS_OUTROS from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'auxilio_orgao_externo';
        select listagg(ID_ORGAO_COOPERACAO_FK, ':') into :ITEM_AUXILIO_ORGAO_EXTERNO_ORGAOS from TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'auxilio_orgao_externo';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA into :ITEM_COLAB_PREMIADA, :ITEM_COLAB_PREMIADA_QTD from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'colab_premiada';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA into :ITEM_QUEBRA_DADOS_TELEMATICOS, :ITEM_QUEBRA_DADOS_TELEMATICOS_QTD from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'quebra_dados_telematicos';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA into :ITEM_QUEBRA_DADOS_TELEFONICOS, :ITEM_QUEBRA_DADOS_TELEFONICOS_QTD from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'quebra_dados_telefonicos';

        -- comentado em atendimento à tarefa 3142 em 17/01/2025 ana.acat:
        --select listagg(ID_SIS_SIS_FK, ':') into :ITEM_QUEBRA_DADOS_TELEFONICOS_IDSIS from TB_RESPOSTA_ETAPA_SIS_SIS tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'quebra_dados_telefonicos';

    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA into :ITEM_QUEBRA_SIGILOS_TELEFONICOS, :ITEM_QUEBRA_SIGILOS_TELEFONICOS_QTD from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'quebra_sigilos_telefonicos';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA into :ITEM_QUEBRA_SIGILO_FINANCEIRO, :ITEM_QUEBRA_SIGILO_FINANCEIRO_QTD from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'quebra_sigilo_financeiro';

        -- comentado em atendimento à tarefa 3143 em 17/01/2025 michell.moq
        -- select listagg(ID_SIS_SIMBA_FK, ':') into :ITEM_QUEBRA_SIGILO_FINANCEIRO_IDSIMBA from TB_RESPOSTA_ETAPA_SIS_SIMBA tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'quebra_sigilo_financeiro';

    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA into :ITEM_QUEBRA_SIGILO_FISCAL, :ITEM_QUEBRA_SIGILO_FISCAL_QTD from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'quebra_sigilo_fiscal';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA into :ITEM_ACAO_CONTROLADA, :ITEM_ACAO_CONTROLADA_QTD from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'acao_controlada';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA into :ITEM_CAPTACAO_AMBIENTAL, :ITEM_CAPTACAO_AMBIENTAL_QTD from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'captacao_ambiental';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA into :ITEM_AGENTE_INFILTRADO, :ITEM_AGENTE_INFILTRADO_QTD from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'agente_infiltrado';
    exception when no_data_found then null;
    end;


    ----
    -- Informacoes gerais

    --
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_CRIME_TRANSNACIONAL from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_transnacional';
        select listagg(ID_PAIS_FK, ':') into :ITEM_CRIME_TRANSNACIONAL_PAISES from TB_RESPOSTA_ETAPA_PAIS tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_transnacional';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_CRIME_INTERESTADUAL from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_interestadual';
        select listagg(ID_UF_FK, ':') into :ITEM_CRIME_INTERESTADUAL_UFS from TB_RESPOSTA_ETAPA_UF tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_interestadual';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA into :ITEM_FACCAO_CRIMINOSA, :ITEM_FACCAO_CRIMINOSA_FACCOES_OUTRAS from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'faccao_criminosa';
        select listagg(ID_ORCRIM_FK, ':') into :ITEM_FACCAO_CRIMINOSA_FACCOES from TB_RESPOSTA_ETAPA_ORCRIM tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'faccao_criminosa';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_AREA_FRONTEIRA from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'area_fronteira';
        select listagg(ID_PAIS_FK, ':') into :ITEM_AREA_FRONTEIRA_PAISES from TB_RESPOSTA_ETAPA_PAIS tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'area_fronteira';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA into :ITEM_RELACIONADA_MILICIA, :ITEM_RELACIONADA_MILICIA_DETALHES from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'relacionada_milicia';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA into :ITEM_TERRA_INDIGENA, :ITEM_TERRA_INDIGENA_TERRAS_OUTRAS from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'terra_indigena';
        select listagg(ID_TERRA_INDIGENA_FK, ':') into :ITEM_TERRA_INDIGENA_TERRAS from TB_RESPOSTA_ETAPA_TERRA_INDIGENA tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'terra_indigena';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_ENVOLVE_UNIDADE_CONSERVACAO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'envolve_unidade_conservacao';
        select listagg(ID_UNIDADE_CONSERVACAO_FK, ':') into :ITEM_ENVOLVE_UNIDADE_CONSERVACAO_UNIDADES from TB_RESPOSTA_ETAPA_UNIDADE_CONSERVACAO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'envolve_unidade_conservacao';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA, DS_RESPOSTA_ETAPA into :ITEM_ENVOLVE_AREA_PRIORITARIA, :ITEM_ENVOLVE_AREA_PRIORITARIA_AREAS_OUTRAS, :ITEM_ENVOLVE_AREA_PRIORITARIA_JUST from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'envolve_area_prioritaria';
        select listagg(ID_AREA_GEOGRAFICA_FK, ':') into :ITEM_ENVOLVE_AREA_PRIORITARIA_AREAS from TB_RESPOSTA_ETAPA_AREA_GEOGRAFICA tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'envolve_area_prioritaria';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_CRIPTOATIVO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'criptoativo';
    exception when no_data_found then null;
    end;

    --
    begin
        select QT_RESPOSTA_ETAPA into :ITEM_PROMETHEUS_QTD_NOTICIAS from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'prometheus_qtd_noticias';
        select ST_RESPOSTA_ETAPA into :ITEM_PROMETHEUS from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'prometheus';
        select listagg(ID_SIS_PROMETHEUS_MATERIA_FK, ':') into :ITEM_PROMETHEUS_MATERIA from TB_RESPOSTA_ETAPA_SIS_PROMETHEUS_MATERIA tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'prometheus';
        select ST_RESPOSTA_ETAPA into :ITEM_PROMETHEUS_FORMULARIO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'prometheus_formulario';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_CRIME_LAVAGEM_DINHEIRO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_lavagem_dinheiro';
        select listagg(ID_ATIVIDADE_ECONOMICA_FK, ':') into :ITEM_CRIME_LAVAGEM_DINHEIRO_ATIVIDADES from TB_RESPOSTA_ETAPA_ATIVIDADE_ECONOMICA tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_lavagem_dinheiro';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_CRIME_LAVAGEM_DINHEIRO_ATOS from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_lavagem_dinheiro_atos';
    exception when no_data_found then null;
    end;

    begin
        select ST_RESPOSTA_ETAPA into :ITEM_CRIME_LAVAGEM_DINHEIRO_TIPOLOGIAS from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_lavagem_dinheiro_tipologias';
    exception when no_data_found then null;
    end;

    /*
    20250319 - https://tree.taiga.io/project/eduardoemi-sigacrim/task/3669
        begin
            select ST_RESPOSTA_ETAPA into :ITEM_REGISTRO_ESPECIAL from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'registro_especial';


            -- Comentado em atendimento à tarefa 3144 em 17/01/2025 ana.ITEM_ACAO_CONTROLADA_QTD
            --select listagg(NR_RE, ':') into :ITEM_REGISTRO_ESPECIAL_NRS from TB_RESPOSTA_ETAPA_RE tb
            --left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'registro_especial';

        exception when no_data_found then null;
        end;

     */

    --
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_CRIME_EVASAO_DIVISAS from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_evasao_divisas';
        select listagg(ID_MEIO_EVASAO_DIVISA_FK, ':') into :ITEM_CRIME_EVASAO_DIVISAS_MEIOS from TB_RESPOSTA_ETAPA_MEIO_EVASAO_DIVISA tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_evasao_divisas';
        select listagg(ID_PAIS_FK, ':') into :ITEM_CRIME_EVASAO_DIVISAS_PAISES from TB_RESPOSTA_ETAPA_PAIS tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_evasao_divisas';
    exception when no_data_found then null;
    end;

    --
    begin
        select ST_RESPOSTA_ETAPA into :ITEM_TENTACULOS from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'tentaculos';
        select DS_RESPOSTA_ETAPA into :ITEM_TENTACULOS_SEI_IPJ from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'tentaculos_sei_ipj';
        select QT_RESPOSTA_ETAPA into :ITEM_TENTACULOS_QTD_NOTICIAS from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'tentaculos_qtd_noticias';
        select VL_RESPOSTA_ETAPA into :ITEM_TENTACULOS_FRAUDE from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'tentaculos_fraude';
        select ST_RESPOSTA_ETAPA into :ITEM_TENTACULOS_IPJ_ENVIADA_CBAN from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'tentaculos_ipj_enviada_cban';
    exception when no_data_found then null;
    end;

exception
    when others then
        raise_application_error(
            -20303,
            'ERRO INTERNO DETECTADO (Andamento)'                 || CHR(10) ||
            'Mensagem: ' || SQLERRM                              || CHR(10) ||
            'Código:    ' || SQLCODE                             || CHR(10) ||
            'Backtrace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,
            false
        );

/*
exception
    when others then
        apex_debug.error('Erro geral não tratado: ' || SQLERRM);
        raise_application_error(-20303, 'Não foi possível recuperar os dados no momento (Em andamento). Caso o problema persista, por favor, entre em contato com o suporte.'|| SQLERRM, false);
*/

end;
