DECLARE
    v_dummy number;
    last_id number;

BEGIN

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'acao_controlada', p_st_resposta => :ITEM_ACAO_CONTROLADA, p_qt_resposta => :ITEM_ACAO_CONTROLADA_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'agente_infiltrado', p_st_resposta => :ITEM_AGENTE_INFILTRADO, p_qt_resposta => :ITEM_AGENTE_INFILTRADO_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'captacao_ambiental', p_st_resposta => :ITEM_CAPTACAO_AMBIENTAL, p_qt_resposta => :ITEM_CAPTACAO_AMBIENTAL_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'colab_premiada', p_st_resposta => :ITEM_COLAB_PREMIADA, p_qt_resposta => :ITEM_COLAB_PREMIADA_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'geoprocessamento', p_st_resposta => :ITEM_GEOPROCESSAMENTO);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'material_genetico', p_st_resposta => :ITEM_MATERIAL_GENETICO);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'quebra_dados_telefonicos', p_st_resposta => :ITEM_QUEBRA_DADOS_TELEFONICOS, p_qt_resposta => :ITEM_QUEBRA_DADOS_TELEFONICOS_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'quebra_dados_telematicos', p_st_resposta => :ITEM_QUEBRA_DADOS_TELEMATICOS, p_qt_resposta => :ITEM_QUEBRA_DADOS_TELEMATICOS_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'quebra_sigilo_financeiro', p_st_resposta => :ITEM_QUEBRA_SIGILO_FINANCEIRO, p_qt_resposta => :ITEM_QUEBRA_SIGILO_FINANCEIRO_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'quebra_sigilo_fiscal', p_st_resposta => :ITEM_QUEBRA_SIGILO_FISCAL, p_qt_resposta => :ITEM_QUEBRA_SIGILO_FISCAL_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'quebra_sigilos_telefonicos', p_st_resposta => :ITEM_QUEBRA_SIGILOS_TELEFONICOS, p_qt_resposta => :ITEM_QUEBRA_SIGILOS_TELEFONICOS_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'utilizacao_rif', p_st_resposta => :ITEM_UTILIZACAO_RIF);

    --
    last_id := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'coop_policial_internacional', p_st_resposta => :ITEM_COOP_POLICIAL_INTERNACIONAL);
    upsert_resposta_etapa_pais(last_id, :ITEM_COOP_POLICIAL_INTERNACIONAL, :ITEM_COOP_POLICIAL_INTERNACIONAL_PAISES);
    upsert_resposta_etapa_orgao_cooperacao(last_id, :ITEM_COOP_POLICIAL_INTERNACIONAL, :ITEM_COOP_POLICIAL_INTERNACIONAL_ORGAOS);

    --
    last_id := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'coop_juridica_internacional', p_st_resposta => :ITEM_COOP_JURIDICA_INTERNACIONAL);
    upsert_resposta_etapa_pais(last_id, :ITEM_COOP_JURIDICA_INTERNACIONAL, :ITEM_COOP_JURIDICA_INTERNACIONAL_PAISES);

    --
    last_id := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'auxilio_orgao_externo', p_st_resposta => :ITEM_AUXILIO_ORGAO_EXTERNO, p_ob_resposta => :ITEM_AUXILIO_ORGAO_EXTERNO_ORGAOS_OUTROS);
    upsert_resposta_etapa_orgao_cooperacao(last_id, :ITEM_AUXILIO_ORGAO_EXTERNO, :ITEM_AUXILIO_ORGAO_EXTERNO_ORGAOS);

EXCEPTION
    WHEN OTHERS THEN
        raise_application_error(-20002, 'Não foi possível salvar (em andamento 1/2): ' || sqlerrm);

END;