-- noinspection SqlInsertValuesForFile

-- noinspection SqlInsertValuesForFile

DECLARE
    shuttle wwv_flow_global.VC_ARR2;
    last_id number;

BEGIN


    ----
    -- Informacoes gerais

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'crime_transnacional')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_CRIME_TRANSNACIONAL
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'crime_transnacional', :ITEM_CRIME_TRANSNACIONAL);
        --
        SELECT id_resposta_etapa INTO last_id FROM tb_resposta_etapa WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'crime_transnacional';
        DELETE FROM tb_resposta_etapa_pais WHERE id_resposta_etapa_pais IN (SELECT id_resposta_etapa_pais FROM tb_resposta_etapa_pais tb LEFT JOIN tb_resposta_etapa tr ON tr.id_resposta_etapa = tb.id_resposta_etapa_fk WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'crime_transnacional');
        IF (:ITEM_CRIME_TRANSNACIONAL = 1) THEN
            shuttle := apex_util.string_to_table(:ITEM_CRIME_TRANSNACIONAL_PAISES);
            FOR i IN 1..shuttle.count LOOP
                INSERT INTO tb_resposta_etapa_pais (id_resposta_etapa_fk, id_pais_fk) VALUES (last_id, shuttle(i));
            END LOOP;
        END IF;
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'crime_interestadual')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_CRIME_INTERESTADUAL
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'crime_interestadual', :ITEM_CRIME_INTERESTADUAL);
        --
        SELECT id_resposta_etapa INTO last_id FROM tb_resposta_etapa WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'crime_interestadual';
        DELETE FROM tb_resposta_etapa_uf WHERE id_resposta_etapa_uf IN (SELECT id_resposta_etapa_uf FROM tb_resposta_etapa_uf tb LEFT JOIN tb_resposta_etapa tr ON tr.id_resposta_etapa = tb.id_resposta_etapa_fk WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'crime_interestadual');
        IF (:ITEM_CRIME_INTERESTADUAL = 1) THEN
            shuttle := apex_util.string_to_table(:ITEM_CRIME_INTERESTADUAL_UFS);
            FOR i IN 1..shuttle.count LOOP
                INSERT INTO tb_resposta_etapa_uf (id_resposta_etapa_fk, id_uf_fk) VALUES (last_id, shuttle(i));
            END LOOP;
        END IF;
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'faccao_criminosa')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_FACCAO_CRIMINOSA, ob_resposta_etapa = :ITEM_FACCAO_CRIMINOSA_FACCOES_OUTRAS
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa, ob_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'faccao_criminosa', :ITEM_FACCAO_CRIMINOSA, :ITEM_FACCAO_CRIMINOSA_FACCOES_OUTRAS);
        --
        SELECT id_resposta_etapa INTO last_id FROM tb_resposta_etapa WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'faccao_criminosa';
        DELETE FROM tb_resposta_etapa_orcrim WHERE id_resposta_etapa_orcrim IN (SELECT id_resposta_etapa_orcrim FROM tb_resposta_etapa_orcrim tb LEFT JOIN tb_resposta_etapa tr ON tr.id_resposta_etapa = tb.id_resposta_etapa_fk WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'faccao_criminosa');
        IF (:ITEM_FACCAO_CRIMINOSA = 1) THEN
            shuttle := apex_util.string_to_table(:ITEM_FACCAO_CRIMINOSA_FACCOES);
            FOR i IN 1..shuttle.count LOOP
                INSERT INTO tb_resposta_etapa_orcrim (id_resposta_etapa_fk, id_orcrim_fk) VALUES (last_id, shuttle(i));
            END LOOP;
        END IF;
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'area_fronteira')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_AREA_FRONTEIRA
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'area_fronteira', :ITEM_AREA_FRONTEIRA);
        --
        SELECT id_resposta_etapa INTO last_id FROM tb_resposta_etapa WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'area_fronteira';
        DELETE FROM tb_resposta_etapa_pais WHERE id_resposta_etapa_pais IN (SELECT id_resposta_etapa_pais FROM tb_resposta_etapa_pais tb LEFT JOIN tb_resposta_etapa tr ON tr.id_resposta_etapa = tb.id_resposta_etapa_fk WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'area_fronteira');
        IF (:ITEM_AREA_FRONTEIRA = 1) THEN
            shuttle := apex_util.string_to_table(:ITEM_AREA_FRONTEIRA_PAISES);
            FOR i IN 1..shuttle.count LOOP
                INSERT INTO tb_resposta_etapa_pais (id_resposta_etapa_fk, id_pais_fk) VALUES (last_id, shuttle(i));
            END LOOP;
        END IF;
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'relacionada_milicia')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_RELACIONADA_MILICIA, ob_resposta_etapa = :ITEM_RELACIONADA_MILICIA_DETALHES
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa, ob_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'relacionada_milicia', :ITEM_RELACIONADA_MILICIA, :ITEM_RELACIONADA_MILICIA_DETALHES);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'terra_indigena')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_TERRA_INDIGENA, ob_resposta_etapa = :ITEM_TERRA_INDIGENA_TERRAS_OUTRAS
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa, ob_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'terra_indigena', :ITEM_TERRA_INDIGENA, :ITEM_TERRA_INDIGENA_TERRAS_OUTRAS);
        --
        SELECT id_resposta_etapa INTO last_id FROM tb_resposta_etapa WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'terra_indigena';
        DELETE FROM tb_resposta_etapa_terra_indigena WHERE id_resposta_etapa_terra_indigena IN (SELECT id_resposta_etapa_terra_indigena FROM tb_resposta_etapa_terra_indigena tb LEFT JOIN tb_resposta_etapa tr ON tr.id_resposta_etapa = tb.id_resposta_etapa_fk WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'terra_indigena');
        IF (:ITEM_TERRA_INDIGENA = 1) THEN
            shuttle := apex_util.string_to_table(:ITEM_TERRA_INDIGENA_TERRAS);
            FOR i IN 1..shuttle.count LOOP
                INSERT INTO tb_resposta_etapa_terra_indigena (id_resposta_etapa_fk, id_terra_indigena_fk) VALUES (last_id, shuttle(i));
            END LOOP;
        END IF;
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'envolve_unidade_conservacao')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_ENVOLVE_UNIDADE_CONSERVACAO
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'envolve_unidade_conservacao', :ITEM_ENVOLVE_UNIDADE_CONSERVACAO);
        --
        SELECT id_resposta_etapa INTO last_id FROM tb_resposta_etapa WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'envolve_unidade_conservacao';
        DELETE FROM tb_resposta_etapa_unidade_conservacao WHERE id_resposta_etapa_unidade_conservacao IN (SELECT id_resposta_etapa_unidade_conservacao FROM tb_resposta_etapa_unidade_conservacao tb LEFT JOIN tb_resposta_etapa tr ON tr.id_resposta_etapa = tb.id_resposta_etapa_fk WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'envolve_unidade_conservacao');
        IF (:ITEM_ENVOLVE_UNIDADE_CONSERVACAO = 1) THEN
            shuttle := apex_util.string_to_table(:ITEM_ENVOLVE_UNIDADE_CONSERVACAO_UNIDADES);
            FOR i IN 1..shuttle.count LOOP
                INSERT INTO tb_resposta_etapa_unidade_conservacao (id_resposta_etapa_fk, id_unidade_conservacao_fk) VALUES (last_id, shuttle(i));
            END LOOP;
        END IF;
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'envolve_area_prioritaria')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_ENVOLVE_AREA_PRIORITARIA, ob_resposta_etapa = :ITEM_ENVOLVE_AREA_PRIORITARIA_AREAS_OUTRAS, ds_resposta_etapa = :ITEM_ENVOLVE_AREA_PRIORITARIA_JUST
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa, ob_resposta_etapa, ds_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'envolve_area_prioritaria', :ITEM_ENVOLVE_AREA_PRIORITARIA, :ITEM_ENVOLVE_AREA_PRIORITARIA_AREAS_OUTRAS, :ITEM_ENVOLVE_AREA_PRIORITARIA_JUST);
        --
        SELECT id_resposta_etapa INTO last_id FROM tb_resposta_etapa WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'envolve_area_prioritaria';
        DELETE FROM tb_resposta_etapa_area_geografica WHERE id_resposta_etapa_area_geografica IN (SELECT id_resposta_etapa_area_geografica FROM tb_resposta_etapa_area_geografica tb LEFT JOIN tb_resposta_etapa tr ON tr.id_resposta_etapa = tb.id_resposta_etapa_fk WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'envolve_area_prioritaria');
        IF (:ITEM_ENVOLVE_AREA_PRIORITARIA = 1) THEN
            shuttle := apex_util.string_to_table(:ITEM_ENVOLVE_AREA_PRIORITARIA_AREAS);
            FOR i IN 1..shuttle.count LOOP
                INSERT INTO tb_resposta_etapa_area_geografica (id_resposta_etapa_fk, id_area_geografica_fk) VALUES (last_id, shuttle(i));
            END LOOP;
        END IF;
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'criptoativo')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_CRIPTOATIVO
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'criptoativo', :ITEM_CRIPTOATIVO);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'prometheus_qtd_noticias')
        WHEN MATCHED THEN
            UPDATE SET qt_resposta_etapa = :ITEM_PROMETHEUS_QTD_NOTICIAS
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, qt_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'prometheus_qtd_noticias', :ITEM_PROMETHEUS_QTD_NOTICIAS);
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'prometheus')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_PROMETHEUS
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'prometheus', :ITEM_PROMETHEUS);
        --
        SELECT id_resposta_etapa INTO last_id FROM tb_resposta_etapa WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'prometheus';
        DELETE FROM tb_resposta_etapa_sis_prometheus_materia WHERE id_resposta_etapa_sis_prometheus_materia IN (SELECT id_resposta_etapa_sis_prometheus_materia FROM tb_resposta_etapa_sis_prometheus_materia tb LEFT JOIN tb_resposta_etapa tr ON tr.id_resposta_etapa = tb.id_resposta_etapa_fk WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'prometheus');
        IF (:ITEM_PROMETHEUS = 1) THEN
            shuttle := apex_util.string_to_table(:ITEM_PROMETHEUS_MATERIA);
            FOR i IN 1..shuttle.count LOOP
                INSERT INTO tb_resposta_etapa_sis_prometheus_materia (id_resposta_etapa_fk, id_sis_prometheus_materia_fk) VALUES (last_id, shuttle(i));
            END LOOP;
        END IF;
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'prometheus_formulario')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_PROMETHEUS_FORMULARIO
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'prometheus_formulario', :ITEM_PROMETHEUS_FORMULARIO);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;


EXCEPTION
    WHEN OTHERS THEN
        raise_application_error(-20002, 'Não foi possível salvar (em andamento - merge 3/4): ' || SQLERRM);
END;