DECLARE
    shuttle wwv_flow_global.VC_ARR2;
    last_id number;

BEGIN


    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'quebra_dados_telematicos')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_QUEBRA_DADOS_TELEMATICOS, qt_resposta_etapa = :ITEM_QUEBRA_DADOS_TELEMATICOS_QTD
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa, qt_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'quebra_dados_telematicos', :ITEM_QUEBRA_DADOS_TELEMATICOS, :ITEM_QUEBRA_DADOS_TELEMATICOS_QTD);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'quebra_dados_telefonicos')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_QUEBRA_DADOS_TELEFONICOS, qt_resposta_etapa = :ITEM_QUEBRA_DADOS_TELEFONICOS_QTD
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa, qt_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'quebra_dados_telefonicos', :ITEM_QUEBRA_DADOS_TELEFONICOS, :ITEM_QUEBRA_DADOS_TELEFONICOS_QTD);

        --
        -- comentado em atendimento à tarefa 3142 em 17/01/2025 ana.acat:
        --select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'quebra_dados_telefonicos';
        --delete from TB_RESPOSTA_ETAPA_SIS_SIS where ID_RESPOSTA_ETAPA_SIS_SIS IN (select ID_RESPOSTA_ETAPA_SIS_SIS from TB_RESPOSTA_ETAPA_SIS_SIS tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'quebra_dados_telefonicos');
        --if (:ITEM_QUEBRA_DADOS_TELEFONICOS = 1) then
        --    shuttle := apex_util.string_to_table(:ITEM_QUEBRA_DADOS_TELEFONICOS_IDSIS);
        --    for i in 1..shuttle.count loop
        --        insert into TB_RESPOSTA_ETAPA_SIS_SIS (ID_RESPOSTA_ETAPA_FK, ID_SIS_SIS_FK) VALUES(last_id, shuttle(i));
        --    end loop;
        --end if;

    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'quebra_sigilos_telefonicos')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_QUEBRA_SIGILOS_TELEFONICOS, qt_resposta_etapa = :ITEM_QUEBRA_SIGILOS_TELEFONICOS_QTD
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa, qt_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'quebra_sigilos_telefonicos', :ITEM_QUEBRA_SIGILOS_TELEFONICOS, :ITEM_QUEBRA_SIGILOS_TELEFONICOS_QTD);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'quebra_sigilo_financeiro')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_QUEBRA_SIGILO_FINANCEIRO, qt_resposta_etapa = :ITEM_QUEBRA_SIGILO_FINANCEIRO_QTD
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa, qt_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'quebra_sigilo_financeiro', :ITEM_QUEBRA_SIGILO_FINANCEIRO, :ITEM_QUEBRA_SIGILO_FINANCEIRO_QTD);
        --
        -- comentado em atendimento à tarefa 3143 em 17/01/2025 ana.acat
        --select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'quebra_sigilo_financeiro';
        --delete from TB_RESPOSTA_ETAPA_SIS_SIMBA where ID_RESPOSTA_ETAPA_SIS_SIMBA IN (select ID_RESPOSTA_ETAPA_SIS_SIMBA from TB_RESPOSTA_ETAPA_SIS_SIMBA tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'quebra_sigilo_financeiro');
        --if (:ITEM_QUEBRA_SIGILO_FINANCEIRO = 1) then
        --    shuttle := apex_util.string_to_table(:ITEM_QUEBRA_SIGILO_FINANCEIRO_IDSIMBA);
        --    for i in 1..shuttle.count loop
        --        insert into TB_RESPOSTA_ETAPA_SIS_SIMBA (ID_RESPOSTA_ETAPA_FK, ID_SIS_SIMBA_FK) VALUES(last_id, shuttle(i));
        --    end loop;
        --end if;

    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'quebra_sigilo_fiscal')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_QUEBRA_SIGILO_FISCAL, qt_resposta_etapa = :ITEM_QUEBRA_SIGILO_FISCAL_QTD
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa, qt_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'quebra_sigilo_fiscal', :ITEM_QUEBRA_SIGILO_FISCAL, :ITEM_QUEBRA_SIGILO_FISCAL_QTD);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'acao_controlada')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_ACAO_CONTROLADA, qt_resposta_etapa = :ITEM_ACAO_CONTROLADA_QTD
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa, qt_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'acao_controlada', :ITEM_ACAO_CONTROLADA, :ITEM_ACAO_CONTROLADA_QTD);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'captacao_ambiental')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_CAPTACAO_AMBIENTAL, qt_resposta_etapa = :ITEM_CAPTACAO_AMBIENTAL_QTD
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa, qt_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'captacao_ambiental', :ITEM_CAPTACAO_AMBIENTAL, :ITEM_CAPTACAO_AMBIENTAL_QTD);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'agente_infiltrado')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_AGENTE_INFILTRADO, qt_resposta_etapa = :ITEM_AGENTE_INFILTRADO_QTD
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa, qt_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'agente_infiltrado', :ITEM_AGENTE_INFILTRADO, :ITEM_AGENTE_INFILTRADO_QTD);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;


EXCEPTION
    WHEN OTHERS THEN
        --raise_application_error(-20303, 'Não foi possível salvar agora, tente novamente em instantes. Caso o problema persista, por favor, entre em contato com o suporte.', false);
        raise_application_error(-20002, 'Não foi possível salvar (em andamento - merge 2/4): ' || SQLERRM);
END;