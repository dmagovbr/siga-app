-- noinspection SqlInsertValuesForFile

-- noinspection SqlInsertValuesForFile

DECLARE
    shuttle wwv_flow_global.VC_ARR2;
    last_id number;

BEGIN

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'crime_lavagem_dinheiro')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_CRIME_LAVAGEM_DINHEIRO
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'crime_lavagem_dinheiro', :ITEM_CRIME_LAVAGEM_DINHEIRO);
        --
        SELECT id_resposta_etapa
        INTO last_id
        FROM tb_resposta_etapa
        WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'crime_lavagem_dinheiro';
        DELETE
        FROM tb_resposta_etapa_atividade_economica
        WHERE id_resposta_etapa_atividade_economica IN
              (SELECT id_resposta_etapa_atividade_economica
               FROM tb_resposta_etapa_atividade_economica tb
               LEFT JOIN tb_resposta_etapa tr ON tr.id_resposta_etapa = tb.id_resposta_etapa_fk
               WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'crime_lavagem_dinheiro');
        IF (:ITEM_CRIME_LAVAGEM_DINHEIRO = 1) THEN
            shuttle := apex_util.string_to_table(:ITEM_CRIME_LAVAGEM_DINHEIRO_ATIVIDADES);
            FOR i IN 1..shuttle.count LOOP
                INSERT INTO tb_resposta_etapa_atividade_economica (id_resposta_etapa_fk, id_atividade_economica_fk)
                VALUES (last_id, shuttle(i));
            END LOOP;
        END IF;
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'crime_lavagem_dinheiro_atos')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_CRIME_LAVAGEM_DINHEIRO_ATOS
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'crime_lavagem_dinheiro_atos', :ITEM_CRIME_LAVAGEM_DINHEIRO_ATOS);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'crime_lavagem_dinheiro_tipologias')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_CRIME_LAVAGEM_DINHEIRO_TIPOLOGIAS
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'crime_lavagem_dinheiro_tipologias', :ITEM_CRIME_LAVAGEM_DINHEIRO_TIPOLOGIAS);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    /*
    20250319 https://tree.taiga.io/project/eduardoemi-sigacrim/task/3669
        begin
            merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'registro_especial')
            when matched then update set ST_RESPOSTA_ETAPA = :ITEM_REGISTRO_ESPECIAL
            when not matched then insert  (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P320_ID_OPERACAO, 'registro_especial', :ITEM_REGISTRO_ESPECIAL);
            --
            -- Comentado em atendimento à tarefa 3144 em 17/01/2025 ana.acat
            --select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'registro_especial';
            --delete from TB_RESPOSTA_ETAPA_RE where ID_RESPOSTA_ETAPA_FK IN (select id_resposta_etapa from tb_resposta_etapa where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'registro_especial');
            --if (:ITEM_REGISTRO_ESPECIAL = 1) then
            --    shuttle := apex_util.string_to_table(:ITEM_REGISTRO_ESPECIAL_NRS);
            --    for i in 1..shuttle.count loop
            --        insert into TB_RESPOSTA_ETAPA_RE
            --                    (ID_RESPOSTA_ETAPA_FK, NR_RE) VALUES
            --                    (last_id, shuttle(i));
            --    end loop;
            --end if;

        exception
            when no_data_found then
                raise_application_error(-20001, 'Nenhum dado encontrado para a operação ou campo etapa especificado.');
            when others then
                raise_application_error(-20002, 'Erro inesperado: ' || SQLERRM);
        end;
     */


    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'crime_evasao_divisas')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_CRIME_EVASAO_DIVISAS
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'crime_evasao_divisas', :ITEM_CRIME_EVASAO_DIVISAS);
        --
        SELECT id_resposta_etapa INTO last_id FROM tb_resposta_etapa WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'crime_evasao_divisas';
        DELETE FROM tb_resposta_etapa_meio_evasao_divisa WHERE id_resposta_etapa_meio_evasao_divisa IN (SELECT id_resposta_etapa_meio_evasao_divisa FROM tb_resposta_etapa_meio_evasao_divisa tb LEFT JOIN tb_resposta_etapa tr ON tr.id_resposta_etapa = tb.id_resposta_etapa_fk WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'crime_evasao_divisas');
        IF (:ITEM_CRIME_EVASAO_DIVISAS = 1) THEN
            shuttle := apex_util.string_to_table(:ITEM_CRIME_EVASAO_DIVISAS_MEIOS);
            FOR i IN 1..shuttle.count LOOP
                INSERT INTO tb_resposta_etapa_meio_evasao_divisa (id_resposta_etapa_fk, id_meio_evasao_divisa_fk) VALUES (last_id, shuttle(i));
            END LOOP;
        END IF;
        --
        SELECT id_resposta_etapa INTO last_id FROM tb_resposta_etapa WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'crime_evasao_divisas';
        DELETE FROM tb_resposta_etapa_pais WHERE id_resposta_etapa_pais IN (SELECT id_resposta_etapa_pais FROM tb_resposta_etapa_pais tb LEFT JOIN tb_resposta_etapa tr ON tr.id_resposta_etapa = tb.id_resposta_etapa_fk WHERE id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'crime_evasao_divisas');
        IF (:ITEM_CRIME_EVASAO_DIVISAS = 1) THEN
            shuttle := apex_util.string_to_table(:ITEM_CRIME_EVASAO_DIVISAS_PAISES);
            FOR i IN 1..shuttle.count LOOP
                INSERT INTO tb_resposta_etapa_pais (id_resposta_etapa_fk, id_pais_fk) VALUES (last_id, shuttle(i));
            END LOOP;
        END IF;
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN

        --
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'tentaculos')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_TENTACULOS
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa) VALUES (:P320_ID_OPERACAO, 'tentaculos', :ITEM_TENTACULOS);
        --
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'tentaculos_sei_ipj')
        WHEN MATCHED THEN
            UPDATE SET ds_resposta_etapa = :ITEM_TENTACULOS_SEI_IPJ, ds_meta_info = 'Nº do SEI que contenha a IPJ'
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, ds_resposta_etapa, ds_meta_info) VALUES (:P320_ID_OPERACAO, 'tentaculos_sei_ipj', :ITEM_TENTACULOS_SEI_IPJ, 'Nº do SEI que contenha a IPJ');
        --
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'tentaculos_qtd_noticias')
        WHEN MATCHED THEN
            UPDATE SET qt_resposta_etapa = :ITEM_TENTACULOS_QTD_NOTICIAS, ds_meta_info = ''
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, qt_resposta_etapa, ds_meta_info) VALUES (:P320_ID_OPERACAO, 'tentaculos_qtd_noticias', to_number(:ITEM_TENTACULOS_QTD_NOTICIAS, '999G999G999G999G990D00'), '');
        --
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'tentaculos_fraude')
        WHEN MATCHED THEN
            UPDATE SET vl_resposta_etapa = to_number(:ITEM_TENTACULOS_FRAUDE, '999G999G999G999G990D00'), ds_meta_info = ''
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, vl_resposta_etapa, ds_meta_info) VALUES (:P320_ID_OPERACAO, 'tentaculos_fraude', to_number(:ITEM_TENTACULOS_FRAUDE, '999G999G999G999G990D00'), '');
        --
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'tentaculos_ipj_enviada_cban')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_TENTACULOS_IPJ_ENVIADA_CBAN, ds_meta_info = ''
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa, ds_meta_info) VALUES (:P320_ID_OPERACAO, 'tentaculos_ipj_enviada_cban', to_number(:ITEM_TENTACULOS_IPJ_ENVIADA_CBAN, '999G999G999G999G990D00'), '');

    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;


EXCEPTION
    WHEN OTHERS THEN
        raise_application_error(-20002, 'Não foi possível salvar (em andamento - merge 4/4): ' || SQLERRM);
END;