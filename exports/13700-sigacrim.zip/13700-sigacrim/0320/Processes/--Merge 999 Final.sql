DECLARE

BEGIN

    -- marca flag ok
    UPDATE tb_operacao SET st_andamento_saved = 1 WHERE id_operacao = :P320_ID_OPERACAO;


EXCEPTION
    WHEN OTHERS THEN
        raise_application_error(-20002, 'Não foi possível salvar (em Andamento - Merge 999 Final): ' || sqlerrm);
END;