DECLARE
    v_dummy number;
    last_id number;

BEGIN

    ----
    -- Informacoes gerais

    --
    last_id := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'crime_transnacional', p_st_resposta => :ITEM_CRIME_TRANSNACIONAL);
    upsert_resposta_etapa_pais(last_id, :ITEM_CRIME_TRANSNACIONAL, :ITEM_CRIME_TRANSNACIONAL_PAISES);

    --
    last_id := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'crime_interestadual', p_st_resposta => :ITEM_CRIME_INTERESTADUAL);
    upsert_resposta_etapa_uf(last_id, :ITEM_CRIME_INTERESTADUAL, :ITEM_CRIME_INTERESTADUAL_UFS);

    --
    last_id := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'faccao_criminosa', p_st_resposta => :ITEM_FACCAO_CRIMINOSA, p_ob_resposta => :ITEM_FACCAO_CRIMINOSA_FACCOES_OUTRAS);
    upsert_resposta_etapa_orcrim(last_id, :ITEM_FACCAO_CRIMINOSA, :ITEM_FACCAO_CRIMINOSA_FACCOES);

    -- 20260527
    last_id := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'faccao_campanha_eleitoral', p_st_resposta => :ITEM_FACCAO_CAMPANHA_ELEITORAL);
    upsert_resposta_etapa_tipo_campanha(last_id, :ITEM_FACCAO_CAMPANHA_ELEITORAL, :ITEM_FACCAO_CAMPANHA_ELEITORAL_TIPOS);

    --
    last_id := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'area_fronteira', p_st_resposta => :ITEM_AREA_FRONTEIRA);
    upsert_resposta_etapa_pais(last_id, :ITEM_AREA_FRONTEIRA, :ITEM_AREA_FRONTEIRA_PAISES);

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'relacionada_milicia', p_st_resposta => :ITEM_RELACIONADA_MILICIA, p_ob_resposta => :ITEM_RELACIONADA_MILICIA_DETALHES);

    --
    last_id := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'terra_indigena', p_st_resposta => :ITEM_TERRA_INDIGENA, p_ob_resposta => :ITEM_TERRA_INDIGENA_TERRAS_OUTRAS);
    upsert_resposta_etapa_terra_indigena(last_id, :ITEM_TERRA_INDIGENA, :ITEM_TERRA_INDIGENA_TERRAS);

    --
    last_id := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'envolve_unidade_conservacao', p_st_resposta => :ITEM_ENVOLVE_UNIDADE_CONSERVACAO);
    upsert_resposta_etapa_unidade_conservacao(last_id, :ITEM_ENVOLVE_UNIDADE_CONSERVACAO, :ITEM_ENVOLVE_UNIDADE_CONSERVACAO_UNIDADES);

    --
    last_id := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'envolve_area_prioritaria', p_st_resposta => :ITEM_ENVOLVE_AREA_PRIORITARIA, p_ob_resposta => :ITEM_ENVOLVE_AREA_PRIORITARIA_AREAS_OUTRAS, p_ds_resposta => :ITEM_ENVOLVE_AREA_PRIORITARIA_JUST);
    upsert_resposta_etapa_area_geografica(last_id, :ITEM_ENVOLVE_AREA_PRIORITARIA, :ITEM_ENVOLVE_AREA_PRIORITARIA_AREAS);

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'criptoativo', p_st_resposta => :ITEM_CRIPTOATIVO);

    --
    -- prometheus: salva qt_noticias, prometheus (st + filhos), formulario
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'prometheus_qtd_noticias', p_qt_resposta => :ITEM_PROMETHEUS_QTD_NOTICIAS);
    last_id := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'prometheus', p_st_resposta => :ITEM_PROMETHEUS);
    upsert_resposta_etapa_sis_prometheus_materia(last_id, :ITEM_PROMETHEUS, :ITEM_PROMETHEUS_MATERIA);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'prometheus_formulario', p_st_resposta => :ITEM_PROMETHEUS_FORMULARIO);

    --
    last_id := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'crime_lavagem_dinheiro', p_st_resposta => :ITEM_CRIME_LAVAGEM_DINHEIRO);
    upsert_resposta_etapa_atividade_economica(last_id, :ITEM_CRIME_LAVAGEM_DINHEIRO, :ITEM_CRIME_LAVAGEM_DINHEIRO_ATIVIDADES);

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'crime_lavagem_dinheiro_atos', p_st_resposta => :ITEM_CRIME_LAVAGEM_DINHEIRO_ATOS);

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'crime_lavagem_dinheiro_tipologias', p_st_resposta => :ITEM_CRIME_LAVAGEM_DINHEIRO_TIPOLOGIAS);

    --
    last_id := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'crime_evasao_divisas', p_st_resposta => :ITEM_CRIME_EVASAO_DIVISAS);
    upsert_resposta_etapa_meio_evasao_divisa(last_id, :ITEM_CRIME_EVASAO_DIVISAS, :ITEM_CRIME_EVASAO_DIVISAS_MEIOS);
    upsert_resposta_etapa_pais(last_id, :ITEM_CRIME_EVASAO_DIVISAS, :ITEM_CRIME_EVASAO_DIVISAS_PAISES);

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'tentaculos', p_st_resposta => :ITEM_TENTACULOS);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'tentaculos_sei_ipj', p_ds_resposta => :ITEM_TENTACULOS_SEI_IPJ);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'tentaculos_qtd_noticias', p_qt_resposta => :ITEM_TENTACULOS_QTD_NOTICIAS);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'tentaculos_fraude', p_vl_resposta => TO_NUMBER(:ITEM_TENTACULOS_FRAUDE, '999G999G999G999G990D00'));
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P320_ID_OPERACAO, p_cd_campo => 'tentaculos_ipj_enviada_cban', p_st_resposta => :ITEM_TENTACULOS_IPJ_ENVIADA_CBAN);

    --
    -- marca flag ok
    UPDATE tb_operacao SET st_andamento_saved = 1 WHERE id_operacao = :P320_ID_OPERACAO;

EXCEPTION
    WHEN OTHERS THEN
        raise_application_error(-20002, 'Não foi possível salvar (em andamento 2/2): ' || SQLERRM);

END;