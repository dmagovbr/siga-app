DECLARE
    shuttle wwv_flow_global.VC_ARR2;
    last_id NUMBER;

BEGIN


    ----
    -- Medidas extraordinarias

    --
    -- comentado em atendimento à tarefa 3137 ana.acat
    --begin
    --    merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'utilizacao_rif')
    --    when matched then update set ST_RESPOSTA_ETAPA = :ITEM_UTILIZACAO_RIF, QT_RESPOSTA_ETAPA = :ITEM_UTILIZACAO_RIF_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P320_ID_OPERACAO, 'utilizacao_rif', :ITEM_UTILIZACAO_RIF, :ITEM_UTILIZACAO_RIF_QTD);
    --
    --    select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'utilizacao_rif';
    --    delete from TB_RESPOSTA_ETAPA_TIPO_RIF where ID_RESPOSTA_ETAPA_TIPO_RIF IN (select ID_RESPOSTA_ETAPA_TIPO_RIF from TB_RESPOSTA_ETAPA_TIPO_RIF tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'utilizacao_rif');
    --    if (:ITEM_UTILIZACAO_RIF = 1) then
    --        shuttle := apex_util.string_to_table(:ITEM_UTILIZACAO_RIF_TIPO);
    --        for i in 1..shuttle.count loop
    --            insert into TB_RESPOSTA_ETAPA_TIPO_RIF (ID_RESPOSTA_ETAPA_FK, ID_TIPO_RIF_FK) VALUES(last_id, shuttle(i));
    --        end loop;
    --    end if;
    --
    --    select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'utilizacao_rif';
    --    delete from TB_RESPOSTA_ETAPA_SIS_RIF where ID_RESPOSTA_ETAPA_SIS_RIF IN (select ID_RESPOSTA_ETAPA_SIS_RIF from TB_RESPOSTA_ETAPA_SIS_RIF tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'utilizacao_rif');
    --    if (:ITEM_UTILIZACAO_RIF = 1) then
    --        shuttle := apex_util.string_to_table(:ITEM_UTILIZACAO_RIF_IDS);
    --        for i in 1..shuttle.count loop
    --            insert into TB_RESPOSTA_ETAPA_SIS_RIF (ID_RESPOSTA_ETAPA_FK, ID_SIS_RIF_FK) VALUES(last_id, shuttle(i));
    --        end loop;
    --    end if;
    --    exception when no_data_found then null;
    --end;
    -- alterado para:
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'utilizacao_rif')
        WHEN MATCHED THEN
            UPDATE SET ST_RESPOSTA_ETAPA = :ITEM_UTILIZACAO_RIF
        WHEN NOT MATCHED THEN
            INSERT (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) VALUES (:P320_ID_OPERACAO, 'utilizacao_rif', :ITEM_UTILIZACAO_RIF);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;


    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'coop_policial_internacional')
        WHEN MATCHED THEN
            UPDATE SET ST_RESPOSTA_ETAPA = :ITEM_COOP_POLICIAL_INTERNACIONAL
        WHEN NOT MATCHED THEN
            INSERT (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) VALUES (:P320_ID_OPERACAO, 'coop_policial_internacional', :ITEM_COOP_POLICIAL_INTERNACIONAL);
        --
        SELECT id_resposta_etapa INTO last_id FROM tb_resposta_etapa WHERE ID_OPERACAO_FK = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'coop_policial_internacional';
        DELETE FROM TB_RESPOSTA_ETAPA_PAIS WHERE ID_RESPOSTA_ETAPA_PAIS IN (SELECT ID_RESPOSTA_ETAPA_PAIS FROM TB_RESPOSTA_ETAPA_PAIS tb LEFT JOIN TB_RESPOSTA_ETAPA tr ON tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK WHERE ID_OPERACAO_FK = :P320_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'coop_policial_internacional');
        IF (:ITEM_COOP_POLICIAL_INTERNACIONAL = 1) THEN
            shuttle := apex_util.string_to_table(:ITEM_COOP_POLICIAL_INTERNACIONAL_PAISES);
            FOR i IN 1..shuttle.count LOOP
                INSERT INTO TB_RESPOSTA_ETAPA_PAIS (ID_RESPOSTA_ETAPA_FK, ID_PAIS_FK) VALUES (last_id, shuttle(i));
            END LOOP;
        END IF;
        --
        SELECT id_resposta_etapa INTO last_id FROM tb_resposta_etapa WHERE ID_OPERACAO_FK = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'coop_policial_internacional';
        DELETE FROM TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO WHERE ID_RESPOSTA_ETAPA_ORGAO_COOPERACAO IN (SELECT ID_RESPOSTA_ETAPA_ORGAO_COOPERACAO FROM TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO tb LEFT JOIN TB_RESPOSTA_ETAPA tr ON tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK WHERE ID_OPERACAO_FK = :P320_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'coop_policial_internacional');
        IF (:ITEM_COOP_POLICIAL_INTERNACIONAL = 1) THEN
            shuttle := apex_util.string_to_table(:ITEM_COOP_POLICIAL_INTERNACIONAL_ORGAOS);
            FOR i IN 1..shuttle.count LOOP
                INSERT INTO TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO (ID_RESPOSTA_ETAPA_FK, ID_ORGAO_COOPERACAO_FK) VALUES (last_id, shuttle(i));
            END LOOP;
        END IF;
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'coop_juridica_internacional')
        WHEN MATCHED THEN
            UPDATE SET ST_RESPOSTA_ETAPA = :ITEM_COOP_JURIDICA_INTERNACIONAL
        WHEN NOT MATCHED THEN
            INSERT (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) VALUES (:P320_ID_OPERACAO, 'coop_juridica_internacional', :ITEM_COOP_JURIDICA_INTERNACIONAL);
        --
        SELECT id_resposta_etapa INTO last_id FROM tb_resposta_etapa WHERE ID_OPERACAO_FK = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'coop_juridica_internacional';
        DELETE FROM TB_RESPOSTA_ETAPA_PAIS WHERE ID_RESPOSTA_ETAPA_PAIS IN (SELECT ID_RESPOSTA_ETAPA_PAIS FROM TB_RESPOSTA_ETAPA_PAIS tb LEFT JOIN TB_RESPOSTA_ETAPA tr ON tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK WHERE ID_OPERACAO_FK = :P320_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'coop_juridica_internacional');
        IF (:ITEM_COOP_JURIDICA_INTERNACIONAL = 1) THEN
            shuttle := apex_util.string_to_table(:ITEM_COOP_JURIDICA_INTERNACIONAL_PAISES);
            FOR i IN 1..shuttle.count LOOP
                INSERT INTO TB_RESPOSTA_ETAPA_PAIS (ID_RESPOSTA_ETAPA_FK, ID_PAIS_FK) VALUES (last_id, shuttle(i));
            END LOOP;
        END IF;
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'geoprocessamento')
        WHEN MATCHED THEN
            UPDATE SET ST_RESPOSTA_ETAPA = :ITEM_GEOPROCESSAMENTO
        WHEN NOT MATCHED THEN
            INSERT (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) VALUES (:P320_ID_OPERACAO, 'geoprocessamento', :ITEM_GEOPROCESSAMENTO);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'material_genetico')
        WHEN MATCHED THEN
            UPDATE SET ST_RESPOSTA_ETAPA = :ITEM_MATERIAL_GENETICO
        WHEN NOT MATCHED THEN
            INSERT (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) VALUES (:P320_ID_OPERACAO, 'material_genetico', :ITEM_MATERIAL_GENETICO);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'auxilio_orgao_externo')
        WHEN MATCHED THEN
            UPDATE SET ST_RESPOSTA_ETAPA = :ITEM_AUXILIO_ORGAO_EXTERNO, OB_RESPOSTA_ETAPA = :ITEM_AUXILIO_ORGAO_EXTERNO_ORGAOS_OUTROS
        WHEN NOT MATCHED THEN
            INSERT (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA) VALUES (:P320_ID_OPERACAO, 'auxilio_orgao_externo', :ITEM_AUXILIO_ORGAO_EXTERNO, :ITEM_AUXILIO_ORGAO_EXTERNO_ORGAOS_OUTROS);
        --
        SELECT id_resposta_etapa INTO last_id FROM tb_resposta_etapa WHERE ID_OPERACAO_FK = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'auxilio_orgao_externo';
        DELETE FROM TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO WHERE ID_RESPOSTA_ETAPA_ORGAO_COOPERACAO IN (SELECT ID_RESPOSTA_ETAPA_ORGAO_COOPERACAO FROM TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO tb LEFT JOIN TB_RESPOSTA_ETAPA tr ON tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK WHERE ID_OPERACAO_FK = :P320_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'auxilio_orgao_externo');
        IF (:ITEM_AUXILIO_ORGAO_EXTERNO = 1) THEN
            shuttle := apex_util.string_to_table(:ITEM_AUXILIO_ORGAO_EXTERNO_ORGAOS);
            FOR i IN 1..shuttle.count LOOP
                INSERT INTO TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO (ID_RESPOSTA_ETAPA_FK, ID_ORGAO_COOPERACAO_FK) VALUES (last_id, shuttle(i));
            END LOOP;
        END IF;
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'colab_premiada')
        WHEN MATCHED THEN
            UPDATE SET ST_RESPOSTA_ETAPA = :ITEM_COLAB_PREMIADA, QT_RESPOSTA_ETAPA = :ITEM_COLAB_PREMIADA_QTD
        WHEN NOT MATCHED THEN
            INSERT (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) VALUES (:P320_ID_OPERACAO, 'colab_premiada', :ITEM_COLAB_PREMIADA, :ITEM_COLAB_PREMIADA_QTD);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'quebra_dados_telematicos')
        WHEN MATCHED THEN
            UPDATE SET ST_RESPOSTA_ETAPA = :ITEM_QUEBRA_DADOS_TELEMATICOS, QT_RESPOSTA_ETAPA = :ITEM_QUEBRA_DADOS_TELEMATICOS_QTD
        WHEN NOT MATCHED THEN
            INSERT (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) VALUES (:P320_ID_OPERACAO, 'quebra_dados_telematicos', :ITEM_QUEBRA_DADOS_TELEMATICOS, :ITEM_QUEBRA_DADOS_TELEMATICOS_QTD);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'quebra_dados_telefonicos')
        WHEN MATCHED THEN
            UPDATE SET ST_RESPOSTA_ETAPA = :ITEM_QUEBRA_DADOS_TELEFONICOS, QT_RESPOSTA_ETAPA = :ITEM_QUEBRA_DADOS_TELEFONICOS_QTD
        WHEN NOT MATCHED THEN
            INSERT (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) VALUES (:P320_ID_OPERACAO, 'quebra_dados_telefonicos', :ITEM_QUEBRA_DADOS_TELEFONICOS, :ITEM_QUEBRA_DADOS_TELEFONICOS_QTD);

        --
        -- comentado em atendimento à tarefa 3142 em 17/01/2025 ana.acat:
        --select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'quebra_dados_telefonicos';
        --delete from TB_RESPOSTA_ETAPA_SIS_SIS where ID_RESPOSTA_ETAPA_SIS_SIS IN (select ID_RESPOSTA_ETAPA_SIS_SIS from TB_RESPOSTA_ETAPA_SIS_SIS tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'quebra_dados_telefonicos');
        --if (:ITEM_QUEBRA_DADOS_TELEFONICOS = 1) then
        --    shuttle := apex_util.string_to_table(:ITEM_QUEBRA_DADOS_TELEFONICOS_IDSIS);
        --    for i in 1..shuttle.count loop
        --        insert into TB_RESPOSTA_ETAPA_SIS_SIS (ID_RESPOSTA_ETAPA_FK, ID_SIS_SIS_FK) VALUES(last_id, shuttle(i));
        --    end loop;
        --end if;

    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'quebra_sigilos_telefonicos')
        WHEN MATCHED THEN
            UPDATE SET ST_RESPOSTA_ETAPA = :ITEM_QUEBRA_SIGILOS_TELEFONICOS, QT_RESPOSTA_ETAPA = :ITEM_QUEBRA_SIGILOS_TELEFONICOS_QTD
        WHEN NOT MATCHED THEN
            INSERT (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) VALUES (:P320_ID_OPERACAO, 'quebra_sigilos_telefonicos', :ITEM_QUEBRA_SIGILOS_TELEFONICOS, :ITEM_QUEBRA_SIGILOS_TELEFONICOS_QTD);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'quebra_sigilo_financeiro')
        WHEN MATCHED THEN
            UPDATE SET ST_RESPOSTA_ETAPA = :ITEM_QUEBRA_SIGILO_FINANCEIRO, QT_RESPOSTA_ETAPA = :ITEM_QUEBRA_SIGILO_FINANCEIRO_QTD
        WHEN NOT MATCHED THEN
            INSERT (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) VALUES (:P320_ID_OPERACAO, 'quebra_sigilo_financeiro', :ITEM_QUEBRA_SIGILO_FINANCEIRO, :ITEM_QUEBRA_SIGILO_FINANCEIRO_QTD);
        --
        -- comentado em atendimento à tarefa 3143 em 17/01/2025 ana.acat
        --select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'quebra_sigilo_financeiro';
        --delete from TB_RESPOSTA_ETAPA_SIS_SIMBA where ID_RESPOSTA_ETAPA_SIS_SIMBA IN (select ID_RESPOSTA_ETAPA_SIS_SIMBA from TB_RESPOSTA_ETAPA_SIS_SIMBA tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'quebra_sigilo_financeiro');
        --if (:ITEM_QUEBRA_SIGILO_FINANCEIRO = 1) then
        --    shuttle := apex_util.string_to_table(:ITEM_QUEBRA_SIGILO_FINANCEIRO_IDSIMBA);
        --    for i in 1..shuttle.count loop
        --        insert into TB_RESPOSTA_ETAPA_SIS_SIMBA (ID_RESPOSTA_ETAPA_FK, ID_SIS_SIMBA_FK) VALUES(last_id, shuttle(i));
        --    end loop;
        --end if;

    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'quebra_sigilo_fiscal')
        WHEN MATCHED THEN
            UPDATE SET ST_RESPOSTA_ETAPA = :ITEM_QUEBRA_SIGILO_FISCAL, QT_RESPOSTA_ETAPA = :ITEM_QUEBRA_SIGILO_FISCAL_QTD
        WHEN NOT MATCHED THEN
            INSERT (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) VALUES (:P320_ID_OPERACAO, 'quebra_sigilo_fiscal', :ITEM_QUEBRA_SIGILO_FISCAL, :ITEM_QUEBRA_SIGILO_FISCAL_QTD);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'acao_controlada')
        WHEN MATCHED THEN
            UPDATE SET ST_RESPOSTA_ETAPA = :ITEM_ACAO_CONTROLADA, QT_RESPOSTA_ETAPA = :ITEM_ACAO_CONTROLADA_QTD
        WHEN NOT MATCHED THEN
            INSERT (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) VALUES (:P320_ID_OPERACAO, 'acao_controlada', :ITEM_ACAO_CONTROLADA, :ITEM_ACAO_CONTROLADA_QTD);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'captacao_ambiental')
        WHEN MATCHED THEN
            UPDATE SET ST_RESPOSTA_ETAPA = :ITEM_CAPTACAO_AMBIENTAL, QT_RESPOSTA_ETAPA = :ITEM_CAPTACAO_AMBIENTAL_QTD
        WHEN NOT MATCHED THEN
            INSERT (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) VALUES (:P320_ID_OPERACAO, 'captacao_ambiental', :ITEM_CAPTACAO_AMBIENTAL, :ITEM_CAPTACAO_AMBIENTAL_QTD);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P320_ID_OPERACAO AND cd_campo_etapa_fk = 'agente_infiltrado')
        WHEN MATCHED THEN
            UPDATE SET ST_RESPOSTA_ETAPA = :ITEM_AGENTE_INFILTRADO, QT_RESPOSTA_ETAPA = :ITEM_AGENTE_INFILTRADO_QTD
        WHEN NOT MATCHED THEN
            INSERT (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) VALUES (:P320_ID_OPERACAO, 'agente_infiltrado', :ITEM_AGENTE_INFILTRADO, :ITEM_AGENTE_INFILTRADO_QTD);
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;


EXCEPTION
    WHEN OTHERS THEN
        raise_application_error(-20002, 'Não foi possível salvar (em andamento 1/2): ' || SQLERRM);
END;