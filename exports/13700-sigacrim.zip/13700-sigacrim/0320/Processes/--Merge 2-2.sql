declare

    shuttle wwv_flow_global.vc_arr2;
    last_id number;

begin



    ----
    -- Informacoes gerais

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'crime_transnacional')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_CRIME_TRANSNACIONAL when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P320_ID_OPERACAO, 'crime_transnacional', :ITEM_CRIME_TRANSNACIONAL);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'crime_transnacional';
        delete from TB_RESPOSTA_ETAPA_PAIS where ID_RESPOSTA_ETAPA_PAIS IN (select ID_RESPOSTA_ETAPA_PAIS from TB_RESPOSTA_ETAPA_PAIS tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_transnacional');
        if (:ITEM_CRIME_TRANSNACIONAL = 1) then
            shuttle := apex_util.string_to_table(:ITEM_CRIME_TRANSNACIONAL_PAISES);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_PAIS (ID_RESPOSTA_ETAPA_FK, ID_PAIS_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
    exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'crime_interestadual')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_CRIME_INTERESTADUAL when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P320_ID_OPERACAO, 'crime_interestadual', :ITEM_CRIME_INTERESTADUAL);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'crime_interestadual';
        delete from TB_RESPOSTA_ETAPA_UF where ID_RESPOSTA_ETAPA_UF IN (select ID_RESPOSTA_ETAPA_UF from TB_RESPOSTA_ETAPA_UF tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_interestadual');
        if (:ITEM_CRIME_INTERESTADUAL = 1) then
            shuttle := apex_util.string_to_table(:ITEM_CRIME_INTERESTADUAL_UFS);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_UF (ID_RESPOSTA_ETAPA_FK, ID_UF_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
    exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'faccao_criminosa')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_FACCAO_CRIMINOSA, OB_RESPOSTA_ETAPA = :ITEM_FACCAO_CRIMINOSA_FACCOES_OUTRAS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA) values (:P320_ID_OPERACAO, 'faccao_criminosa', :ITEM_FACCAO_CRIMINOSA, :ITEM_FACCAO_CRIMINOSA_FACCOES_OUTRAS);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'faccao_criminosa';
        delete from TB_RESPOSTA_ETAPA_ORCRIM where ID_RESPOSTA_ETAPA_ORCRIM IN (select ID_RESPOSTA_ETAPA_ORCRIM from TB_RESPOSTA_ETAPA_ORCRIM tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'faccao_criminosa');
        if (:ITEM_FACCAO_CRIMINOSA = 1) then
            shuttle := apex_util.string_to_table(:ITEM_FACCAO_CRIMINOSA_FACCOES);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_ORCRIM (ID_RESPOSTA_ETAPA_FK, ID_ORCRIM_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
    exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'area_fronteira')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_AREA_FRONTEIRA when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P320_ID_OPERACAO, 'area_fronteira', :ITEM_AREA_FRONTEIRA);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'area_fronteira';
        delete from TB_RESPOSTA_ETAPA_PAIS where ID_RESPOSTA_ETAPA_PAIS IN (select ID_RESPOSTA_ETAPA_PAIS from TB_RESPOSTA_ETAPA_PAIS tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'area_fronteira');
        if (:ITEM_AREA_FRONTEIRA = 1) then
            shuttle := apex_util.string_to_table(:ITEM_AREA_FRONTEIRA_PAISES);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_PAIS (ID_RESPOSTA_ETAPA_FK, ID_PAIS_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
    exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'relacionada_milicia')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_RELACIONADA_MILICIA, OB_RESPOSTA_ETAPA = :ITEM_RELACIONADA_MILICIA_DETALHES when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA) values (:P320_ID_OPERACAO, 'relacionada_milicia', :ITEM_RELACIONADA_MILICIA, :ITEM_RELACIONADA_MILICIA_DETALHES);
    exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'terra_indigena')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_TERRA_INDIGENA, OB_RESPOSTA_ETAPA = :ITEM_TERRA_INDIGENA_TERRAS_OUTRAS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA) values (:P320_ID_OPERACAO, 'terra_indigena', :ITEM_TERRA_INDIGENA, :ITEM_TERRA_INDIGENA_TERRAS_OUTRAS);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'terra_indigena';
        delete from TB_RESPOSTA_ETAPA_TERRA_INDIGENA where ID_RESPOSTA_ETAPA_TERRA_INDIGENA IN (select ID_RESPOSTA_ETAPA_TERRA_INDIGENA from TB_RESPOSTA_ETAPA_TERRA_INDIGENA tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'terra_indigena');
        if (:ITEM_TERRA_INDIGENA = 1) then
            shuttle := apex_util.string_to_table(:ITEM_TERRA_INDIGENA_TERRAS);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_TERRA_INDIGENA (ID_RESPOSTA_ETAPA_FK, ID_TERRA_INDIGENA_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
    exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'envolve_unidade_conservacao')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_ENVOLVE_UNIDADE_CONSERVACAO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P320_ID_OPERACAO, 'envolve_unidade_conservacao', :ITEM_ENVOLVE_UNIDADE_CONSERVACAO);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'envolve_unidade_conservacao';
        delete from TB_RESPOSTA_ETAPA_UNIDADE_CONSERVACAO where ID_RESPOSTA_ETAPA_UNIDADE_CONSERVACAO IN (select ID_RESPOSTA_ETAPA_UNIDADE_CONSERVACAO from TB_RESPOSTA_ETAPA_UNIDADE_CONSERVACAO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'envolve_unidade_conservacao');
        if (:ITEM_ENVOLVE_UNIDADE_CONSERVACAO = 1) then
            shuttle := apex_util.string_to_table(:ITEM_ENVOLVE_UNIDADE_CONSERVACAO_UNIDADES);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_UNIDADE_CONSERVACAO (ID_RESPOSTA_ETAPA_FK, ID_UNIDADE_CONSERVACAO_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
    exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'envolve_area_prioritaria')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_ENVOLVE_AREA_PRIORITARIA, OB_RESPOSTA_ETAPA = :ITEM_ENVOLVE_AREA_PRIORITARIA_AREAS_OUTRAS, DS_RESPOSTA_ETAPA = :ITEM_ENVOLVE_AREA_PRIORITARIA_JUST when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA, DS_RESPOSTA_ETAPA) values (:P320_ID_OPERACAO, 'envolve_area_prioritaria', :ITEM_ENVOLVE_AREA_PRIORITARIA, :ITEM_ENVOLVE_AREA_PRIORITARIA_AREAS_OUTRAS, :ITEM_ENVOLVE_AREA_PRIORITARIA_JUST);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'envolve_area_prioritaria';
        delete from TB_RESPOSTA_ETAPA_AREA_GEOGRAFICA where ID_RESPOSTA_ETAPA_AREA_GEOGRAFICA IN (select ID_RESPOSTA_ETAPA_AREA_GEOGRAFICA from TB_RESPOSTA_ETAPA_AREA_GEOGRAFICA tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'envolve_area_prioritaria');
        if (:ITEM_ENVOLVE_AREA_PRIORITARIA = 1) then
            shuttle := apex_util.string_to_table(:ITEM_ENVOLVE_AREA_PRIORITARIA_AREAS);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_AREA_GEOGRAFICA (ID_RESPOSTA_ETAPA_FK, ID_AREA_GEOGRAFICA_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
    exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'criptoativo')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_CRIPTOATIVO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P320_ID_OPERACAO, 'criptoativo', :ITEM_CRIPTOATIVO);
    exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'prometheus_qtd_noticias')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_PROMETHEUS_QTD_NOTICIAS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P320_ID_OPERACAO, 'prometheus_qtd_noticias', :ITEM_PROMETHEUS_QTD_NOTICIAS);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'prometheus')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_PROMETHEUS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P320_ID_OPERACAO, 'prometheus', :ITEM_PROMETHEUS);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'prometheus';
        delete from TB_RESPOSTA_ETAPA_SIS_PROMETHEUS_MATERIA where ID_RESPOSTA_ETAPA_SIS_PROMETHEUS_MATERIA IN (select ID_RESPOSTA_ETAPA_SIS_PROMETHEUS_MATERIA from TB_RESPOSTA_ETAPA_SIS_PROMETHEUS_MATERIA tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'prometheus');
        if (:ITEM_PROMETHEUS = 1) then
            shuttle := apex_util.string_to_table(:ITEM_PROMETHEUS_MATERIA);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_SIS_PROMETHEUS_MATERIA (ID_RESPOSTA_ETAPA_FK, ID_SIS_PROMETHEUS_MATERIA_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'prometheus_formulario')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_PROMETHEUS_FORMULARIO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P320_ID_OPERACAO, 'prometheus_formulario', :ITEM_PROMETHEUS_FORMULARIO);
    exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'crime_lavagem_dinheiro')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_CRIME_LAVAGEM_DINHEIRO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P320_ID_OPERACAO, 'crime_lavagem_dinheiro', :ITEM_CRIME_LAVAGEM_DINHEIRO);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa
        where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'crime_lavagem_dinheiro';
        delete from TB_RESPOSTA_ETAPA_ATIVIDADE_ECONOMICA
        where ID_RESPOSTA_ETAPA_ATIVIDADE_ECONOMICA IN
              (select ID_RESPOSTA_ETAPA_ATIVIDADE_ECONOMICA from TB_RESPOSTA_ETAPA_ATIVIDADE_ECONOMICA tb
              left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK
               where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_lavagem_dinheiro');
        if (:ITEM_CRIME_LAVAGEM_DINHEIRO = 1) then
            shuttle := apex_util.string_to_table(:ITEM_CRIME_LAVAGEM_DINHEIRO_ATIVIDADES);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_ATIVIDADE_ECONOMICA (ID_RESPOSTA_ETAPA_FK, ID_ATIVIDADE_ECONOMICA_FK)
                VALUES(last_id, shuttle(i));
            end loop;
        end if;
    exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'crime_lavagem_dinheiro_atos')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_CRIME_LAVAGEM_DINHEIRO_ATOS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P320_ID_OPERACAO, 'crime_lavagem_dinheiro_atos', :ITEM_CRIME_LAVAGEM_DINHEIRO_ATOS);
    exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'crime_lavagem_dinheiro_tipologias')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_CRIME_LAVAGEM_DINHEIRO_TIPOLOGIAS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P320_ID_OPERACAO, 'crime_lavagem_dinheiro_tipologias', :ITEM_CRIME_LAVAGEM_DINHEIRO_TIPOLOGIAS);
    exception when no_data_found then null;
    end;

    /*
    20250319 https://tree.taiga.io/project/eduardoemi-sigacrim/task/3669
        begin
            merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'registro_especial')
            when matched then update set ST_RESPOSTA_ETAPA = :ITEM_REGISTRO_ESPECIAL
            when not matched then insert  (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P320_ID_OPERACAO, 'registro_especial', :ITEM_REGISTRO_ESPECIAL);
            --
            -- Comentado em atendimento à tarefa 3144 em 17/01/2025 ana.acat
            --select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'registro_especial';
            --delete from TB_RESPOSTA_ETAPA_RE where ID_RESPOSTA_ETAPA_FK IN (select id_resposta_etapa from tb_resposta_etapa where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'registro_especial');
            --if (:ITEM_REGISTRO_ESPECIAL = 1) then
            --    shuttle := apex_util.string_to_table(:ITEM_REGISTRO_ESPECIAL_NRS);
            --    for i in 1..shuttle.count loop
            --        insert into TB_RESPOSTA_ETAPA_RE
            --                    (ID_RESPOSTA_ETAPA_FK, NR_RE) VALUES
            --                    (last_id, shuttle(i));
            --    end loop;
            --end if;

        exception
            when no_data_found then
                raise_application_error(-20001, 'Nenhum dado encontrado para a operação ou campo etapa especificado.');
            when others then
                raise_application_error(-20002, 'Erro inesperado: ' || SQLERRM);
        end;
     */


    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'crime_evasao_divisas')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_CRIME_EVASAO_DIVISAS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P320_ID_OPERACAO, 'crime_evasao_divisas', :ITEM_CRIME_EVASAO_DIVISAS);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'crime_evasao_divisas';
        delete from TB_RESPOSTA_ETAPA_MEIO_EVASAO_DIVISA where ID_RESPOSTA_ETAPA_MEIO_EVASAO_DIVISA IN (select ID_RESPOSTA_ETAPA_MEIO_EVASAO_DIVISA from TB_RESPOSTA_ETAPA_MEIO_EVASAO_DIVISA tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_evasao_divisas');
        if (:ITEM_CRIME_EVASAO_DIVISAS = 1) then
            shuttle := apex_util.string_to_table(:ITEM_CRIME_EVASAO_DIVISAS_MEIOS);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_MEIO_EVASAO_DIVISA (ID_RESPOSTA_ETAPA_FK, ID_MEIO_EVASAO_DIVISA_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'crime_evasao_divisas';
        delete from TB_RESPOSTA_ETAPA_PAIS where ID_RESPOSTA_ETAPA_PAIS IN (select ID_RESPOSTA_ETAPA_PAIS from TB_RESPOSTA_ETAPA_PAIS tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P320_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_evasao_divisas');
        if (:ITEM_CRIME_EVASAO_DIVISAS = 1) then
            shuttle := apex_util.string_to_table(:ITEM_CRIME_EVASAO_DIVISAS_PAISES);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_PAIS (ID_RESPOSTA_ETAPA_FK, ID_PAIS_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
    exception when no_data_found then null;
    end;

    --
    begin

        --
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'tentaculos')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_TENTACULOS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P320_ID_OPERACAO, 'tentaculos', :ITEM_TENTACULOS);
        --
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'tentaculos_sei_ipj')
        when matched then update set DS_RESPOSTA_ETAPA = :ITEM_TENTACULOS_SEI_IPJ, DS_META_INFO = 'Nº do SEI que contenha a IPJ'
        when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, DS_RESPOSTA_ETAPA, DS_META_INFO) values (:P320_ID_OPERACAO, 'tentaculos_sei_ipj', :ITEM_TENTACULOS_SEI_IPJ, 'Nº do SEI que contenha a IPJ');
        --
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'tentaculos_qtd_noticias')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_TENTACULOS_QTD_NOTICIAS, DS_META_INFO = '' when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA, DS_META_INFO) values (:P320_ID_OPERACAO, 'tentaculos_qtd_noticias', to_number(:ITEM_TENTACULOS_QTD_NOTICIAS, '999G999G999G999G990D00'), '');
        --
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'tentaculos_fraude')
        when matched then update set VL_RESPOSTA_ETAPA = to_number(:ITEM_TENTACULOS_FRAUDE, '999G999G999G999G990D00'), DS_META_INFO = '' when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, VL_RESPOSTA_ETAPA, DS_META_INFO) values (:P320_ID_OPERACAO, 'tentaculos_fraude', to_number(:ITEM_TENTACULOS_FRAUDE, '999G999G999G999G990D00'), '');
        --
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P320_ID_OPERACAO and cd_campo_etapa_fk = 'tentaculos_ipj_enviada_cban')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_TENTACULOS_IPJ_ENVIADA_CBAN, DS_META_INFO = '' when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, DS_META_INFO) values (:P320_ID_OPERACAO, 'tentaculos_ipj_enviada_cban', to_number(:ITEM_TENTACULOS_IPJ_ENVIADA_CBAN, '999G999G999G999G990D00'), '');

    exception when no_data_found then null;
    end;


    -- marca flag ok
    update tb_operacao set ST_ANDAMENTO_SAVED = 1 where id_operacao = :P320_ID_OPERACAO;



exception when others then
    --raise_application_error(-20303, 'Não foi possível salvar agora, tente novamente em instantes. Caso o problema persista, por favor, entre em contato com o suporte.', false);
    raise_application_error(-20002, 'Não foi possível salvar (em andamento 2/2): ' || SQLERRM);
end;