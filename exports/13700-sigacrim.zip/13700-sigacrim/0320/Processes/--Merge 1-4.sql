DECLARE
    v_dummy number;
    v_last_id number;

BEGIN

    --
    v_dummy := upsert_resposta_etapa(:P320_ID_OPERACAO, 'utilizacao_rif', :ITEM_UTILIZACAO_RIF);
    v_dummy := upsert_resposta_etapa(:P320_ID_OPERACAO, 'geoprocessamento', :ITEM_GEOPROCESSAMENTO);
    v_dummy := upsert_resposta_etapa(:P320_ID_OPERACAO, 'material_genetico', :ITEM_MATERIAL_GENETICO);
    v_dummy := upsert_resposta_etapa(:P320_ID_OPERACAO, 'colab_premiada', :ITEM_COLAB_PREMIADA, :ITEM_COLAB_PREMIADA_QTD);

    --
    v_last_id := upsert_resposta_etapa(:P320_ID_OPERACAO, 'coop_policial_internacional', :ITEM_COOP_POLICIAL_INTERNACIONAL);
    upsert_resposta_etapa_pais(v_last_id, :ITEM_COOP_POLICIAL_INTERNACIONAL, :ITEM_COOP_POLICIAL_INTERNACIONAL_PAISES);
    upsert_resposta_etapa_orgao_cooperacao(v_last_id, :ITEM_COOP_POLICIAL_INTERNACIONAL, :ITEM_COOP_POLICIAL_INTERNACIONAL_ORGAOS);

    --
    v_last_id := upsert_resposta_etapa(:P320_ID_OPERACAO, 'coop_juridica_internacional', :ITEM_COOP_JURIDICA_INTERNACIONAL);
    upsert_resposta_etapa_pais(v_last_id, :ITEM_COOP_JURIDICA_INTERNACIONAL, :ITEM_COOP_JURIDICA_INTERNACIONAL_PAISES);

    --
    v_last_id := upsert_resposta_etapa(:P320_ID_OPERACAO, 'auxilio_orgao_externo', :ITEM_AUXILIO_ORGAO_EXTERNO, NULL, :ITEM_AUXILIO_ORGAO_EXTERNO_ORGAOS_OUTROS);
    upsert_resposta_etapa_orgao_cooperacao(v_last_id, :ITEM_AUXILIO_ORGAO_EXTERNO, :ITEM_AUXILIO_ORGAO_EXTERNO_ORGAOS);

EXCEPTION
    WHEN OTHERS THEN
        raise_application_error(-20002, 'Não foi possível salvar (em andamento - merge 1/4): ' || sqlerrm);
END;