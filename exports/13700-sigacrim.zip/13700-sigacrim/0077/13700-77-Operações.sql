SELECT id_operacao
     , id_etapa_operacao_fk
     , no_operacao
     , dt_inicio_operacao dataoperacao
     , areaatribuicao
     , siglaunidade
     , siglauf
     , ds_visibilidade
     , nr_inquerito_ipl
     , etapaoperacao

    -- em andamento
     , CASE WHEN id_etapa_operacao_fk <= 100 THEN
                '<a class="t-Button gestao t-Button--hot t-Button--danger" href="'
                    || apex_page.get_url(p_page=>78, p_items=>'P78_ID_OPERACAO', p_values => id_operacao) || '">Cancelar</a> '
            WHEN id_etapa_operacao_fk = 9999 THEN -- cancelada
                '<a class="t-Button gestao t-Button--hot t-Button--danger desativado" href="javascript:">Cancelada</a> '
    END AS acao

--
FROM vw_operacao_admin
WHERE 1 = 1

    --
  AND (
    :P77_SEM_PROPRIETARIO = 'N'
        OR
    (:P77_SEM_PROPRIETARIO = 'Y' AND NOT EXISTS( SELECT id_equipe FROM tb_equipe WHERE tb_equipe.id_operacao_fk = id_operacao AND cd_tipo_membro = 'Proprietário' ))
    )

    -- dma 202404 - filtra operacoes duplicadas
  AND (
    :P77_DUPLICADAS = 'N'
        OR
    (:P77_DUPLICADAS = 'Y' AND nr_inquerito_ipl IN ( SELECT nr_inquerito_ipl FROM vw_operacao_v2 GROUP BY nr_inquerito_ipl HAVING COUNT(*) > 1 ))
    )

  AND -- dma 20240219 - filtra operacoes com nome teste
    (
        :P77_TESTE = 'N'
            OR
        (:P77_TESTE = 'Y' AND LOWER(no_operacao) LIKE '%teste%')
        )

  AND -- 20250701
    (
        :P77_SEM_AREA = 'N'
            OR
        (:P77_SEM_AREA = 'Y' AND areaatribuicao IS NULL)
        )

  AND -- 20250701
    (
        :P77_SEM_UF = 'N'
            OR
        (:P77_SEM_UF = 'Y' AND siglauf IS NULL)
        )

  AND -- 20250701
    (
        :P77_SEM_UNIDADE = 'N'
            OR
        (:P77_SEM_UNIDADE = 'Y' AND siglaunidade IS NULL)
        )
