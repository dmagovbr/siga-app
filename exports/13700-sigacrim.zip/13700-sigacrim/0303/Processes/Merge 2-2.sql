declare

    shuttle wwv_flow_global.vc_arr2;
    last_id number;

begin



    ----
    -- Crimes direitos humanos

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'crime_odio')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_CRIME_ODIO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'crime_odio', :ITEM_CRIME_ODIO);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'crime_odio';
        delete from TB_RESPOSTA_ETAPA_MEIO_CRIME where ID_RESPOSTA_ETAPA_MEIO_CRIME IN (select ID_RESPOSTA_ETAPA_MEIO_CRIME from TB_RESPOSTA_ETAPA_MEIO_CRIME tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P303_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_odio');
        if (:ITEM_CRIME_ODIO = 1) then
            shuttle := apex_util.string_to_table(:ITEM_CRIME_ODIO_FORMA);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_MEIO_CRIME (ID_RESPOSTA_ETAPA_FK, ID_MEIO_CRIME_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'repressao_escravidao')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_REPRESSAO_ESCRAVIDAO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'repressao_escravidao', :ITEM_REPRESSAO_ESCRAVIDAO);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_assistencia_vitimas')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_RESGATE_ASSISTENCIA_VITIMAS, QT_RESPOSTA_ETAPA = :ITEM_RESGATE_ASSISTENCIA_VITIMAS_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'resgate_assistencia_vitimas', :ITEM_RESGATE_ASSISTENCIA_VITIMAS, :ITEM_RESGATE_ASSISTENCIA_VITIMAS_QTD);
        exception when no_data_found then null;
    end;


    ----
    -- Crimes previdenciarios

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'forca_tarefa_prev')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_FORCA_TAREFA_PREV when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'forca_tarefa_prev', :ITEM_FORCA_TAREFA_PREV);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'fraude_beneficios_prev')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_FRAUDE_BENEFICIOS_PREV, QT_RESPOSTA_ETAPA = :ITEM_FRAUDE_BENEFICIOS_PREV_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'fraude_beneficios_prev', :ITEM_FRAUDE_BENEFICIOS_PREV, :ITEM_FRAUDE_BENEFICIOS_PREV_QTD);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'fraude_beneficios_prev';
        delete from TB_RESPOSTA_ETAPA_TIPO_BENEFICIO where ID_RESPOSTA_ETAPA_TIPO_BENEFICIO IN (select ID_RESPOSTA_ETAPA_TIPO_BENEFICIO from TB_RESPOSTA_ETAPA_TIPO_BENEFICIO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P303_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'fraude_beneficios_prev');
        if (:ITEM_FRAUDE_BENEFICIOS_PREV = 1) then
            shuttle := apex_util.string_to_table(:ITEM_FRAUDE_BENEFICIOS_PREV_TIPOS);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_TIPO_BENEFICIO (ID_RESPOSTA_ETAPA_FK, ID_TIPO_BENEFICIO_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'fraude_custeio_prev')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_FRAUDE_CUSTEIO_PREV when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'fraude_custeio_prev', :ITEM_FRAUDE_CUSTEIO_PREV);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'apropriacao_indebita_prev')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_APROPRIACAO_INDEBITA_PREV when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'apropriacao_indebita_prev', :ITEM_APROPRIACAO_INDEBITA_PREV);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'sonegacao_prev')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_SONEGACAO_PREV when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'sonegacao_prev', :ITEM_SONEGACAO_PREV);
        exception when no_data_found then null;
    end;


    ----
    -- Desvio recursos publicos

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'vantagem_indevida_servidor')
        when matched then update set DS_META_INFO = 'Valor/Justificativa', ST_RESPOSTA_ETAPA = :ITEM_VANTAGEM_INDEVIDA_SERVIDOR, OB_RESPOSTA_ETAPA = :ITEM_VANTAGEM_INDEVIDA_SERVIDOR_JUST, VL_RESPOSTA_ETAPA = CAST(REPLACE(REPLACE(:ITEM_VANTAGEM_INDEVIDA_SERVIDOR_VALOR, 'R$', ''), '.', '') AS NUMBER(16, 2)) when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, DS_META_INFO, ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA, VL_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'vantagem_indevida_servidor', 'Valor/Justificativa', :ITEM_VANTAGEM_INDEVIDA_SERVIDOR, :ITEM_VANTAGEM_INDEVIDA_SERVIDOR_JUST, CAST(REPLACE(REPLACE(:ITEM_VANTAGEM_INDEVIDA_SERVIDOR_VALOR, 'R$', ''), '.', '') AS NUMBER(16, 2)));
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'prejuizos_evitados_uniao')
        when matched then update set DS_META_INFO = 'Valor/Justificativa', ST_RESPOSTA_ETAPA = :ITEM_PREJUIZOS_EVITADOS_UNIAO, OB_RESPOSTA_ETAPA = :ITEM_PREJUIZOS_EVITADOS_UNIAO_JUST, VL_RESPOSTA_ETAPA = CAST(REPLACE(REPLACE(:ITEM_PREJUIZOS_EVITADOS_UNIAO_VALOR, 'R$', ''), '.', '') AS NUMBER(16, 2)) when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, DS_META_INFO, ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA, VL_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'prejuizos_evitados_uniao', 'Valor/Justificativa', :ITEM_PREJUIZOS_EVITADOS_UNIAO, :ITEM_PREJUIZOS_EVITADOS_UNIAO_JUST, CAST(REPLACE(REPLACE(:ITEM_PREJUIZOS_EVITADOS_UNIAO_VALOR, 'R$', ''), '.', '') AS NUMBER(16, 2)));
        exception when no_data_found then null;
    end;


    ----
    -- Crime alta tecnologia

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'houve_crime_tecnologia')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_HOUVE_CRIME_TECNOLOGIA when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'houve_crime_tecnologia', :ITEM_HOUVE_CRIME_TECNOLOGIA);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'crime_alta_tecnologia_meio')
        when matched then update set OB_RESPOSTA_ETAPA = :ITEM_CRIME_ALTA_TECNOLOGIA_MEIO_OUTROS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, OB_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'crime_alta_tecnologia_meio', :ITEM_CRIME_ALTA_TECNOLOGIA_MEIO_OUTROS);
       --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'crime_alta_tecnologia_meio';
        delete from TB_RESPOSTA_ETAPA_MEIO_CRIME_TECNOLOGIA where ID_RESPOSTA_ETAPA_MEIO_CRIME_TECNOLOGIA IN (select ID_RESPOSTA_ETAPA_MEIO_CRIME_TECNOLOGIA from TB_RESPOSTA_ETAPA_MEIO_CRIME_TECNOLOGIA tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P303_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_alta_tecnologia_meio');
        shuttle := apex_util.string_to_table(:ITEM_CRIME_ALTA_TECNOLOGIA_MEIO);
        for i in 1..shuttle.count loop
        insert into TB_RESPOSTA_ETAPA_MEIO_CRIME_TECNOLOGIA (ID_RESPOSTA_ETAPA_FK, ID_MEIO_CRIME_TECNOLOGIA_FK) VALUES(last_id, shuttle(i));
        end loop;
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'impacto_causado')
        when matched then update set OB_RESPOSTA_ETAPA = :ITEM_IMPACTO_CAUSADO_OUTROS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, OB_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'impacto_causado', :ITEM_IMPACTO_CAUSADO_OUTROS);
       --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'impacto_causado';
        delete from TB_RESPOSTA_ETAPA_IMPACTO_CRIME_TECNOLOGIA where ID_RESPOSTA_ETAPA_IMPACTO_CRIME_TECNOLOGIA IN (select ID_RESPOSTA_ETAPA_IMPACTO_CRIME_TECNOLOGIA from TB_RESPOSTA_ETAPA_IMPACTO_CRIME_TECNOLOGIA tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P303_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'impacto_causado');
        shuttle := apex_util.string_to_table(:ITEM_IMPACTO_CAUSADO);
        for i in 1..shuttle.count loop
        insert into TB_RESPOSTA_ETAPA_IMPACTO_CRIME_TECNOLOGIA (ID_RESPOSTA_ETAPA_FK, ID_IMPACTO_CRIME_TECNOLOGIA_FK) VALUES(last_id, shuttle(i));
        end loop;
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'incidente_ciber')
        when matched then update set DS_META_INFO = 'Relatório', ST_RESPOSTA_ETAPA = :ITEM_INCIDENTE_CIBER, DS_RESPOSTA_ETAPA = :ITEM_INCIDENTE_CIBER_RELATORIO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, DS_META_INFO, ST_RESPOSTA_ETAPA, DS_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'incidente_ciber', 'Relatório', :ITEM_INCIDENTE_CIBER, :ITEM_INCIDENTE_CIBER_RELATORIO);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'relatorio_tecnico')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_RELATORIO_TECNICO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'relatorio_tecnico', :ITEM_RELATORIO_TECNICO);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'relatorio_tecnico_raat')
        when matched then update set DS_RESPOSTA_ETAPA = :ITEM_RELATORIO_TECNICO_RAAT, DS_META_INFO = '' when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, DS_RESPOSTA_ETAPA, DS_META_INFO) values (:P303_ID_OPERACAO, 'relatorio_tecnico_raat', to_number(:ITEM_RELATORIO_TECNICO_RAAT, '999G999G999G999G990D00'), '');
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'relatorio_tecnico_laudo')
        when matched then update set DS_RESPOSTA_ETAPA = :ITEM_RELATORIO_TECNICO_LAUDO, DS_META_INFO = '' when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, DS_RESPOSTA_ETAPA, DS_META_INFO) values (:P303_ID_OPERACAO, 'relatorio_tecnico_laudo', to_number(:ITEM_RELATORIO_TECNICO_LAUDO, '999G999G999G999G990D00'), '');
        exception when no_data_found then null;
    end;


    ----
    -- Crime ambiental

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'tipo_crime_ambiental')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_TIPO_CRIME_AMBIENTAL when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'tipo_crime_ambiental', :ITEM_TIPO_CRIME_AMBIENTAL);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'tipo_crime_ambiental';
        delete from TB_RESPOSTA_ETAPA_ESPECIE_AMBIENTAL where ID_RESPOSTA_ETAPA_ESPECIE_AMBIENTAL IN (select ID_RESPOSTA_ETAPA_ESPECIE_AMBIENTAL from TB_RESPOSTA_ETAPA_ESPECIE_AMBIENTAL tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P303_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'tipo_crime_ambiental');
        if (:ITEM_TIPO_CRIME_AMBIENTAL = 1) then
            shuttle := apex_util.string_to_table(:ITEM_TIPO_CRIME_AMBIENTAL_ESPECIES);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_ESPECIE_AMBIENTAL (ID_RESPOSTA_ETAPA_FK, ID_ESPECIE_AMBIENTAL_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'danos_ambientais')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_DANOS_AMBIENTAIS, VL_RESPOSTA_ETAPA = :ITEM_DANOS_AMBIENTAIS_AREA when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, VL_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'danos_ambientais', :ITEM_DANOS_AMBIENTAIS, :ITEM_DANOS_AMBIENTAIS_AREA);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'danos_ambientais';
        delete from TB_RESPOSTA_ETAPA_TIPO_ILICITO where ID_RESPOSTA_ETAPA_TIPO_ILICITO IN (select ID_RESPOSTA_ETAPA_TIPO_ILICITO from TB_RESPOSTA_ETAPA_TIPO_ILICITO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P303_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'danos_ambientais');
        if (:ITEM_DANOS_AMBIENTAIS = 1) then
            shuttle := apex_util.string_to_table(:ITEM_DANOS_AMBIENTAIS_ATIVIDADES);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_TIPO_ILICITO (ID_RESPOSTA_ETAPA_FK, ID_TIPO_ILICITO_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'danos_ambientais';
        delete from TB_RESPOSTA_ETAPA_UF where ID_RESPOSTA_ETAPA_UF IN (select ID_RESPOSTA_ETAPA_UF from TB_RESPOSTA_ETAPA_UF tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P303_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'danos_ambientais');
        if (:ITEM_DANOS_AMBIENTAIS = 1) then
            shuttle := apex_util.string_to_table(:ITEM_DANOS_AMBIENTAIS_UFS);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_UF (ID_RESPOSTA_ETAPA_FK, ID_UF_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'danos_ambientais';
        delete from TB_RESPOSTA_ETAPA_MUNICIPIO where ID_RESPOSTA_ETAPA_MUNICIPIO IN (select ID_RESPOSTA_ETAPA_MUNICIPIO from TB_RESPOSTA_ETAPA_MUNICIPIO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P303_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'danos_ambientais');
        if (:ITEM_DANOS_AMBIENTAIS = 1) then
            shuttle := apex_util.string_to_table(:ITEM_DANOS_AMBIENTAIS_MUNICIPIOS);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_MUNICIPIO (ID_RESPOSTA_ETAPA_FK, ID_MUNICIPIO_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'destruicao_maquinario')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_DESTRUICAO_MAQUINARIO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'destruicao_maquinario', :ITEM_DESTRUICAO_MAQUINARIO);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'desintrusao_invasores')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_DESINTRUSAO_INVASORES, QT_RESPOSTA_ETAPA = :ITEM_DESINTRUSAO_INVASORES_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'desintrusao_invasores', :ITEM_DESINTRUSAO_INVASORES, :ITEM_DESINTRUSAO_INVASORES_QTD);
        exception when no_data_found then null;
    end;


    ----
    -- Crimes de ódio Cibernético

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'identificado_material_abuso')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_IDENTIFICADO_MATERIAL_ABUSO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'identificado_material_abuso', :ITEM_IDENTIFICADO_MATERIAL_ABUSO);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'existe_especie_ciber')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_EXISTE_ESPECIE_CIBER when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'existe_especie_ciber', :ITEM_EXISTE_ESPECIE_CIBER);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'houve_incitacao_racismo')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_HOUVE_INCITACAO_RACISMO, DS_RESPOSTA_ETAPA = :ITEM_HOUVE_INCITACAO_RACISMO_LISTA when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, DS_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'houve_incitacao_racismo', :ITEM_HOUVE_INCITACAO_RACISMO, :ITEM_HOUVE_INCITACAO_RACISMO_LISTA);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'direcionado_pessoa_especifica')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_DIRECIONADO_PESSOA_ESPECIFICA, QT_RESPOSTA_ETAPA = :ITEM_DIRECIONADO_PESSOA_ESPECIFICA_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'direcionado_pessoa_especifica', :ITEM_DIRECIONADO_PESSOA_ESPECIFICA, :ITEM_DIRECIONADO_PESSOA_ESPECIFICA_QTD);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'houve_grupos_atacados')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_HOUVE_GRUPOS_ATACADOS, OB_RESPOSTA_ETAPA = :ITEM_HOUVE_GRUPOS_ATACADOS_OUTROS, DS_RESPOSTA_ETAPA = :ITEM_HOUVE_GRUPOS_ATACADOS_LISTA when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA, DS_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'houve_grupos_atacados', :ITEM_HOUVE_GRUPOS_ATACADOS, :ITEM_HOUVE_GRUPOS_ATACADOS_OUTROS, :ITEM_HOUVE_GRUPOS_ATACADOS_LISTA);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'houve_apreensao_menor')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_HOUVE_APREENSAO_MENOR when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'houve_apreensao_menor', :ITEM_HOUVE_APREENSAO_MENOR);
        exception when no_data_found then null;
    end;


    -- marca flag ok
    update tb_operacao set ST_SETORIAL_SAVED = 1 where id_operacao = :P303_ID_OPERACAO;

exception when others then
    raise_application_error(-20002, 'Não foi possível salvar (setorial 2/2): ' || SQLERRM);
end;