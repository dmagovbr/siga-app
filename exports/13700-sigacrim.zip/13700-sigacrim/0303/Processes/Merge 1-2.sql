declare

    shuttle wwv_flow_global.vc_arr2;
    last_id number;

begin



    ----
    -- Crimes ciberneticos

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'producao_material_abuso')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_PRODUCAO_MATERIAL_ABUSO, QT_RESPOSTA_ETAPA = :ITEM_PRODUCAO_MATERIAL_ABUSO_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'producao_material_abuso', :ITEM_PRODUCAO_MATERIAL_ABUSO, :ITEM_PRODUCAO_MATERIAL_ABUSO_QTD);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'sistema_rapina')
        when matched then update set DS_META_INFO = 'Caso', ST_RESPOSTA_ETAPA = :ITEM_SISTEMA_RAPINA, DS_RESPOSTA_ETAPA = :ITEM_SISTEMA_RAPINA_CASO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, DS_META_INFO, ST_RESPOSTA_ETAPA, DS_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'sistema_rapina', 'Caso', :ITEM_SISTEMA_RAPINA, :ITEM_SISTEMA_RAPINA_CASO);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'sistema_icse')
        when matched then update set DS_META_INFO = 'Série', ST_RESPOSTA_ETAPA = :ITEM_SISTEMA_ICSE, DS_RESPOSTA_ETAPA = :ITEM_SISTEMA_ICSE_SERIE when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, DS_META_INFO, ST_RESPOSTA_ETAPA, DS_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'sistema_icse', 'Série', :ITEM_SISTEMA_ICSE, :ITEM_SISTEMA_ICSE_SERIE);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'sistema_cps')
        when matched then update set DS_META_INFO = 'Campo identificador', ST_RESPOSTA_ETAPA = :ITEM_SISTEMA_CPS, DS_RESPOSTA_ETAPA = :ITEM_SISTEMA_CPS_IDENT when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, DS_META_INFO, ST_RESPOSTA_ETAPA, DS_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'sistema_cps', 'Campo identificador', :ITEM_SISTEMA_CPS, :ITEM_SISTEMA_CPS_IDENT);
        exception when no_data_found then null;
    end;


    ----
    -- Trafico drogas

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'houve_trafico_drogas')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_HOUVE_TRAFICO_DROGAS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'houve_trafico_drogas', :ITEM_HOUVE_TRAFICO_DROGAS);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'houve_trafico_drogas';
        delete from TB_RESPOSTA_ETAPA_MODAL_TRANSPORTE where ID_RESPOSTA_ETAPA_MODAL_TRANSPORTE IN (select ID_RESPOSTA_ETAPA_MODAL_TRANSPORTE from TB_RESPOSTA_ETAPA_MODAL_TRANSPORTE tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P303_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'houve_trafico_drogas');
        if (:ITEM_HOUVE_TRAFICO_DROGAS = 1) then
            shuttle := apex_util.string_to_table(:ITEM_HOUVE_TRAFICO_DROGAS_MODAIS);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_MODAL_TRANSPORTE (ID_RESPOSTA_ETAPA_FK, ID_MODAL_TRANSPORTE_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'erradicacao_cultivo_drogas')
        when matched then update set DS_META_INFO = 'Tipo/Pés (Qt)/Área (Vl)', ST_RESPOSTA_ETAPA = :ITEM_ERRADICACAO_CULTIVO_DROGAS, QT_RESPOSTA_ETAPA = :ITEM_ERRADICACAO_CULTIVO_DROGAS_PES, CD_RESPOSTA_ETAPA = :ITEM_ERRADICACAO_CULTIVO_DROGAS_TIPO, VL_RESPOSTA_ETAPA = :ITEM_ERRADICACAO_CULTIVO_DROGAS_AREA when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, DS_META_INFO, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA, CD_RESPOSTA_ETAPA, VL_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'erradicacao_cultivo_drogas', 'Tipo/Pés (Qt)/Área (Vl)', :ITEM_ERRADICACAO_CULTIVO_DROGAS, :ITEM_ERRADICACAO_CULTIVO_DROGAS_PES, :ITEM_ERRADICACAO_CULTIVO_DROGAS_TIPO, :ITEM_ERRADICACAO_CULTIVO_DROGAS_AREA);
        exception when no_data_found then null;
    end;


    ----
    -- Crimes Patrimonio

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'pessoa_feridas_mortas_investigacao')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_PESSOA_FERIDAS_MORTAS_INVESTIGACAO, QT_RESPOSTA_ETAPA = :ITEM_PESSOA_FERIDAS_MORTAS_INVESTIGACAO_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'pessoa_feridas_mortas_investigacao', :ITEM_PESSOA_FERIDAS_MORTAS_INVESTIGACAO, :ITEM_PESSOA_FERIDAS_MORTAS_INVESTIGACAO_QTD);
        exception when no_data_found then null;
    end;


    ----
    -- Crimes eleitorais

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'crime_estado_democratico_direito')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_CRIME_ESTADO_DEMOCRATICO_DIREITO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'crime_estado_democratico_direito', :ITEM_CRIME_ESTADO_DEMOCRATICO_DIREITO);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'desvio_recursos_fefc_partidario')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_DESVIO_RECURSOS_FEFC_PARTIDARIO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'desvio_recursos_fefc_partidario', :ITEM_DESVIO_RECURSOS_FEFC_PARTIDARIO);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'participacao_parente_assessor')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_PARTICIPACAO_PARENTE_ASSESSOR when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'participacao_parente_assessor', :ITEM_PARTICIPACAO_PARENTE_ASSESSOR);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'participacao_contador')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_PARTICIPACAO_CONTADOR when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'participacao_contador', :ITEM_PARTICIPACAO_CONTADOR);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'participacao_advogado')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_PARTICIPACAO_ADVOGADO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'participacao_advogado', :ITEM_PARTICIPACAO_ADVOGADO);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'investigado_filiado')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_INVESTIGADO_FILIADO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'investigado_filiado', :ITEM_INVESTIGADO_FILIADO);
        exception when no_data_found then null;
    end;


    ----
    -- Crimes financeiros

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'envolve_fundo_investimento')
        when matched then update set DS_META_INFO = 'Quais (obs)', ST_RESPOSTA_ETAPA = :ITEM_ENVOLVE_FUNDO_INVESTIMENTO, OB_RESPOSTA_ETAPA = :ITEM_ENVOLVE_FUNDO_INVESTIMENTO_QUAIS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, DS_META_INFO, ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'envolve_fundo_investimento', 'Quais (obs)', :ITEM_ENVOLVE_FUNDO_INVESTIMENTO, :ITEM_ENVOLVE_FUNDO_INVESTIMENTO_QUAIS);
        exception when no_data_found then null;
    end;


    ----
    -- Fraudes bancárias

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'identificacao_sites_grupos')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_IDENTIFICACAO_SITES_GRUPOS, OB_RESPOSTA_ETAPA = :ITEM_IDENTIFICACAO_SITES_GRUPOS_QUAIS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'identificacao_sites_grupos', :ITEM_IDENTIFICACAO_SITES_GRUPOS, :ITEM_IDENTIFICACAO_SITES_GRUPOS_QUAIS);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'identificacao_modus_operandi')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_IDENTIFICACAO_MODUS_OPERANDI, OB_RESPOSTA_ETAPA = :ITEM_IDENTIFICACAO_MODUS_OPERANDI_DESCRICAO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'identificacao_modus_operandi', :ITEM_IDENTIFICACAO_MODUS_OPERANDI, :ITEM_IDENTIFICACAO_MODUS_OPERANDI_DESCRICAO);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'inst_bancarias')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_INST_BANCARIAS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'inst_bancarias', :ITEM_INST_BANCARIAS);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'inst_bancarias';
        delete from TB_RESPOSTA_ETAPA_INSTITUICAO_BANCARIA where ID_RESPOSTA_ETAPA_INSTITUICAO_BANCARIA IN (select ID_RESPOSTA_ETAPA_INSTITUICAO_BANCARIA from TB_RESPOSTA_ETAPA_INSTITUICAO_BANCARIA tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P303_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'inst_bancarias');
        if (:ITEM_INST_BANCARIAS = 1) then
            shuttle := apex_util.string_to_table(:ITEM_INST_BANCARIAS_AFETADAS);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_INSTITUICAO_BANCARIA (ID_RESPOSTA_ETAPA_FK, ID_INSTITUICAO_BANCARIA_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'banco_dados_invadidos')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_BANCO_DADOS_INVADIDOS, OB_RESPOSTA_ETAPA = :ITEM_BANCO_DADOS_INVADIDOS_DESCRICAO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'banco_dados_invadidos', :ITEM_BANCO_DADOS_INVADIDOS, :ITEM_BANCO_DADOS_INVADIDOS_DESCRICAO);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'malware_bancario')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_MALWARE_BANCARIO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'malware_bancario', :ITEM_MALWARE_BANCARIO);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'malware_bancario_raat')
        when matched then update set DS_RESPOSTA_ETAPA = :ITEM_MALWARE_BANCARIO_RAAT, DS_META_INFO = '' when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, DS_RESPOSTA_ETAPA, DS_META_INFO) values (:P303_ID_OPERACAO, 'malware_bancario_raat',:ITEM_MALWARE_BANCARIO_RAAT,'');
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'malware_bancario_laudo')
        when matched then update set DS_RESPOSTA_ETAPA = :ITEM_MALWARE_BANCARIO_LAUDO, DS_META_INFO = '' when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, DS_RESPOSTA_ETAPA, DS_META_INFO) values (:P303_ID_OPERACAO, 'malware_bancario_laudo', to_number(:ITEM_MALWARE_BANCARIO_LAUDO, '999G999G999G999G990D00'), '');
        exception when no_data_found then null;
    end;


    ----
    -- Crimes fazendarios

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P303_ID_OPERACAO and cd_campo_etapa_fk = 'prejuizo_uniao')
        when matched then update set DS_META_INFO = 'Valor/Justificativa', ST_RESPOSTA_ETAPA = :ITEM_PREJUIZO_UNIAO, OB_RESPOSTA_ETAPA = :ITEM_PREJUIZO_UNIAO_JUST, VL_RESPOSTA_ETAPA = CAST(REPLACE(REPLACE(:ITEM_PREJUIZO_UNIAO_VALOR, 'R$', ''), '.', '') AS NUMBER(16, 2)) when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, DS_META_INFO, ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA, VL_RESPOSTA_ETAPA) values (:P303_ID_OPERACAO, 'prejuizo_uniao', 'Valor/Justificativa', :ITEM_PREJUIZO_UNIAO, :ITEM_PREJUIZO_UNIAO_JUST, CAST(REPLACE(REPLACE(:ITEM_PREJUIZO_UNIAO_VALOR, 'R$', ''), '.', '') AS NUMBER(16, 2)));
        exception when no_data_found then null;
    end;

exception when others then
  raise_application_error(-20002, 'Não foi possível salvar (setorial 1/2): ' || SQLERRM);

end;
