declare 

    general_id number; 

begin 



    ---- 
    -- Crimes ciberneticos

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA into :ITEM_PRODUCAO_MATERIAL_ABUSO, :ITEM_PRODUCAO_MATERIAL_ABUSO_QTD from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'producao_material_abuso'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, DS_RESPOSTA_ETAPA into :ITEM_SISTEMA_RAPINA, :ITEM_SISTEMA_RAPINA_CASO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'sistema_rapina'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, DS_RESPOSTA_ETAPA into :ITEM_SISTEMA_ICSE, :ITEM_SISTEMA_ICSE_SERIE from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'sistema_icse'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, DS_RESPOSTA_ETAPA into :ITEM_SISTEMA_CPS, :ITEM_SISTEMA_CPS_IDENT from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'sistema_cps'; 
        exception when no_data_found then null; 
    end; 


    ---- 
    -- Trafico drogas

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_HOUVE_TRAFICO_DROGAS from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'houve_trafico_drogas'; 
        select listagg(ID_MODAL_TRANSPORTE_FK, ':') into :ITEM_HOUVE_TRAFICO_DROGAS_MODAIS from TB_RESPOSTA_ETAPA_MODAL_TRANSPORTE tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'houve_trafico_drogas'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA, CD_RESPOSTA_ETAPA, VL_RESPOSTA_ETAPA into :ITEM_ERRADICACAO_CULTIVO_DROGAS, :ITEM_ERRADICACAO_CULTIVO_DROGAS_PES, :ITEM_ERRADICACAO_CULTIVO_DROGAS_TIPO, :ITEM_ERRADICACAO_CULTIVO_DROGAS_AREA from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'erradicacao_cultivo_drogas'; 
        exception when no_data_found then null; 
    end; 


    ---- 
    -- Crimes Patrimonio

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA into :ITEM_PESSOA_FERIDAS_MORTAS_INVESTIGACAO, :ITEM_PESSOA_FERIDAS_MORTAS_INVESTIGACAO_QTD from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'pessoa_feridas_mortas_investigacao'; 
        exception when no_data_found then null; 
    end; 


    ---- 
    -- Crimes eleitorais

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_CRIME_ESTADO_DEMOCRATICO_DIREITO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_estado_democratico_direito'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_DESVIO_RECURSOS_FEFC_PARTIDARIO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'desvio_recursos_fefc_partidario'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_PARTICIPACAO_PARENTE_ASSESSOR from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'participacao_parente_assessor'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_PARTICIPACAO_CONTADOR from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'participacao_contador'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_PARTICIPACAO_ADVOGADO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'participacao_advogado'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_INVESTIGADO_FILIADO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'investigado_filiado'; 
        exception when no_data_found then null; 
    end; 


    ---- 
    -- Crimes financeiros

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA into :ITEM_ENVOLVE_FUNDO_INVESTIMENTO, :ITEM_ENVOLVE_FUNDO_INVESTIMENTO_QUAIS from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'envolve_fundo_investimento'; 
        exception when no_data_found then null; 
    end; 


    ---- 
    -- Fraudes bancárias

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA into :ITEM_IDENTIFICACAO_SITES_GRUPOS, :ITEM_IDENTIFICACAO_SITES_GRUPOS_QUAIS from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'identificacao_sites_grupos'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA into :ITEM_IDENTIFICACAO_MODUS_OPERANDI, :ITEM_IDENTIFICACAO_MODUS_OPERANDI_DESCRICAO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'identificacao_modus_operandi'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_INST_BANCARIAS from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'inst_bancarias'; 
        select listagg(ID_INSTITUICAO_BANCARIA_FK, ':') into :ITEM_INST_BANCARIAS_AFETADAS from TB_RESPOSTA_ETAPA_INSTITUICAO_BANCARIA tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'inst_bancarias'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA into :ITEM_BANCO_DADOS_INVADIDOS, :ITEM_BANCO_DADOS_INVADIDOS_DESCRICAO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'banco_dados_invadidos'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_MALWARE_BANCARIO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'malware_bancario'; 
        select DS_RESPOSTA_ETAPA into :ITEM_MALWARE_BANCARIO_RAAT from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'malware_bancario_raat'; 
        select DS_RESPOSTA_ETAPA into :ITEM_MALWARE_BANCARIO_LAUDO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'malware_bancario_laudo'; 
        exception when no_data_found then null; 
    end; 


    ---- 
    -- Crimes fazendarios

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA, TO_CHAR(VL_RESPOSTA_ETAPA, '999G999G999G999G990D00') into :ITEM_PREJUIZO_UNIAO, :ITEM_PREJUIZO_UNIAO_JUST, :ITEM_PREJUIZO_UNIAO_VALOR from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'prejuizo_uniao'; 
        exception when no_data_found then null; 
    end; 


    ---- 
    -- Crimes direitos humanos

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_CRIME_ODIO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_odio'; 
        select listagg(ID_MEIO_CRIME_FK, ':') into :ITEM_CRIME_ODIO_FORMA from TB_RESPOSTA_ETAPA_MEIO_CRIME tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_odio'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_REPRESSAO_ESCRAVIDAO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'repressao_escravidao'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA into :ITEM_RESGATE_ASSISTENCIA_VITIMAS, :ITEM_RESGATE_ASSISTENCIA_VITIMAS_QTD from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'resgate_assistencia_vitimas'; 
        exception when no_data_found then null; 
    end; 


    ---- 
    -- Crimes previdenciarios

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_FORCA_TAREFA_PREV from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'forca_tarefa_prev'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA into :ITEM_FRAUDE_BENEFICIOS_PREV, :ITEM_FRAUDE_BENEFICIOS_PREV_QTD from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'fraude_beneficios_prev'; 
        select listagg(ID_TIPO_BENEFICIO_FK, ':') into :ITEM_FRAUDE_BENEFICIOS_PREV_TIPOS from TB_RESPOSTA_ETAPA_TIPO_BENEFICIO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'fraude_beneficios_prev'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_FRAUDE_CUSTEIO_PREV from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'fraude_custeio_prev'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_APROPRIACAO_INDEBITA_PREV from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'apropriacao_indebita_prev'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_SONEGACAO_PREV from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'sonegacao_prev'; 
        exception when no_data_found then null; 
    end; 


    ---- 
    -- Desvio recursos publicos

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA, TO_CHAR(VL_RESPOSTA_ETAPA, '999G999G999G999G990D00') into :ITEM_VANTAGEM_INDEVIDA_SERVIDOR, :ITEM_VANTAGEM_INDEVIDA_SERVIDOR_JUST, :ITEM_VANTAGEM_INDEVIDA_SERVIDOR_VALOR from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'vantagem_indevida_servidor'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA, TO_CHAR(VL_RESPOSTA_ETAPA, '999G999G999G999G990D00') into :ITEM_PREJUIZOS_EVITADOS_UNIAO, :ITEM_PREJUIZOS_EVITADOS_UNIAO_JUST, :ITEM_PREJUIZOS_EVITADOS_UNIAO_VALOR from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'prejuizos_evitados_uniao'; 
        exception when no_data_found then null; 
    end; 


    ---- 
    -- Crime alta tecnologia

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_HOUVE_CRIME_TECNOLOGIA from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'houve_crime_tecnologia'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select OB_RESPOSTA_ETAPA into :ITEM_CRIME_ALTA_TECNOLOGIA_MEIO_OUTROS from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_alta_tecnologia_meio'; 
        select listagg(ID_MEIO_CRIME_TECNOLOGIA_FK, ':') into :ITEM_CRIME_ALTA_TECNOLOGIA_MEIO from TB_RESPOSTA_ETAPA_MEIO_CRIME_TECNOLOGIA tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'crime_alta_tecnologia_meio'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select OB_RESPOSTA_ETAPA into :ITEM_IMPACTO_CAUSADO_OUTROS from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'impacto_causado'; 
        select listagg(ID_IMPACTO_CRIME_TECNOLOGIA_FK, ':') into :ITEM_IMPACTO_CAUSADO from TB_RESPOSTA_ETAPA_IMPACTO_CRIME_TECNOLOGIA tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'impacto_causado'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, DS_RESPOSTA_ETAPA into :ITEM_INCIDENTE_CIBER, :ITEM_INCIDENTE_CIBER_RELATORIO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'incidente_ciber'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_RELATORIO_TECNICO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'relatorio_tecnico'; 
        select DS_RESPOSTA_ETAPA into :ITEM_RELATORIO_TECNICO_RAAT from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'relatorio_tecnico_raat'; 
        select DS_RESPOSTA_ETAPA into :ITEM_RELATORIO_TECNICO_LAUDO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'relatorio_tecnico_laudo'; 
        exception when no_data_found then null; 
    end; 


    ---- 
    -- Crime ambiental

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_TIPO_CRIME_AMBIENTAL from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'tipo_crime_ambiental'; 
        select listagg(ID_ESPECIE_AMBIENTAL_FK, ':') into :ITEM_TIPO_CRIME_AMBIENTAL_ESPECIES from TB_RESPOSTA_ETAPA_ESPECIE_AMBIENTAL tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'tipo_crime_ambiental'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, VL_RESPOSTA_ETAPA into :ITEM_DANOS_AMBIENTAIS, :ITEM_DANOS_AMBIENTAIS_AREA from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'danos_ambientais'; 
        select listagg(ID_TIPO_ILICITO_FK, ':') into :ITEM_DANOS_AMBIENTAIS_ATIVIDADES from TB_RESPOSTA_ETAPA_TIPO_ILICITO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'danos_ambientais'; 
        select listagg(ID_UF_FK, ':') into :ITEM_DANOS_AMBIENTAIS_UFS from TB_RESPOSTA_ETAPA_UF tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'danos_ambientais'; 
        select listagg(ID_MUNICIPIO_FK, ':') into :ITEM_DANOS_AMBIENTAIS_MUNICIPIOS from TB_RESPOSTA_ETAPA_MUNICIPIO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'danos_ambientais'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_DESTRUICAO_MAQUINARIO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'destruicao_maquinario'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA into :ITEM_DESINTRUSAO_INVASORES, :ITEM_DESINTRUSAO_INVASORES_QTD from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'desintrusao_invasores'; 
        exception when no_data_found then null; 
    end; 


    ---- 
    -- Crimes de ódio Cibernético

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_IDENTIFICADO_MATERIAL_ABUSO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'identificado_material_abuso'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_EXISTE_ESPECIE_CIBER from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'existe_especie_ciber'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, DS_RESPOSTA_ETAPA into :ITEM_HOUVE_INCITACAO_RACISMO, :ITEM_HOUVE_INCITACAO_RACISMO_LISTA from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'houve_incitacao_racismo'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA into :ITEM_DIRECIONADO_PESSOA_ESPECIFICA, :ITEM_DIRECIONADO_PESSOA_ESPECIFICA_QTD from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'direcionado_pessoa_especifica'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA, DS_RESPOSTA_ETAPA into :ITEM_HOUVE_GRUPOS_ATACADOS, :ITEM_HOUVE_GRUPOS_ATACADOS_OUTROS, :ITEM_HOUVE_GRUPOS_ATACADOS_LISTA from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'houve_grupos_atacados'; 
        exception when no_data_found then null; 
    end; 

    -- 
    begin 
        select ST_RESPOSTA_ETAPA into :ITEM_HOUVE_APREENSAO_MENOR from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P310_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'houve_apreensao_menor'; 
        exception when no_data_found then null; 
    end; 


exception when others then

     raise_application_error(
        -20303,
        'Erro interno: ' || SQLERRM || ' - Código: ' || SQLCODE || ' - Backtrace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,
        false
    );

end;