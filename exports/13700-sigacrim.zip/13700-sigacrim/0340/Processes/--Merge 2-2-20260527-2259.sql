declare

    shuttle wwv_flow_global.vc_arr2;
    last_id number;

begin



    ----
    -- Deflagracao 2/2

    begin
    merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima')
    when matched then update set ST_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA, OB_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_CRIME_OUTROS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO,'resgate_vitima',:ITEM_RESGATE_VITIMA,:ITEM_RESGATE_VITIMA_CRIME_OUTROS);
    --
    select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima';
    --
    delete from TB_RESPOSTA_ETAPA_RESGATE_VITIMA_CRIME where ID_RESPOSTA_ETAPA_RESGATE_VITIMA_CRIME in (select ID_RESPOSTA_ETAPA_RESGATE_VITIMA_CRIME from TB_RESPOSTA_ETAPA_RESGATE_VITIMA_CRIME tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P340_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'resgate_vitima');
    --
    if (:ITEM_RESGATE_VITIMA = 1) then
        shuttle := apex_util.string_to_table(:ITEM_RESGATE_VITIMA_CRIMES);
        for i in 1..shuttle.count loop
            insert into TB_RESPOSTA_ETAPA_RESGATE_VITIMA_CRIME (
                ID_RESPOSTA_ETAPA_FK,
                ID_TIPO_CRIME_VITIMA_FK
            )
            values (
                last_id,
                shuttle(i)
            );
        end loop;
    end if;
    exception
    when no_data_found then null;
    end;

    --
    begin
    merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'identificacao_vitima')
    when matched then update set ST_RESPOSTA_ETAPA = :ITEM_IDENTIFICACAO_VITIMA, OB_RESPOSTA_ETAPA = :ITEM_IDENTIFICACAO_VITIMA_CRIME_OUTROS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, OB_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO,'identificacao_vitima',:ITEM_IDENTIFICACAO_VITIMA,:ITEM_IDENTIFICACAO_VITIMA_CRIME_OUTROS);
    --
    select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'identificacao_vitima';
    --
    delete from TB_RESPOSTA_ETAPA_IDENTIFICACAO_VITIMA_CRIME where ID_RESPOSTA_ETAPA_IDENTIFICACAO_VITIMA_CRIME in (select ID_RESPOSTA_ETAPA_IDENTIFICACAO_VITIMA_CRIME from TB_RESPOSTA_ETAPA_IDENTIFICACAO_VITIMA_CRIME tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P340_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'identificacao_vitima');
    --
    if (:ITEM_IDENTIFICACAO_VITIMA = 1) then
        shuttle := apex_util.string_to_table(:ITEM_IDENTIFICACAO_VITIMA_CRIME);
        for i in 1..shuttle.count loop
            insert into TB_RESPOSTA_ETAPA_IDENTIFICACAO_VITIMA_CRIME (
                ID_RESPOSTA_ETAPA_FK,
                ID_TIPO_CRIME_VITIMA_FK
            )
            values (
                last_id,
                shuttle(i)
            );
        end loop;
    end if;
    exception
    when no_data_found then null;
    end;

    --
    /*
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_trafico_pessoas')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_trafico_pessoas', :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_trafico_pessoas_qtd_homens')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_HOMENS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_trafico_pessoas_qtd_homens', :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_HOMENS);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_trafico_pessoas_qtd_mulheres')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_MULHERES when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_trafico_pessoas_qtd_mulheres', :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_MULHERES);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_trafico_pessoas_qtd_cri_masc')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_CRI_MASC when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_trafico_pessoas_qtd_cri_masc', :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_CRI_MASC);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_trafico_pessoas_qtd_cri_fem')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_CRI_FEM when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_trafico_pessoas_qtd_cri_fem', :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_CRI_FEM);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_trafico_pessoas_qtd_br_masc')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_BR_MASC when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_trafico_pessoas_qtd_br_masc', :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_BR_MASC);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_trafico_pessoas_qtd_br_fem')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_BR_FEM when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_trafico_pessoas_qtd_br_fem', :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_BR_FEM);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_trafico_pessoas_qtd_est_masc')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_EST_MASC when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_trafico_pessoas_qtd_est_masc', :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_EST_MASC);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_trafico_pessoas_qtd_est_fem')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_EST_FEM when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_trafico_pessoas_qtd_est_fem', :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_EST_FEM);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_trafico_pessoas_qtd_nao_hetero')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_NAO_HETERO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_trafico_pessoas_qtd_nao_hetero', :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_NAO_HETERO);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_migracao_ilegal')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_migracao_ilegal', :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_migracao_ilegal_qtd_homens')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_HOMENS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_migracao_ilegal_qtd_homens', :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_HOMENS);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_migracao_ilegal_qtd_mulheres')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_MULHERES when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_migracao_ilegal_qtd_mulheres', :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_MULHERES);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_migracao_ilegal_qtd_cri_masc')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_CRI_MASC when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_migracao_ilegal_qtd_cri_masc', :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_CRI_MASC);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_migracao_ilegal_qtd_cri_fem')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_CRI_FEM when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_migracao_ilegal_qtd_cri_fem', :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_CRI_FEM);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_migracao_ilegal_qtd_br_masc')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_BR_MASC when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_migracao_ilegal_qtd_br_masc', :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_BR_MASC);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_migracao_ilegal_qtd_br_fem')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_BR_FEM when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_migracao_ilegal_qtd_br_fem', :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_BR_FEM);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_migracao_ilegal_qtd_est_masc')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_EST_MASC when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_migracao_ilegal_qtd_est_masc', :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_EST_MASC);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_migracao_ilegal_qtd_est_fem')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_EST_FEM when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_migracao_ilegal_qtd_est_fem', :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_EST_FEM);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_migracao_ilegal_qtd_nao_hetero')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_NAO_HETERO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_migracao_ilegal_qtd_nao_hetero', :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_NAO_HETERO);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_ordem_trabalho')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_ordem_trabalho', :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_ordem_trabalho_qtd_homens')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_HOMENS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_ordem_trabalho_qtd_homens', :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_HOMENS);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_ordem_trabalho_qtd_mulheres')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_MULHERES when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_ordem_trabalho_qtd_mulheres', :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_MULHERES);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_ordem_trabalho_qtd_cri_masc')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_CRI_MASC when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_ordem_trabalho_qtd_cri_masc', :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_CRI_MASC);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_ordem_trabalho_qtd_cri_fem')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_CRI_FEM when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_ordem_trabalho_qtd_cri_fem', :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_CRI_FEM);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_ordem_trabalho_qtd_br_masc')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_BR_MASC when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_ordem_trabalho_qtd_br_masc', :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_BR_MASC);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_ordem_trabalho_qtd_br_fem')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_BR_FEM when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_ordem_trabalho_qtd_br_fem', :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_BR_FEM);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_ordem_trabalho_qtd_est_masc')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_EST_MASC when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_ordem_trabalho_qtd_est_masc', :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_EST_MASC);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_ordem_trabalho_qtd_est_fem')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_EST_FEM when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_ordem_trabalho_qtd_est_fem', :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_EST_FEM);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_ordem_trabalho_qtd_nao_hetero')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_NAO_HETERO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_ordem_trabalho_qtd_nao_hetero', :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_NAO_HETERO);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_grupo_exterminio')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_grupo_exterminio', :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_grupo_exterminio_qtd_homens')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_HOMENS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_grupo_exterminio_qtd_homens', :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_HOMENS);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_grupo_exterminio_qtd_mulheres')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_MULHERES when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_grupo_exterminio_qtd_mulheres', :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_MULHERES);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_grupo_exterminio_qtd_cri_masc')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_CRI_MASC when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_grupo_exterminio_qtd_cri_masc', :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_CRI_MASC);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_grupo_exterminio_qtd_cri_fem')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_CRI_FEM when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_grupo_exterminio_qtd_cri_fem', :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_CRI_FEM);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_grupo_exterminio_qtd_br_masc')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_BR_MASC when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_grupo_exterminio_qtd_br_masc', :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_BR_MASC);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_grupo_exterminio_qtd_br_fem')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_BR_FEM when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_grupo_exterminio_qtd_br_fem', :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_BR_FEM);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_grupo_exterminio_qtd_est_masc')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_EST_MASC when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_grupo_exterminio_qtd_est_masc', :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_EST_MASC);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_grupo_exterminio_qtd_est_fem')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_EST_FEM when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_grupo_exterminio_qtd_est_fem', :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_EST_FEM);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_grupo_exterminio_qtd_nao_hetero')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_NAO_HETERO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_grupo_exterminio_qtd_nao_hetero', :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_NAO_HETERO);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'vitima_abuso')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_VITIMA_ABUSO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'vitima_abuso', :ITEM_VITIMA_ABUSO);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'vitima_abuso_qtd_11_masc')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_VITIMA_ABUSO_QTD_11_MASC when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'vitima_abuso_qtd_11_masc', :ITEM_VITIMA_ABUSO_QTD_11_MASC);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'vitima_abuso_qtd_11_fem')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_VITIMA_ABUSO_QTD_11_FEM when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'vitima_abuso_qtd_11_fem', :ITEM_VITIMA_ABUSO_QTD_11_FEM);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'vitima_abuso_qtd_17_masc')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_VITIMA_ABUSO_QTD_17_MASC when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'vitima_abuso_qtd_17_masc', :ITEM_VITIMA_ABUSO_QTD_17_MASC);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'vitima_abuso_qtd_17_fem')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_VITIMA_ABUSO_QTD_17_FEM when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'vitima_abuso_qtd_17_fem', :ITEM_VITIMA_ABUSO_QTD_17_FEM);
        exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima', :ITEM_RESGATE_VITIMA);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_qtd_11_masc')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_QTD_11_MASC when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_qtd_11_masc', :ITEM_RESGATE_VITIMA_QTD_11_MASC);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_qtd_11_fem')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_QTD_11_FEM when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_qtd_11_fem', :ITEM_RESGATE_VITIMA_QTD_11_FEM);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_qtd_17_masc')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_QTD_17_MASC when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_qtd_17_masc', :ITEM_RESGATE_VITIMA_QTD_17_MASC);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'resgate_vitima_qtd_17_fem')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_RESGATE_VITIMA_QTD_17_FEM when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'resgate_vitima_qtd_17_fem', :ITEM_RESGATE_VITIMA_QTD_17_FEM);
        exception when no_data_found then null;
    end;
    */


    -- marca flag ok
    update tb_operacao set ST_DEFLAGRACAO_SAVED = 1 where id_operacao = :P340_ID_OPERACAO;

exception when others then
    raise_application_error(-20002, 'Não foi possível salvar (deflagração 2/2): ' || SQLERRM);
end;