DECLARE
    v_dummy number;
    last_id number;

BEGIN

    ----
    -- Deflagracao 1/2

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'busca_domiciliar', p_st_resposta => :ITEM_BUSCA_DOMICILIAR, p_qt_resposta => :ITEM_BUSCA_DOMICILIAR_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'busca_domiciliar_enderecos', p_qt_resposta => :ITEM_BUSCA_DOMICILIAR_ENDERECOS);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'busca_domiciliar_qtd_expedida', p_qt_resposta => :ITEM_BUSCA_DOMICILIAR_QTD_EXPEDIDA);

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'prisao_temporaria', p_st_resposta => :ITEM_PRISAO_TEMPORARIA, p_qt_resposta => :ITEM_PRISAO_TEMPORARIA_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'prisao_temporaria_qtd_expedida', p_qt_resposta => :ITEM_PRISAO_TEMPORARIA_QTD_EXPEDIDA);

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'prisao_preventiva', p_st_resposta => :ITEM_PRISAO_PREVENTIVA, p_qt_resposta => :ITEM_PRISAO_PREVENTIVA_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'prisao_preventiva_qtd_expedida', p_qt_resposta => :ITEM_PRISAO_PREVENTIVA_QTD_EXPEDIDA);

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'sequestro', p_st_resposta => :ITEM_SEQUESTRO, p_ds_resposta => :ITEM_SEQUESTRO_CASOS, p_ds_meta_info => 'Casos Epol');

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'medidas_cautelares', p_st_resposta => :ITEM_MEDIDAS_CAUTELARES);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'medidas_cautelares_comparecimento_juizo', p_st_resposta => :ITEM_MEDIDAS_CAUTELARES_COMPARECIMENTO_JUIZO, p_qt_resposta => :ITEM_MEDIDAS_CAUTELARES_COMPARECIMENTO_JUIZO_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'medidas_cautelares_proibicao_acesso', p_st_resposta => :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_ACESSO, p_qt_resposta => :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_ACESSO_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'medidas_cautelares_proibicao_contato', p_st_resposta => :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_CONTATO, p_qt_resposta => :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_CONTATO_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'medidas_cautelares_proibicao_ausentar_comarca', p_st_resposta => :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_AUSENTAR_COMARCA, p_qt_resposta => :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_AUSENTAR_COMARCA_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'medidas_cautelares_recolhimento_domiciliar', p_st_resposta => :ITEM_MEDIDAS_CAUTELARES_RECOLHIMENTO_DOMICILIAR, p_qt_resposta => :ITEM_MEDIDAS_CAUTELARES_RECOLHIMENTO_DOMICILIAR_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'medidas_cautelares_suspensao_exercicio', p_st_resposta => :ITEM_MEDIDAS_CAUTELARES_SUSPENSAO_EXERCICIO, p_qt_resposta => :ITEM_MEDIDAS_CAUTELARES_SUSPENSAO_EXERCICIO_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'medidas_cautelares_suspensao_atividade', p_st_resposta => :ITEM_MEDIDAS_CAUTELARES_SUSPENSAO_ATIVIDADE, p_qt_resposta => :ITEM_MEDIDAS_CAUTELARES_SUSPENSAO_ATIVIDADE_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'medidas_cautelares_internacao_provisoria', p_st_resposta => :ITEM_MEDIDAS_CAUTELARES_INTERNACAO_PROVISORIA, p_qt_resposta => :ITEM_MEDIDAS_CAUTELARES_INTERNACAO_PROVISORIA_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'medidas_cautelares_fianca', p_st_resposta => :ITEM_MEDIDAS_CAUTELARES_FIANCA, p_qt_resposta => :ITEM_MEDIDAS_CAUTELARES_FIANCA_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'medidas_cautelares_monitoracao_eletronica', p_st_resposta => :ITEM_MEDIDAS_CAUTELARES_MONITORACAO_ELETRONICA, p_qt_resposta => :ITEM_MEDIDAS_CAUTELARES_MONITORACAO_ELETRONICA_QTD);
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'medidas_cautelares_proibicao_ausentar_pais', p_st_resposta => :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_AUSENTAR_PAIS, p_qt_resposta => :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_AUSENTAR_PAIS_QTD);

    --
    last_id := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'auxilio_orgao', p_st_resposta => :ITEM_AUXILIO_ORGAO);
    IF (:ITEM_AUXILIO_ORGAO = 1) THEN
        upsert_resposta_etapa_orgao_cooperacao(last_id, :ITEM_AUXILIO_ORGAO, :ITEM_AUXILIO_ORGAO_ORGAOS);
    END IF;

    --
    last_id := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'auxilio_tatico', p_st_resposta => :ITEM_AUXILIO_TATICO);
    IF (:ITEM_AUXILIO_TATICO = 1) THEN
        upsert_resposta_etapa_grupo_tatico(last_id, :ITEM_AUXILIO_TATICO, :ITEM_AUXILIO_TATICO_GRUPOS);
    END IF;

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'reintegracao_posse', p_st_resposta => :ITEM_REINTEGRACAO_POSSE, p_qt_resposta => :ITEM_REINTEGRACAO_POSSE_QTD);

    --
    last_id := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'medida_contra_servidor_publico', p_st_resposta => :ITEM_MEDIDA_CONTRA_SERVIDOR_PUBLICO, p_qt_resposta => :ITEM_MEDIDA_CONTRA_SERVIDOR_PUBLICO_QTD);
    IF (:ITEM_MEDIDA_CONTRA_SERVIDOR_PUBLICO = 1) THEN
        upsert_resposta_etapa_orgao_cooperacao(last_id, :ITEM_MEDIDA_CONTRA_SERVIDOR_PUBLICO, :ITEM_MEDIDA_CONTRA_SERVIDOR_PUBLICO_ORGAO);
    END IF;

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'medida_exposta_politicamente', p_st_resposta => :ITEM_MEDIDA_EXPOSTA_POLITICAMENTE, p_qt_resposta => :ITEM_MEDIDA_EXPOSTA_POLITICAMENTE_QTD);

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'operacao_simultanea', p_st_resposta => :ITEM_OPERACAO_SIMULTANEA);

    --
    v_dummy := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'publicacao_midia_externa', p_st_resposta => :ITEM_PUBLICACAO_MIDIA_EXTERNA);

    ----
    -- Deflagracao 2/2

    -- resgate vitimas
    last_id := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'resgate_vitima', p_st_resposta => :ITEM_RESGATE_VITIMA, p_ob_resposta => :ITEM_RESGATE_VITIMA_OUTROS);
    IF (:ITEM_RESGATE_VITIMA = 1) THEN
        upsert_resposta_etapa_tipo_crime(last_id, :ITEM_RESGATE_VITIMA, :ITEM_RESGATE_VITIMA_TIPOS);
    END IF;

    -- identificacao vítimas
    last_id := upsert_resposta_etapa(p_id_operacao => :P340_ID_OPERACAO, p_cd_campo => 'identificacao_vitima', p_st_resposta => :ITEM_IDENTIFICACAO_VITIMA, p_ob_resposta => :ITEM_IDENTIFICACAO_VITIMA_OUTROS);
    IF (:ITEM_IDENTIFICACAO_VITIMA = 1) THEN
        upsert_resposta_etapa_tipo_crime(last_id, :ITEM_IDENTIFICACAO_VITIMA, :ITEM_IDENTIFICACAO_VITIMA_TIPOS);
    END IF;

    -- marca flag ok
    UPDATE tb_operacao SET st_deflagracao_saved = 1 WHERE id_operacao = :P340_ID_OPERACAO;

EXCEPTION
    WHEN OTHERS THEN
        raise_application_error(-20002, 'Não foi possível salvar (deflagração): ' || sqlerrm);

END;