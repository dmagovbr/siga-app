DECLARE

--     general_id number;

BEGIN


    ----
    -- Deflagracao 1/2

    --
    --2025.01.10 Item comentado devido Realocar pergunta 'Houve cadastro da operação no GPOL?' de 'Deflagração' para 'Pré-deflagração'
    --#3151 michell.moq
    --=====================================================
    --begin
    --    select ST_RESPOSTA_ETAPA into :ITEM_CADASTRO_GPOL from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P340_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'cadastro_gpol';
    --    -- select listagg(ID_SIS_GPOL_FK, ':') into :ITEM_CADASTRO_GPOL_IDGPOL from TB_RESPOSTA_ETAPA_SIS_GPOL tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P340_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'cadastro_gpol';
    --    exception when no_data_found then null;
    --end;

    --
    BEGIN
        SELECT st_resposta_etapa, qt_resposta_etapa INTO :ITEM_BUSCA_DOMICILIAR, :ITEM_BUSCA_DOMICILIAR_QTD FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'busca_domiciliar';
        SELECT qt_resposta_etapa INTO :ITEM_BUSCA_DOMICILIAR_ENDERECOS FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'busca_domiciliar_enderecos';
        SELECT qt_resposta_etapa INTO :ITEM_BUSCA_DOMICILIAR_QTD_EXPEDIDA FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'busca_domiciliar_qtd_expedida';
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        SELECT st_resposta_etapa, qt_resposta_etapa INTO :ITEM_PRISAO_TEMPORARIA, :ITEM_PRISAO_TEMPORARIA_QTD FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'prisao_temporaria';
        SELECT qt_resposta_etapa INTO :ITEM_PRISAO_TEMPORARIA_QTD_EXPEDIDA FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'prisao_temporaria_qtd_expedida';
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        SELECT st_resposta_etapa, qt_resposta_etapa INTO :ITEM_PRISAO_PREVENTIVA, :ITEM_PRISAO_PREVENTIVA_QTD FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'prisao_preventiva';
        -- descomentado em 20251230
        SELECT qt_resposta_etapa INTO :ITEM_PRISAO_PREVENTIVA_QTD_EXPEDIDA FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'prisao_preventiva_qtd_expedida';
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        SELECT st_resposta_etapa, ds_resposta_etapa INTO :ITEM_SEQUESTRO, :ITEM_SEQUESTRO_CASOS FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'sequestro';
        /* 20250319 https://tree.taiga.io/project/eduardoemi-sigacrim/task/3669
        select VL_RESPOSTA_ETAPA into :ITEM_SEQUESTRO_VALOR_MOVEIS from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P340_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'sequestro_valor_moveis';
        select VL_RESPOSTA_ETAPA into :ITEM_SEQUESTRO_VALOR_BLOQUEADO_FINANCEIRO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P340_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'sequestro_valor_bloqueado_financeiro';
        select VL_RESPOSTA_ETAPA into :ITEM_SEQUESTRO_VALOR_ESTIMADO_IMOVEIS from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P340_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'sequestro_valor_estimado_imoveis';
        select VL_RESPOSTA_ETAPA into :ITEM_SEQUESTRO_VALOR_CRIPTO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P340_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'sequestro_valor_cripto';
        select VL_RESPOSTA_ETAPA into :ITEM_SEQUESTRO_VALOR_TETO_JUIZ from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P340_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'sequestro_valor_teto_juiz';
        */
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        SELECT st_resposta_etapa INTO :ITEM_MEDIDAS_CAUTELARES FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'medidas_cautelares';
        SELECT st_resposta_etapa, qt_resposta_etapa INTO :ITEM_MEDIDAS_CAUTELARES_COMPARECIMENTO_JUIZO, :ITEM_MEDIDAS_CAUTELARES_COMPARECIMENTO_JUIZO_QTD FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'medidas_cautelares_comparecimento_juizo';
        SELECT st_resposta_etapa, qt_resposta_etapa INTO :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_ACESSO, :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_ACESSO_QTD FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'medidas_cautelares_proibicao_acesso';
        SELECT st_resposta_etapa, qt_resposta_etapa INTO :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_CONTATO, :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_CONTATO_QTD FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'medidas_cautelares_proibicao_contato';
        SELECT st_resposta_etapa, qt_resposta_etapa INTO :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_AUSENTAR_COMARCA, :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_AUSENTAR_COMARCA_QTD FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'medidas_cautelares_proibicao_ausentar_comarca';
        SELECT st_resposta_etapa, qt_resposta_etapa INTO :ITEM_MEDIDAS_CAUTELARES_RECOLHIMENTO_DOMICILIAR, :ITEM_MEDIDAS_CAUTELARES_RECOLHIMENTO_DOMICILIAR_QTD FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'medidas_cautelares_recolhimento_domiciliar';
        SELECT st_resposta_etapa, qt_resposta_etapa INTO :ITEM_MEDIDAS_CAUTELARES_SUSPENSAO_EXERCICIO, :ITEM_MEDIDAS_CAUTELARES_SUSPENSAO_EXERCICIO_QTD FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'medidas_cautelares_suspensao_exercicio';

        -- 20250820
        SELECT st_resposta_etapa, qt_resposta_etapa INTO :ITEM_MEDIDAS_CAUTELARES_SUSPENSAO_ATIVIDADE, :ITEM_MEDIDAS_CAUTELARES_SUSPENSAO_ATIVIDADE_QTD FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'medidas_cautelares_suspensao_atividade';

        SELECT st_resposta_etapa, qt_resposta_etapa INTO :ITEM_MEDIDAS_CAUTELARES_INTERNACAO_PROVISORIA, :ITEM_MEDIDAS_CAUTELARES_INTERNACAO_PROVISORIA_QTD FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'medidas_cautelares_internacao_provisoria';
        SELECT st_resposta_etapa, qt_resposta_etapa INTO :ITEM_MEDIDAS_CAUTELARES_FIANCA, :ITEM_MEDIDAS_CAUTELARES_FIANCA_QTD FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'medidas_cautelares_fianca';
        SELECT st_resposta_etapa, qt_resposta_etapa INTO :ITEM_MEDIDAS_CAUTELARES_MONITORACAO_ELETRONICA, :ITEM_MEDIDAS_CAUTELARES_MONITORACAO_ELETRONICA_QTD FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'medidas_cautelares_monitoracao_eletronica';
        SELECT st_resposta_etapa, qt_resposta_etapa INTO :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_AUSENTAR_PAIS, :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_AUSENTAR_PAIS_QTD FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'medidas_cautelares_proibicao_ausentar_pais';
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        SELECT st_resposta_etapa INTO :ITEM_AUXILIO_ORGAO FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'auxilio_orgao';
        SELECT listagg(id_orgao_cooperacao_fk, ':') INTO :ITEM_AUXILIO_ORGAO_ORGAOS FROM tb_resposta_etapa_orgao_cooperacao tb LEFT JOIN tb_resposta_etapa tr ON tr.id_resposta_etapa = tb.id_resposta_etapa_fk WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'auxilio_orgao';
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        -- selects comentados em atendimento ao problema #3274 ana.acat
        --select ST_RESPOSTA_ETAPA into :ITEM_AUXILIO_TATICO from TB_RESPOSTA_ETAPA where ID_OPERACAO_FK = :P340_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'pre_auxilio_tatico';
        --select listagg(ID_GRUPO_TATICO_FK, ':') into :ITEM_AUXILIO_TATICO_GRUPOS from TB_RESPOSTA_ETAPA_GRUPO_TATICO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P340_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'pre_auxilio_tatico';
        -- selects criados em atendimento ao problema #3274 ana.acat
        SELECT st_resposta_etapa INTO :ITEM_AUXILIO_TATICO FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'auxilio_tatico';
        SELECT listagg(id_grupo_tatico_fk, ':') INTO :ITEM_AUXILIO_TATICO_GRUPOS FROM tb_resposta_etapa_grupo_tatico tb LEFT JOIN tb_resposta_etapa tr ON tr.id_resposta_etapa = tb.id_resposta_etapa_fk WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'auxilio_tatico';
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        SELECT st_resposta_etapa, qt_resposta_etapa INTO :ITEM_REINTEGRACAO_POSSE, :ITEM_REINTEGRACAO_POSSE_QTD FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'reintegracao_posse';
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        SELECT st_resposta_etapa, qt_resposta_etapa INTO :ITEM_MEDIDA_CONTRA_SERVIDOR_PUBLICO, :ITEM_MEDIDA_CONTRA_SERVIDOR_PUBLICO_QTD FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'medida_contra_servidor_publico';
        -- select listagg(ID_ORGAO_COOPERACAO_FK, ':') into :ITEM_MEDIDA_CONTRA_SERVIDOR_PUBLICO_ORGAO from TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P340_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'pre_medida_contra_servidor_publico';
        SELECT listagg(id_orgao_cooperacao_fk, ':') INTO :ITEM_MEDIDA_CONTRA_SERVIDOR_PUBLICO_ORGAO FROM tb_resposta_etapa_orgao_cooperacao tb LEFT JOIN tb_resposta_etapa tr ON tr.id_resposta_etapa = tb.id_resposta_etapa_fk WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'medida_contra_servidor_publico';

    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        SELECT st_resposta_etapa, qt_resposta_etapa INTO :ITEM_MEDIDA_EXPOSTA_POLITICAMENTE, :ITEM_MEDIDA_EXPOSTA_POLITICAMENTE_QTD FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'medida_exposta_politicamente';
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        SELECT st_resposta_etapa INTO :ITEM_OPERACAO_SIMULTANEA FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'operacao_simultanea';
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --

    BEGIN
        SELECT st_resposta_etapa, ob_resposta_etapa INTO :ITEM_RESGATE_VITIMA, :ITEM_RESGATE_VITIMA_OUTROS FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'resgate_vitima';
         SELECT listagg(id_tipo_crime_fk, ':') INTO :ITEM_RESGATE_VITIMA_TIPOS FROM tb_resposta_etapa_tipo_crime WHERE id_resposta_etapa_fk = (SELECT id_resposta_etapa FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'resgate_vitima');
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        SELECT st_resposta_etapa, ob_resposta_etapa INTO :ITEM_IDENTIFICACAO_VITIMA, :ITEM_IDENTIFICACAO_VITIMA_OUTROS FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'identificacao_vitima';
         SELECT listagg(id_tipo_crime_fk, ':') INTO :ITEM_IDENTIFICACAO_VITIMA_TIPOS FROM tb_resposta_etapa_tipo_crime WHERE id_resposta_etapa_fk = (SELECT id_resposta_etapa FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'identificacao_vitima');
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    ----
    -- Deflagracao 2/2

    --
    /*
    BEGIN
        SELECT ST_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_trafico_pessoas';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_HOMENS FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_trafico_pessoas_qtd_homens';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_MULHERES FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_trafico_pessoas_qtd_mulheres';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_CRI_MASC FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_trafico_pessoas_qtd_cri_masc';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_CRI_FEM FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_trafico_pessoas_qtd_cri_fem';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_BR_MASC FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_trafico_pessoas_qtd_br_masc';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_BR_FEM FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_trafico_pessoas_qtd_br_fem';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_EST_MASC FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_trafico_pessoas_qtd_est_masc';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_EST_FEM FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_trafico_pessoas_qtd_est_fem';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_TRAFICO_PESSOAS_QTD_NAO_HETERO FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_trafico_pessoas_qtd_nao_hetero';
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        SELECT ST_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_migracao_ilegal';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_HOMENS FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_migracao_ilegal_qtd_homens';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_MULHERES FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_migracao_ilegal_qtd_mulheres';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_CRI_MASC FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_migracao_ilegal_qtd_cri_masc';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_CRI_FEM FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_migracao_ilegal_qtd_cri_fem';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_BR_MASC FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_migracao_ilegal_qtd_br_masc';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_BR_FEM FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_migracao_ilegal_qtd_br_fem';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_EST_MASC FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_migracao_ilegal_qtd_est_masc';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_EST_FEM FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_migracao_ilegal_qtd_est_fem';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_MIGRACAO_ILEGAL_QTD_NAO_HETERO FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_migracao_ilegal_qtd_nao_hetero';
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        SELECT ST_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_ordem_trabalho';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_HOMENS FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_ordem_trabalho_qtd_homens';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_MULHERES FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_ordem_trabalho_qtd_mulheres';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_CRI_MASC FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_ordem_trabalho_qtd_cri_masc';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_CRI_FEM FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_ordem_trabalho_qtd_cri_fem';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_BR_MASC FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_ordem_trabalho_qtd_br_masc';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_BR_FEM FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_ordem_trabalho_qtd_br_fem';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_EST_MASC FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_ordem_trabalho_qtd_est_masc';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_EST_FEM FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_ordem_trabalho_qtd_est_fem';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_ORDEM_TRABALHO_QTD_NAO_HETERO FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_ordem_trabalho_qtd_nao_hetero';
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        SELECT ST_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_grupo_exterminio';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_HOMENS FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_grupo_exterminio_qtd_homens';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_MULHERES FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_grupo_exterminio_qtd_mulheres';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_CRI_MASC FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_grupo_exterminio_qtd_cri_masc';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_CRI_FEM FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_grupo_exterminio_qtd_cri_fem';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_BR_MASC FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_grupo_exterminio_qtd_br_masc';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_BR_FEM FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_grupo_exterminio_qtd_br_fem';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_EST_MASC FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_grupo_exterminio_qtd_est_masc';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_EST_FEM FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_grupo_exterminio_qtd_est_fem';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_GRUPO_EXTERMINIO_QTD_NAO_HETERO FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_grupo_exterminio_qtd_nao_hetero';
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        SELECT ST_RESPOSTA_ETAPA INTO :ITEM_VITIMA_ABUSO FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'vitima_abuso';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_VITIMA_ABUSO_QTD_11_MASC FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'vitima_abuso_qtd_11_masc';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_VITIMA_ABUSO_QTD_11_FEM FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'vitima_abuso_qtd_11_fem';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_VITIMA_ABUSO_QTD_17_MASC FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'vitima_abuso_qtd_17_masc';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_VITIMA_ABUSO_QTD_17_FEM FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'vitima_abuso_qtd_17_fem';
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        SELECT ST_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_QTD_11_MASC FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_qtd_11_masc';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_QTD_11_FEM FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_qtd_11_fem';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_QTD_17_MASC FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_qtd_17_masc';
        SELECT QT_RESPOSTA_ETAPA INTO :ITEM_RESGATE_VITIMA_QTD_17_FEM FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P340_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'resgate_vitima_qtd_17_fem';
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;
    */

    -- é um item do tipo checkbox
    -- novo código inserido em atendimento ao problema #3273 ana.acat
    BEGIN
        SELECT st_resposta_etapa INTO :ITEM_PUBLICACAO_MIDIA_EXTERNA FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'publicacao_midia_externa';
    EXCEPTION
        WHEN no_data_found THEN :ITEM_PUBLICACAO_MIDIA_EXTERNA := '0'; -- Define valor padrão
    END;

EXCEPTION
    WHEN OTHERS THEN
        raise_application_error(-20303, 'Não foi possível recuperar os dados no momento (Deflagração). Caso o problema persista, por favor, entre em contato com o suporte.', FALSE);
END;