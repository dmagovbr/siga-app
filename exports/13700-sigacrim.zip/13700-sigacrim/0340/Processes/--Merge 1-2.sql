declare

    shuttle wwv_flow_global.vc_arr2;
    last_id number;

begin



    ----
    -- Deflagracao 1/2

    --
    /*
    --2025.01.10 Item comentado devido Realocar pergunta 'Houve cadastro da operação no GPOL?' de 'Deflagração' para 'Pré-deflagração'
    -- #3151 michell.moq
    ---=====================================================
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'cadastro_gpol')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_CADASTRO_GPOL when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'cadastro_gpol', :ITEM_CADASTRO_GPOL);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'cadastro_gpol';
        delete from TB_RESPOSTA_ETAPA_SIS_GPOL where ID_RESPOSTA_ETAPA_SIS_GPOL IN (select ID_RESPOSTA_ETAPA_SIS_GPOL from TB_RESPOSTA_ETAPA_SIS_GPOL tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P340_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'cadastro_gpol');
        if (:ITEM_CADASTRO_GPOL = 1) then
            shuttle := apex_util.string_to_table(:ITEM_CADASTRO_GPOL_IDGPOL);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_SIS_GPOL (ID_RESPOSTA_ETAPA_FK, ID_SIS_GPOL_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
        exception when no_data_found then null;
    end;
*/
    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'busca_domiciliar')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_BUSCA_DOMICILIAR, QT_RESPOSTA_ETAPA = :ITEM_BUSCA_DOMICILIAR_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'busca_domiciliar', :ITEM_BUSCA_DOMICILIAR, :ITEM_BUSCA_DOMICILIAR_QTD);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'busca_domiciliar_enderecos')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_BUSCA_DOMICILIAR_ENDERECOS when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'busca_domiciliar_enderecos', :ITEM_BUSCA_DOMICILIAR_ENDERECOS);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'busca_domiciliar_qtd_expedida')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_BUSCA_DOMICILIAR_QTD_EXPEDIDA when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'busca_domiciliar_qtd_expedida', :ITEM_BUSCA_DOMICILIAR_QTD_EXPEDIDA);
    exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'prisao_temporaria')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_PRISAO_TEMPORARIA, QT_RESPOSTA_ETAPA = :ITEM_PRISAO_TEMPORARIA_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'prisao_temporaria', :ITEM_PRISAO_TEMPORARIA, :ITEM_PRISAO_TEMPORARIA_QTD);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'prisao_temporaria_qtd_expedida')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_PRISAO_TEMPORARIA_QTD_EXPEDIDA when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'prisao_temporaria_qtd_expedida', :ITEM_PRISAO_TEMPORARIA_QTD_EXPEDIDA);
    exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'prisao_preventiva')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_PRISAO_PREVENTIVA, QT_RESPOSTA_ETAPA = :ITEM_PRISAO_PREVENTIVA_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'prisao_preventiva', :ITEM_PRISAO_PREVENTIVA, :ITEM_PRISAO_PREVENTIVA_QTD);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'prisao_preventiva_qtd_expedida')
        when matched then update set QT_RESPOSTA_ETAPA = :ITEM_PRISAO_PREVENTIVA_QTD_EXPEDIDA when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'prisao_preventiva_qtd_expedida', :ITEM_PRISAO_PREVENTIVA_QTD_EXPEDIDA);
    exception when no_data_found then null;
    end;


    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'sequestro')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_SEQUESTRO, DS_RESPOSTA_ETAPA = :ITEM_SEQUESTRO_CASOS
        when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, DS_RESPOSTA_ETAPA, DS_META_INFO) values (:P340_ID_OPERACAO, 'sequestro', :ITEM_SEQUESTRO, :ITEM_SEQUESTRO_CASOS, 'Casos Epol');

        --
        /*
        20250319 https://tree.taiga.io/project/eduardoemi-sigacrim/task/3669

        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'sequestro_valor_moveis')
        when matched then update set VL_RESPOSTA_ETAPA = to_number(:ITEM_SEQUESTRO_VALOR_MOVEIS, '999G999G999G999G990D00'), DS_META_INFO = '' when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, VL_RESPOSTA_ETAPA, DS_META_INFO) values (:P340_ID_OPERACAO, 'sequestro_valor_moveis', to_number(:ITEM_SEQUESTRO_VALOR_MOVEIS, '999G999G999G999G990D00'), '');
        --
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'sequestro_valor_bloqueado_financeiro')
        when matched then update set VL_RESPOSTA_ETAPA = to_number(:ITEM_SEQUESTRO_VALOR_BLOQUEADO_FINANCEIRO, '999G999G999G999G990D00'), DS_META_INFO = '' when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, VL_RESPOSTA_ETAPA, DS_META_INFO) values (:P340_ID_OPERACAO, 'sequestro_valor_bloqueado_financeiro', to_number(:ITEM_SEQUESTRO_VALOR_BLOQUEADO_FINANCEIRO, '999G999G999G999G990D00'), '');
        --
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'sequestro_valor_estimado_imoveis')
        when matched then update set VL_RESPOSTA_ETAPA = to_number(:ITEM_SEQUESTRO_VALOR_ESTIMADO_IMOVEIS, '999G999G999G999G990D00'), DS_META_INFO = '' when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, VL_RESPOSTA_ETAPA, DS_META_INFO) values (:P340_ID_OPERACAO, 'sequestro_valor_estimado_imoveis', to_number(:ITEM_SEQUESTRO_VALOR_ESTIMADO_IMOVEIS, '999G999G999G999G990D00'), '');
        --
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'sequestro_valor_cripto')
        when matched then update set VL_RESPOSTA_ETAPA = to_number(:ITEM_SEQUESTRO_VALOR_CRIPTO, '999G999G999G999G990D00'), DS_META_INFO = '' when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, VL_RESPOSTA_ETAPA, DS_META_INFO) values (:P340_ID_OPERACAO, 'sequestro_valor_cripto', to_number(:ITEM_SEQUESTRO_VALOR_CRIPTO, '999G999G999G999G990D00'), '');
        -- https://tree.taiga.io/project/eduardoemi-sigacrim/us/3195?
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'sequestro_valor_teto_juiz')
        when matched then update set VL_RESPOSTA_ETAPA = to_number(:ITEM_SEQUESTRO_VALOR_TETO_JUIZ, '999G999G999G999G990D00'), DS_META_INFO = '' when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, VL_RESPOSTA_ETAPA, DS_META_INFO) values (:P340_ID_OPERACAO, 'sequestro_valor_teto_juiz', to_number(:ITEM_SEQUESTRO_VALOR_TETO_JUIZ, '999G999G999G999G990D00'), '');
        */


        /*
        MERGE INTO tb_resposta_etapa USING dual ON (rownum = 1 AND id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'sequestro_valor_teto_juiz' )
        WHEN MATCHED THEN UPDATE SET VL_RESPOSTA_ETAPA = TO_NUMBER(REPLACE(REPLACE(:ITEM_SEQUESTRO_VALOR_TETO_JUIZ, '.', ''), ',', '.'), '999999999999999D99', 'NLS_NUMERIC_CHARACTERS = '',.'' ' ),DS_META_INFO = ''
        WHEN NOT MATCHED THEN INSERT (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, VL_RESPOSTA_ETAPA, DS_META_INFO) VALUES ( :P340_ID_OPERACAO, 'sequestro_valor_teto_juiz', TO_NUMBER( REPLACE(REPLACE(:ITEM_SEQUESTRO_VALOR_TETO_JUIZ, '.', ''), ',', '.'), '999999999999999D99', 'NLS_NUMERIC_CHARACTERS = '',.'' ' ), '' );
        */

    exception when no_data_found then null;
    end;


    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'medidas_cautelares')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'medidas_cautelares', :ITEM_MEDIDAS_CAUTELARES);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'medidas_cautelares_comparecimento_juizo')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_COMPARECIMENTO_JUIZO, QT_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_COMPARECIMENTO_JUIZO_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'medidas_cautelares_comparecimento_juizo', :ITEM_MEDIDAS_CAUTELARES_COMPARECIMENTO_JUIZO, :ITEM_MEDIDAS_CAUTELARES_COMPARECIMENTO_JUIZO_QTD);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'medidas_cautelares_proibicao_acesso')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_ACESSO, QT_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_ACESSO_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'medidas_cautelares_proibicao_acesso', :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_ACESSO, :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_ACESSO_QTD);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'medidas_cautelares_proibicao_contato')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_CONTATO, QT_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_CONTATO_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'medidas_cautelares_proibicao_contato', :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_CONTATO, :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_CONTATO_QTD);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'medidas_cautelares_proibicao_ausentar_comarca')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_AUSENTAR_COMARCA, QT_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_AUSENTAR_COMARCA_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'medidas_cautelares_proibicao_ausentar_comarca', :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_AUSENTAR_COMARCA, :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_AUSENTAR_COMARCA_QTD);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'medidas_cautelares_recolhimento_domiciliar')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_RECOLHIMENTO_DOMICILIAR, QT_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_RECOLHIMENTO_DOMICILIAR_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'medidas_cautelares_recolhimento_domiciliar', :ITEM_MEDIDAS_CAUTELARES_RECOLHIMENTO_DOMICILIAR, :ITEM_MEDIDAS_CAUTELARES_RECOLHIMENTO_DOMICILIAR_QTD);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'medidas_cautelares_suspensao_exercicio')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_SUSPENSAO_EXERCICIO, QT_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_SUSPENSAO_EXERCICIO_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'medidas_cautelares_suspensao_exercicio', :ITEM_MEDIDAS_CAUTELARES_SUSPENSAO_EXERCICIO, :ITEM_MEDIDAS_CAUTELARES_SUSPENSAO_EXERCICIO_QTD);

        -- 20250820
         merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'medidas_cautelares_suspensao_atividade')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_SUSPENSAO_ATIVIDADE, QT_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_SUSPENSAO_ATIVIDADE_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'medidas_cautelares_suspensao_atividade', :ITEM_MEDIDAS_CAUTELARES_SUSPENSAO_ATIVIDADE, :ITEM_MEDIDAS_CAUTELARES_SUSPENSAO_ATIVIDADE_QTD);

        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'medidas_cautelares_internacao_provisoria')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_INTERNACAO_PROVISORIA, QT_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_INTERNACAO_PROVISORIA_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'medidas_cautelares_internacao_provisoria', :ITEM_MEDIDAS_CAUTELARES_INTERNACAO_PROVISORIA, :ITEM_MEDIDAS_CAUTELARES_INTERNACAO_PROVISORIA_QTD);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'medidas_cautelares_fianca')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_FIANCA, QT_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_FIANCA_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'medidas_cautelares_fianca', :ITEM_MEDIDAS_CAUTELARES_FIANCA, :ITEM_MEDIDAS_CAUTELARES_FIANCA_QTD);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'medidas_cautelares_monitoracao_eletronica')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_MONITORACAO_ELETRONICA, QT_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_MONITORACAO_ELETRONICA_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'medidas_cautelares_monitoracao_eletronica', :ITEM_MEDIDAS_CAUTELARES_MONITORACAO_ELETRONICA, :ITEM_MEDIDAS_CAUTELARES_MONITORACAO_ELETRONICA_QTD);
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'medidas_cautelares_proibicao_ausentar_pais')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_AUSENTAR_PAIS, QT_RESPOSTA_ETAPA = :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_AUSENTAR_PAIS_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'medidas_cautelares_proibicao_ausentar_pais', :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_AUSENTAR_PAIS, :ITEM_MEDIDAS_CAUTELARES_PROIBICAO_AUSENTAR_PAIS_QTD);
    exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'auxilio_orgao')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_AUXILIO_ORGAO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'auxilio_orgao', :ITEM_AUXILIO_ORGAO);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'auxilio_orgao';
        delete from TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO where ID_RESPOSTA_ETAPA_ORGAO_COOPERACAO IN (select ID_RESPOSTA_ETAPA_ORGAO_COOPERACAO from TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P340_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'auxilio_orgao');
        if (:ITEM_AUXILIO_ORGAO = 1) then
            shuttle := apex_util.string_to_table(:ITEM_AUXILIO_ORGAO_ORGAOS);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO (ID_RESPOSTA_ETAPA_FK, ID_ORGAO_COOPERACAO_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
    exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'auxilio_tatico')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_AUXILIO_TATICO when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'auxilio_tatico', :ITEM_AUXILIO_TATICO);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'auxilio_tatico';
        delete from TB_RESPOSTA_ETAPA_GRUPO_TATICO where ID_RESPOSTA_ETAPA_GRUPO_TATICO IN
                                                         (select ID_RESPOSTA_ETAPA_GRUPO_TATICO from TB_RESPOSTA_ETAPA_GRUPO_TATICO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P340_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'auxilio_tatico');
        if (:ITEM_AUXILIO_TATICO = 1) then
            shuttle := apex_util.string_to_table(:ITEM_AUXILIO_TATICO_GRUPOS);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_GRUPO_TATICO (ID_RESPOSTA_ETAPA_FK, ID_GRUPO_TATICO_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
    exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'reintegracao_posse')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_REINTEGRACAO_POSSE, QT_RESPOSTA_ETAPA = :ITEM_REINTEGRACAO_POSSE_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'reintegracao_posse', :ITEM_REINTEGRACAO_POSSE, :ITEM_REINTEGRACAO_POSSE_QTD);
    exception when no_data_found then null;
    end;

    -- #US 1938 ANA.ACAT
    -- 20241010-1431 maia.dam tabela alterada para TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'medida_contra_servidor_publico')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_MEDIDA_CONTRA_SERVIDOR_PUBLICO, QT_RESPOSTA_ETAPA = :ITEM_MEDIDA_CONTRA_SERVIDOR_PUBLICO_QTD
        when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'medida_contra_servidor_publico', :ITEM_MEDIDA_CONTRA_SERVIDOR_PUBLICO, :ITEM_MEDIDA_CONTRA_SERVIDOR_PUBLICO_QTD);
        --
        select id_resposta_etapa into last_id from tb_resposta_etapa where ID_OPERACAO_FK = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'medida_contra_servidor_publico';
        delete from TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO where ID_RESPOSTA_ETAPA_ORGAO_COOPERACAO IN
                                                             (select ID_RESPOSTA_ETAPA_ORGAO_COOPERACAO from TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO tb left join TB_RESPOSTA_ETAPA tr on tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK where ID_OPERACAO_FK = :P340_ID_OPERACAO and CD_CAMPO_ETAPA_FK = 'medida_contra_servidor_publico');
        if (:ITEM_MEDIDA_CONTRA_SERVIDOR_PUBLICO = 1) then
            shuttle := apex_util.string_to_table(:ITEM_MEDIDA_CONTRA_SERVIDOR_PUBLICO_ORGAO);
            for i in 1..shuttle.count loop
                insert into TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO (ID_RESPOSTA_ETAPA_FK, ID_ORGAO_COOPERACAO_FK) VALUES(last_id, shuttle(i));
            end loop;
        end if;
    exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'medida_exposta_politicamente')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_MEDIDA_EXPOSTA_POLITICAMENTE, QT_RESPOSTA_ETAPA = :ITEM_MEDIDA_EXPOSTA_POLITICAMENTE_QTD when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA, QT_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'medida_exposta_politicamente', :ITEM_MEDIDA_EXPOSTA_POLITICAMENTE, :ITEM_MEDIDA_EXPOSTA_POLITICAMENTE_QTD);
    exception when no_data_found then null;
    end;

    --
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'operacao_simultanea')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_OPERACAO_SIMULTANEA when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'operacao_simultanea', :ITEM_OPERACAO_SIMULTANEA);
    exception when no_data_found then null;
    end;

    --
    -- novo código inserido para armazenar quando não houver publicação em mídia externa #3273 ana.acat
    begin
        merge into tb_resposta_etapa using dual on (rownum = 1 and id_operacao_fk = :P340_ID_OPERACAO and cd_campo_etapa_fk = 'publicacao_midia_externa')
        when matched then update set ST_RESPOSTA_ETAPA = :ITEM_PUBLICACAO_MIDIA_EXTERNA
        when not matched then insert (ID_OPERACAO_FK, CD_CAMPO_ETAPA_FK, ST_RESPOSTA_ETAPA) values (:P340_ID_OPERACAO, 'publicacao_midia_externa', :ITEM_PUBLICACAO_MIDIA_EXTERNA);
    exception when no_data_found then null;
    end;



exception when others then
    raise_application_error(-20002, 'Não foi possível salvar (deflagração 1/2): ' || SQLERRM);
end;