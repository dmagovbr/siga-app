DECLARE
    shuttle wwv_flow_global.VC_ARR2;
    last_id number;

BEGIN


    ----
    -- Deflagracao 2/2

    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'resgate_vitima')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_RESGATE_VITIMA, ob_resposta_etapa = :ITEM_RESGATE_VITIMA_CRIME_OUTROS
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa, ob_resposta_etapa) VALUES (:P340_ID_OPERACAO, 'resgate_vitima', :ITEM_RESGATE_VITIMA, :ITEM_RESGATE_VITIMA_CRIME_OUTROS);
        --
        SELECT id_resposta_etapa INTO last_id FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'resgate_vitima';
        --
        DELETE FROM tb_resposta_etapa_resgate_vitima_crime WHERE id_resposta_etapa_resgate_vitima_crime IN (SELECT id_resposta_etapa_resgate_vitima_crime FROM tb_resposta_etapa_resgate_vitima_crime tb LEFT JOIN tb_resposta_etapa tr ON tr.id_resposta_etapa = tb.id_resposta_etapa_fk WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'resgate_vitima');
        --
        IF (:ITEM_RESGATE_VITIMA = 1) THEN
            shuttle := apex_util.string_to_table(:ITEM_RESGATE_VITIMA_CRIMES);
            FOR i IN 1..shuttle.count LOOP
                INSERT INTO tb_resposta_etapa_resgate_vitima_crime (
                    id_resposta_etapa_fk,
                    id_tipo_crime_vitima_fk
                )
                VALUES (
                    last_id,
                    shuttle(i)
                );
            END LOOP;
        END IF;
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;

    --
    BEGIN
        MERGE INTO tb_resposta_etapa
        USING dual
        ON (rownum = 1 AND id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'identificacao_vitima')
        WHEN MATCHED THEN
            UPDATE SET st_resposta_etapa = :ITEM_IDENTIFICACAO_VITIMA, ob_resposta_etapa = :ITEM_IDENTIFICACAO_VITIMA_CRIME_OUTROS
        WHEN NOT MATCHED THEN
            INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa, ob_resposta_etapa) VALUES (:P340_ID_OPERACAO, 'identificacao_vitima', :ITEM_IDENTIFICACAO_VITIMA, :ITEM_IDENTIFICACAO_VITIMA_CRIME_OUTROS);
        --
        SELECT id_resposta_etapa INTO last_id FROM tb_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'identificacao_vitima';
        --
        DELETE FROM tb_resposta_etapa_identificacao_vitima_crime WHERE id_resposta_etapa_identificacao_vitima_crime IN (SELECT id_resposta_etapa_identificacao_vitima_crime FROM tb_resposta_etapa_identificacao_vitima_crime tb LEFT JOIN tb_resposta_etapa tr ON tr.id_resposta_etapa = tb.id_resposta_etapa_fk WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'identificacao_vitima');
        --
        IF (:ITEM_IDENTIFICACAO_VITIMA = 1) THEN
            shuttle := apex_util.string_to_table(:ITEM_IDENTIFICACAO_VITIMA_CRIME);
            FOR i IN 1..shuttle.count LOOP
                INSERT INTO tb_resposta_etapa_identificacao_vitima_crime (
                    id_resposta_etapa_fk,
                    id_tipo_crime_vitima_fk
                )
                VALUES (
                    last_id,
                    shuttle(i)
                );
            END LOOP;
        END IF;
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;


    -- marca flag ok
    UPDATE tb_operacao SET st_deflagracao_saved = 1 WHERE id_operacao = :P340_ID_OPERACAO;

EXCEPTION
    WHEN OTHERS THEN
        raise_application_error(-20002, 'Não foi possível salvar (deflagração 2/2): ' || sqlerrm);
END;