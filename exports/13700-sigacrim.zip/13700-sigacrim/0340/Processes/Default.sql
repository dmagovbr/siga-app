BEGIN

    --
    IF APEX_REGION.IS_READ_ONLY THEN
        RETURN;
    END IF;

    --
    IF :ITEM_BUSCA_DOMICILIAR IS NULL THEN
        SELECT st_resposta_etapa INTO :ITEM_BUSCA_DOMICILIAR FROM vw_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'pre_busca_domiciliar';
    END IF;
    IF :ITEM_BUSCA_DOMICILIAR_QTD IS NULL THEN
        SELECT qt_resposta_etapa INTO :ITEM_BUSCA_DOMICILIAR_QTD_EXPEDIDA FROM vw_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'pre_busca_domiciliar';
    END IF;

    --
    IF :ITEM_PRISAO_TEMPORARIA IS NULL THEN
        SELECT st_resposta_etapa INTO :ITEM_PRISAO_TEMPORARIA FROM vw_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'pre_prisao_temporaria';
    END IF;
    IF :ITEM_PRISAO_TEMPORARIA_QTD IS NULL THEN
        SELECT qt_resposta_etapa INTO :ITEM_PRISAO_TEMPORARIA_QTD_EXPEDIDA FROM vw_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'pre_prisao_temporaria';
    END IF;

    --
    IF :ITEM_PRISAO_PREVENTIVA IS NULL THEN
        SELECT st_resposta_etapa INTO :ITEM_PRISAO_PREVENTIVA FROM vw_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'pre_prisao_preventiva';
    END IF;
    IF :ITEM_PRISAO_PREVENTIVA_QTD IS NULL THEN
        SELECT qt_resposta_etapa INTO :ITEM_PRISAO_PREVENTIVA_QTD_EXPEDIDA FROM vw_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'pre_prisao_preventiva';
    END IF;

    --
    IF :ITEM_AUXILIO_TATICO IS NULL THEN
        SELECT st_resposta_etapa INTO :ITEM_AUXILIO_TATICO FROM vw_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'pre_auxilio_tatico';
    END IF;

    --
    IF :ITEM_AUXILIO_ORGAO IS NULL THEN
        SELECT st_resposta_etapa INTO :ITEM_AUXILIO_ORGAO FROM vw_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'pre_auxilio_orgao';
    END IF;
    IF :ITEM_AUXILIO_ORGAO_ORGAOS IS NULL THEN
        SELECT listagg(ID_ORGAO_COOPERACAO_FK, ':') INTO :ITEM_PRE_AUXILIO_ORGAO_ORGAOS FROM vw_resposta_etapa_multipla WHERE id_operacao_fk = :P340_ID_OPERACAO AND campo = 'pre_auxilio_orgao';
    END IF;

    -- Pré-Deflagração: Há previsão de cumprimento de medidas cautelares em desfavor de Funcionários Públicos? 
    -- CD_CAMPO_ETAPA_FK = pre_envolv_funcionario
    -- Deflagração: Houve a expedição de mandado de medidas cautelares contra servidores públicos?
    IF :ITEM_MEDIDA_CONTRA_SERVIDOR_PUBLICO IS NULL THEN
        SELECT st_resposta_etapa INTO :ITEM_MEDIDA_CONTRA_SERVIDOR_PUBLICO FROM vw_resposta_etapa WHERE id_operacao_fk = :P340_ID_OPERACAO AND cd_campo_etapa_fk = 'pre_envolv_funcionarios';
    END IF;
    IF :ITEM_MEDIDA_CONTRA_SERVIDOR_PUBLICO_ORGAO IS NULL THEN
        SELECT listagg(ro.ID_ORGAO_COOPERACAO_FK, ':')
        INTO :ITEM_MEDIDA_CONTRA_SERVIDOR_PUBLICO_ORGAO
        FROM TB_RESPOSTA_ETAPA_ORGAO_COOPERACAO ro
        JOIN TB_RESPOSTA_ETAPA re ON re.ID_RESPOSTA_ETAPA = ro.ID_RESPOSTA_ETAPA_FK
        JOIN TB_CAMPO_ETAPA ce ON ce.CD_CAMPO_ETAPA = re.CD_CAMPO_ETAPA_FK
        WHERE re.ID_OPERACAO_FK = :P340_ID_OPERACAO AND re.CD_CAMPO_ETAPA_FK = 'pre_envolv_funcionarios';
    END IF;

--PRE_ENVOLV_FUNCIONARIOS

EXCEPTION
    WHEN no_data_found THEN
        RETURN;

END;