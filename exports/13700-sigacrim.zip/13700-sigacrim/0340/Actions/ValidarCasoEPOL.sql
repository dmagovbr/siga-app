DECLARE
    v_lista APEX_T_VARCHAR2 := APEX_STRING.SPLIT(:ITEM_SEQUESTRO_CASOS, ':');
    v_valido APEX_T_VARCHAR2 := APEX_T_VARCHAR2();
    v_invalidos APEX_T_VARCHAR2 := APEX_T_VARCHAR2();
    r_json CLOB;
    v_nrCaso VARCHAR2(100);
    i PLS_INTEGER;
BEGIN
    FOR i IN 1 .. v_lista.COUNT LOOP
        -- Chamando a API para verificar o valor
        r_json := API_EPOL(v_lista(i), :G_TOKEN);

        IF r_json IS NOT NULL THEN
            BEGIN
                -- Se a API retornar dados, verificamos se o caso é válido
                apex_json.parse(r_json);
                v_nrCaso := apex_json.get_varchar2('caso');

                IF v_nrCaso IS NOT NULL THEN
                    -- Caso válido, adicionamos à lista de válidos
                    v_valido.EXTEND;
                    v_valido(v_valido.COUNT) := v_lista(i);
                ELSE
                    -- Caso inválido, adicionamos à lista de inválidos
                    v_invalidos.EXTEND;
                    v_invalidos(v_invalidos.COUNT) := v_lista(i);
                END IF;
            EXCEPTION
                WHEN OTHERS THEN
                    -- Se houver qualquer erro, consideramos o valor como inválido
                    v_invalidos.EXTEND;
                    v_invalidos(v_invalidos.COUNT) := v_lista(i);
            END;
        ELSE
            -- Se a resposta da API for nula, consideramos o valor como inválido
            v_invalidos.EXTEND;
            v_invalidos(v_invalidos.COUNT) := v_lista(i);
        END IF;
    END LOOP;

    -- Atualizando ITEM_SEQUESTRO_CASOS para conter apenas os valores válidos
    :ITEM_SEQUESTRO_CASOS := APEX_STRING.JOIN(v_valido, ':');

    -- Atualizando as variáveis para exibição
    :P340_VALORES_VALIDOS := APEX_STRING.JOIN(v_valido, ':');
    :P340_INVALIDOS := APEX_STRING.JOIN(v_invalidos, ':');

    -- Exibindo a mensagem de erro com os casos inválidos
    IF v_invalidos.COUNT > 0 THEN
        :P340_MENSAGEM_ERRO := '🚫 Caso(s) inválido(s): ' || APEX_STRING.JOIN(v_invalidos, ', ');
    ELSE
        :P340_MENSAGEM_ERRO := NULL;
    END IF;
END;
