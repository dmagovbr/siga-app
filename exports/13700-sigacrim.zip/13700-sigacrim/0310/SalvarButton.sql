BEGIN

    -- 20260205
    IF (eh_administrador(:APP_ID, :G_USERNAME) = 1) THEN
        RETURN TRUE;
    END IF;

    --
    IF go_pode_atualizar_drpj(:P310_ID_OPERACAO, :G_USERNAME, :G_MATRICULA) = 1 THEN
        RETURN TRUE;
    END IF;

END;