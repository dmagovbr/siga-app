// Evento: Lose Focus (Blur)
// Item: P310_NR_CASO

var valor = $v('P310_NR_CASO');

if (!valor) return;

valor = valor.replace(/\D/g, '');

if (valor.length < 4) return;

var ano = valor.substring(0, 4);
var seq = valor.substring(4).padStart(7, '0').substring(0,7);

$s('P310_NR_CASO', ano + '.' + seq);