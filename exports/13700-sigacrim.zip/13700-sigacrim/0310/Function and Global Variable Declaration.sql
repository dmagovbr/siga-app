/*document.getElementById('P310_NR_CASO').addEventListener('input', function (event) {

   // var inputValue = event.target.value.replace(/[^\d]+/g,''); // Remove não dígitos
    var inputValue = event.target.value.replace(/[^\d,]/g,''); // Remove não dígitos

    // Aplica a máscara para o formato NNNN.NNNNNNN
    // var formattedValue = inputValue.replace(/(\d{0,4})(\d{0,7})/, "$1.$2");

    var formattedValue = inputValue.replace(/(\d{4})(\d{1,7})/, "$1.$2");

    event.target.value = formattedValue;

});
*/


$(document).ready(function(){
apex.date.parse = function ( pDateString, pFormat ) {
        let localDate = new Date( 2024, 0, 1 ),
            dateString = pDateString || "",
            formatMask = pFormat || apex.locale.getDateFormat(),
            formatMaskSearch = formatMask.toUpperCase(),
            formatTokenString = "FMMONTH|FMYYYY|FMRRRR|MONTH|FMMON|FMDAY|FMDY|FMDD|FMMM|HH12|HH24|RRRR|YYYY|DAY|DDD|MON|AM|DD|DL|DS|DY|HH|MI|MM|PM|RR|SS|YY|D",
            notSupportedTokenString = "SSSSS|SYEAR|SYYYY|IYYY|YEAR|IYY|SCC|TZD|TZH|TZM|TZR|AD|BC|CC|EE|FF|FX|IW|IY|RM|TS|WW|E|I|J|Q|W|X",
            amFormat = apex.locale.getSettings().calendar.amFormat,
            pmFormat = apex.locale.getSettings().calendar.pmFormat,
            formatTokens = [],
            formatToken = "",
            notSupportedTokens = [],
            notSupportedToken = "",
            findings = [],
            finding,
            dateStringPart,
            datePart,
            correctFollowFindings = false,
            findingStart = 0,
            findingEnd = 0,
            correctStartIndex = 0,
            blankAfterFormat = false,
            replaceChars = ["~", "*", "#", "<", ">", "|", "§", "^", "°", "=", "$", "&", "%", "@", "€"],
            replaceChar = "",
            i;

        function _getMonthNumber( pMonth, pUseAbbrev = false ) {
            let monthNames = pUseAbbrev ? apex.locale.getAbbrevMonthNames() : apex.locale.getMonthNames(),
                rawMonthNames = pUseAbbrev ? apex.locale.getSettings().calendar.rawAbbrMonthNames : apex.locale.getSettings().calendar.rawMonthNames,
                index;

            index = rawMonthNames.findIndex( ( month ) => {
                return month.toLowerCase() === pMonth.toLowerCase();
            } );
            if ( index === -1 ) { // not found
                index = monthNames.findIndex( ( month ) => {
                    return month.toLowerCase() === pMonth.toLowerCase();
                } );
            }
            return index;
        }

        function _setDayOfWeek( pDate, pDay ) {
            const currentDay = pDate.getDay() + 1,
                  distance = pDay - currentDay;
            pDate.setDate( pDate.getDate() + distance );
        }

        function _extractMonth( pDateString, pUseAbbrev = false ) {
            let monthNames = pUseAbbrev ? apex.locale.getAbbrevMonthNames() : apex.locale.getMonthNames(),
                rawMonthNames = pUseAbbrev ? apex.locale.getSettings().calendar.rawAbbrMonthNames : apex.locale.getSettings().calendar.rawMonthNames,
                found = false,
                monthName = "";

            for ( let i = 0; i < rawMonthNames.length; i++ ) {
                monthName = rawMonthNames[i];
                if ( pDateString.toLowerCase().includes( monthName.toLowerCase() ) ) {
                    found = true;
                    break;
                }
                monthName = "";
            }
            if ( !found ) {
                for ( let i = 0; i < monthNames.length; i++ ) {
                    monthName = monthNames[i];
                    if ( pDateString.toLowerCase().includes( monthName.toLowerCase() ) ) {
                        break;
                    }
                    monthName = "";
                }
            }
            return monthName;
        }

        function _extractDay( pDateString, pUseAbbrev = false ) {
            let dayNames = pUseAbbrev ? apex.locale.getAbbrevDayNames() : apex.locale.getDayNames(),
                rawDayNames = pUseAbbrev ? apex.locale.getSettings().calendar.rawAbbrDayNames : apex.locale.getSettings().calendar.rawDayNames,
                found = false,
                dayName = "";

            for ( let i = 0; i < rawDayNames.length; i++ ) {
                dayName = rawDayNames[i];
                if ( pDateString.toLowerCase().includes( dayName.toLowerCase() ) ) {
                    found = true;
                    break;
                }
                dayName = "";
            }
            if ( !found ) {
                for ( let i = 0; i < dayNames.length; i++ ) {
                    dayName = dayNames[i];
                    if ( pDateString.toLowerCase().includes( dayName.toLowerCase() ) ) {
                        break;
                    }
                    dayName = "";
                }
            }
            return dayName;
        }

        function _extractAMPM( pDateString ) {
            let ampmName = "";

            if ( pDateString.toLowerCase().includes( amFormat.toLowerCase() ) ) {
                ampmName = amFormat;
            }

            if ( !ampmName ) {
                if ( pDateString.toLowerCase().includes( pmFormat.toLowerCase() ) ) {
                    ampmName = pmFormat;
                }
            }
            return ampmName;
        }

        function _extractFMMM_FMDD_FMHH( pDateString, pStart, pEnd ) {
            let dateString = pDateString.substring( pStart, pEnd ) || "", // get only the relevant part
                dayNumber = ( dateString.match( /\d{1,2}/ ) || [] ).join(); // search for numbers with a length of 1 or 2
            return dayNumber;
        }

        function _correctFollowFindings( pFindings, pStartIndex, pAmount ) {
            pFindings = pFindings
                .filter( function ( elem ) {
                    return elem.start > pStartIndex;
                } )
                .forEach( function ( item ) {
                    item.start = item.start + pAmount;
                    item.end = item.end + pAmount;
                } );
        }

        function _escapeRegExp( pString = "" ) {
            return pString.replace( /[.*+?^${}()|[\]\\]/g, "\\$&" );
        }

        function _setDatePart( pDate, pPartValue, pPartFormat ) {
            apex.debug.info( "apex.date.parse: setDatePart", "value:", pPartValue, "format:", pPartFormat );

            const setDatePart = {
                YYYY: ( d, v ) => {
                    if ( !/^\d{4}$/.test( v ) ) {
                        throw new Error( "Date Parsing Error: YYYY not valid." );
                    }
                    d.setFullYear( v );
                },
                FMYYYY: ( d, v ) => {
                    if ( !/^\d{4}$/.test( v ) ) {
                        throw new Error( "Date Parsing Error: FMYYYY not valid." );
                    }
                    d.setFullYear( v );
                },
                YY: ( d, v ) => {
                    if ( !/^\d{2}$/.test( v ) ) {
                        throw new Error( "Date Parsing Error: YY not valid." );
                    }
                    d.setFullYear( d.getFullYear().toString().substr( 0, 2 ) + v );
                },
                RRRR: ( d, v ) => {
                    if ( !/^\d{4}$/.test( v ) ) {
                        throw new Error( "Date Parsing Error: RRRR not valid." );
                    }
                    d.setFullYear( v );
                },
                FMRRRR: ( d, v ) => {
                    if ( !/^\d{4}$/.test( v ) ) {
                        throw new Error( "Date Parsing Error: FMRRRR not valid." );
                    }
                    d.setFullYear( v );
                },
                RR: ( d, v ) => {
                    if ( !/^\d{2}$/.test( v ) ) {
                        throw new Error( "Date Parsing Error: RR not valid." );
                    }
                    d.setFullYear( d.getFullYear().toString().substr( 0, 2 ) + v );
                },
                MONTH: ( d, v ) => {
                    const value = _getMonthNumber( v, false );
                    if ( value === -1 ) {
                        throw new Error( "Date Parsing Error: MONTH not valid." );
                    }
                    d.setMonth( value );
                },
                FMMONTH: ( d, v ) => {
                    const value = _getMonthNumber( v, false );
                    if ( value === -1 ) {
                        throw new Error( "Date Parsing Error: FMMONTH not valid." );
                    }
                    d.setMonth( value );
                },
                MON: ( d, v ) => {
                    const value = _getMonthNumber( v, true );
                    if ( value === -1 ) {
                        throw new Error( "Date Parsing Error: MON not valid." );
                    }
                    d.setMonth( value );
                },
                FMMON: ( d, v ) => {
                    const value = _getMonthNumber( v, true );
                    if ( value === -1 ) {
                        throw new Error( "Date Parsing Error: FMMON not valid." );
                    }
                    d.setMonth( value );
                },
                MM: ( d, v ) => {
                    const value = parseInt( v, 10 );
                    if ( !/^\d+$/.test( value ) || value < 1 || value > 12 ) {
                        throw new Error( "Date Parsing Error: MM not valid." );
                    }
                    d.setMonth( value - 1 );
                },
                FMMM: ( d, v ) => {
                    const value = parseInt( v, 10 );
                    if ( !/^\d+$/.test( value ) || value < 1 || value > 12 ) {
                        throw new Error( "Date Parsing Error: FMMM not valid." );
                    }
                    d.setMonth( value - 1 );
                },
                DDD: ( d, v ) => {
                    const value = parseInt( v, 10 );
                    if ( !/^\d+$/.test( value ) || value < 1 || value > 366 ) {
                        throw new Error( "Date Parsing Error: DDD not valid." );
                    }
                    date.setDayOfYear( d, value );
                },
                DD: ( d, v ) => {
                    const value = parseInt( v, 10 );
                    if ( !/^\d+$/.test( value ) || value < 1 || value > 31 ) {
                        throw new Error( "Date Parsing Error: DD not valid." );
                    }
                    d.setDate( value );
                },
                FMDD: ( d, v ) => {
                    const value = parseInt( v, 10 );
                    if ( !/^\d+$/.test( value ) || value < 1 || value > 31 ) {
                        throw new Error( "Date Parsing Error: FMDD not valid." );
                    }
                    d.setDate( value );
                },
                D: ( d, v ) => {
                    const value = parseInt( v, 10 );
                    if ( !/^\d+$/.test( value ) || value < 1 || value > 7 ) {
                        throw new Error( "Date Parsing Error: D not valid." );
                    }
                    _setDayOfWeek( d, value );
                },
                HH24: ( d, v ) => {
                    const value = parseInt( v, 10 );
                    if ( !/^\d+$/.test( value ) || value < 0 || value > 23 ) {
                        throw new Error( "Date Parsing Error: HH24 not valid." );
                    }
                    d.setHours( value );
                },
                HH12: ( d, v ) => {
                    const value = parseInt( v, 10 );
                    if ( !/^\d+$/.test( value ) || value < 1 || value > 12 ) {
                        throw new Error( "Date Parsing Error: HH12 not valid." );
                    }
                    d.setHours( value );
                },
                HH: ( d, v ) => {
                    const value = parseInt( v, 10 );
                    if ( !/^\d+$/.test( value ) || value < 1 || value > 12 ) {
                        throw new Error( "Date Parsing Error: HH not valid." );
                    }
                    d.setHours( value );
                },
                AM: ( d, v ) => {
                    if ( ![amFormat, pmFormat].includes( v.toUpperCase() ) ) {
                        throw new Error( "Date Parsing Error: AM not valid." );
                    }
                    if ( v.toUpperCase() === amFormat && d.getHours() === 12 ) {
                        d.setHours( 0 );
                    } else if ( v.toUpperCase() === pmFormat && d.getHours() === 0 ) {
                        d.setHours( 12 );
                    } else if ( v.toUpperCase() === amFormat && d.getHours() > 12 ) {
                        d.setHours( d.getHours() - 12 );
                    } else if ( v.toUpperCase() === pmFormat && d.getHours() < 12 ) {
                        d.setHours( d.getHours() + 12 );
                    }
                },
                PM: ( d, v ) => {
                    if ( ![amFormat, pmFormat].includes( v.toUpperCase() ) ) {
                        throw new Error( "Date Parsing Error: PM not valid." );
                    }
                    if ( v.toUpperCase() === amFormat && d.getHours() === 12 ) {
                        d.setHours( 0 );
                    } else if ( v.toUpperCase() === pmFormat && d.getHours() === 0 ) {
                        d.setHours( 12 );
                    } else if ( v.toUpperCase() === amFormat && d.getHours() > 12 ) {
                        d.setHours( d.getHours() - 12 );
                    } else if ( v.toUpperCase() === pmFormat && d.getHours() < 12 ) {
                        d.setHours( d.getHours() + 12 );
                    }
                },
                MI: ( d, v ) => {
                    const value = parseInt( v, 10 );
                    if ( !/^\d+$/.test( value ) || value < 0 || value > 59 ) {
                        throw new Error( "Date Parsing Error: MI not valid." );
                    }
                    d.setMinutes( value );
                },
                SS: ( d, v ) => {
                    const value = parseInt( v, 10 );
                    if ( !/^\d+$/.test( value ) || value < 0 || value > 59 ) {
                        throw new Error( "Date Parsing Error: SS not valid." );
                    }
                    d.setSeconds( value );
                }
            };

            setDatePart[pPartFormat]( pDate, pPartValue );
        }

        // exit when no date string is provided
        if ( !dateString ) {
            return;
        }

        // reset hour, minutes, seconds, milliseconds
        localDate.setHours( 0, 0, 0, 0 );

        // special handling for DS/DL format mask, get the real one from DB (apex.apex.locale)
        if ( formatMaskSearch === "DS" ) {
            formatMask = apex.locale.getDSDateFormat();
            formatMaskSearch = formatMask.toUpperCase();
        }
        if ( formatMaskSearch === "DL" ) {
            formatMask = apex.locale.getDLDateFormat();
            formatMaskSearch = formatMask.toUpperCase();
        }

        // remove enquoted string including quotes from format mask
        // These strings should not be relevant for date conversion
        if ( formatMaskSearch.includes( '"' ) ) {
            formatMask = formatMask.replace( /".*?"/g, function ( match ) {
                return " ".repeat( match.length - 2 ); // length without the wrapping quotes
            } );
            formatMaskSearch = formatMask.toUpperCase();
        }

        // Remove unicode chars from format mask
        // These chars should not be relevant for date conversion
        if ( /[\u{0080}-\u{FFFF}]/u.test( formatMaskSearch ) ) {
            formatMask = formatMask.replace( /[\u{0080}-\u{FFFF}]/gu, " " );
            formatMaskSearch = formatMask.toUpperCase();
        }

        apex.debug.info( "apex.date.parse: dateString", dateString );
        apex.debug.info( "apex.date.parse: formatMask", formatMask );

        // find token matches in supplied format mask which we can use to translate into date parts
        formatTokens = formatTokenString.split( "|" );

        for ( i = 0; i < formatTokens.length; i++ ) {
            formatToken = formatTokens[i];

            if ( formatMaskSearch.includes( formatToken ) ) {
                findingStart = formatMask.toUpperCase().indexOf( formatToken );
                findingEnd = formatMask.toUpperCase().indexOf( formatToken ) + formatToken.length;

                // correct start & end position if a format mask part could be longer than the real data, e.g. FMYYYY -> 2022, HH12/HH24 is handled below
                if ( formatToken === "FMYYYY" || formatToken === "FMRRRR" ) {
                    findingEnd = findingEnd - 2;
                    correctStartIndex = findingStart;
                    correctFollowFindings = true;
                }

                findings.push( {
                    id: i,
                    name: formatToken,
                    start: findingStart,
                    end: findingEnd
                } );

                formatMaskSearch = formatMaskSearch.replace( formatToken, new Array( formatToken.length + 1 ).join( i ) );
            }
        }

        // correct start & end position of following findings, if e.g. HH24 or HH12 was used
        if ( correctFollowFindings ) {
            _correctFollowFindings( findings, correctStartIndex, - 2 );
        }

        // lookup not yet supported tokens in remaining format mask, if found thow an error
        notSupportedTokens = notSupportedTokenString.split( "|" );

        for ( i = 0; i < notSupportedTokens.length; i++ ) {
            notSupportedToken = notSupportedTokens[i];

            if ( formatMaskSearch.includes( notSupportedToken ) ) {
                throw new Error( "Format not supported: " + notSupportedToken );
            }
        }

        // sort findings by start position
        findings.sort( function( a, b ) {
            return a.start - b.start;
        } );

        // now we are building the final formatted output from our findings
        // first handle special localized format mask parts like "MON", "MONTH", "DY", "DAY"
        for ( i = 0; i < findings.length; i++ ) {
            replaceChar = replaceChars[i] || "~";
            finding = findings[i];
            blankAfterFormat = formatMask.toUpperCase().includes( finding.name + " " );
            datePart = "";

            if ( finding.name === "MONTH" || finding.name === "FMMONTH" ) {
                datePart = _extractMonth( dateString, false );

                if ( datePart ) {
                    dateString = dateString.replace( new RegExp( datePart, "ig" ), replaceChar.repeat( finding.name.length ) + ( blankAfterFormat ? " " : "" ) ); // replace with fixed length 5 or 7 for MONTH
                    _setDatePart( localDate, datePart, finding.name );
                    findings.splice( i, 1 ); // remove object from findings array to not process again
                    i = i - 1;
                }
            }
            if ( finding.name === "MON" || finding.name === "FMMON" ) {
                datePart = _extractMonth( dateString, true );

                if ( datePart ) {
                    dateString = dateString.replace( new RegExp( datePart, "ig" ), replaceChar.repeat( finding.name.length ) + ( blankAfterFormat ? " " : "" ) ); // replace with fixed length 3 or 5 for MON
                    _setDatePart( localDate, datePart, finding.name );
                    findings.splice( i, 1 ); // remove object from findings array to not process again
                    i = i - 1;
                }
            }
            if ( finding.name === "MM" || finding.name === "DD" || finding.name === "FMMM" || finding.name === "FMDD" ) {
                if ( finding.name.length === 4 ) {
                    finding.end = finding.end - 2;
                }
                datePart = dateString.substring( finding.start, finding.end );

                if ( datePart ) {
                    // it could happen that FMMONTH or some other FMxxx is set before DD, and Oracle seems to apply this FM also to DD, so 02 becomes just 2
                    // So we check if the value we have is numeric, if not find only the numeric value
                    if ( !/^\d+$/.test( datePart ) ) {
                        datePart = _extractFMMM_FMDD_FMHH( dateString, finding.start, finding.end );
                        if ( datePart ) {
                            _setDatePart( localDate, datePart, finding.name );
                        }
                    // This is normal handling where we really get 02 for example
                    } else {
                        _setDatePart( localDate, datePart, finding.name );
                    }
                    finding.end = finding.name.length === 4 ? finding.end - ( finding.name.length - datePart.length ) + 2 : finding.end - ( finding.name.length - datePart.length );
                    _correctFollowFindings( findings, finding.start, - ( finding.name.length - datePart.length ) );
                    findings.splice( i, 1 ); // remove object from findings array to not process again
                    i = i - 1;
                }
            }
            if ( finding.name === "DAY" || finding.name === "FMDAY" ) {
                datePart = _extractDay( dateString, false );

                if ( datePart ) {
                    dateString = dateString.replace( new RegExp( datePart, "ig" ), replaceChar.repeat( finding.name.length ) + ( blankAfterFormat ? " " : "" ) ); // replace with fixed length 3 or 5 for DAY
                    // not calling _setDatePart() because DAY is not specific enough, e.g. "Friday" doesn't map to a exact day
                }
                findings.splice( i, 1 ); // always remove object from findings array to not process again
                i = i - 1;
            }
            if ( finding.name === "DY" || finding.name === "FMDY" ) {
                datePart = _extractDay( dateString, true );

                if ( datePart ) {
                    dateString = dateString.replace( new RegExp( datePart, "ig" ), replaceChar.repeat( finding.name.length ) + ( blankAfterFormat ? " " : "" ) ); // replace with fixed length 2 or 4 for DY
                    // not calling _setDatePart() because DY is not specific enough, e.g. "Fri" doesn't map to a exact day
                }
                findings.splice( i, 1 ); // always remove object from findings array to not process again
                i = i - 1;
            }
            if ( finding.name === "HH" || finding.name === "HH12" || finding.name === "HH24" ) {
                if ( finding.name.length === 4 ) {
                    finding.end = finding.end - 2;
                }
                datePart = dateString.substring( finding.start, finding.end );

                if ( datePart ) {
                    // it could happen that FMMONTH or some other FMxxx is set before HH, and Oracle seems to apply this FM also to HH, so 02 becomes just 2
                    // So we check if the value we have is numeric, if not find only the numeric value
                    if ( !/^\d+$/.test( datePart ) ) {
                        datePart = _extractFMMM_FMDD_FMHH( dateString, finding.start, finding.end );
                        if ( datePart ) {
                            _setDatePart( localDate, datePart, finding.name );
                        }
                    // This is normal handling where we really get 02 for example
                    } else {
                        _setDatePart( localDate, datePart, finding.name );
                    }
                    finding.end = finding.name.length === 4 ? finding.end - ( finding.name.length - datePart.length ) + 2 : finding.end - ( finding.name.length - datePart.length );
                    _correctFollowFindings( findings, finding.start, - ( finding.name.length - datePart.length ) );
                    findings.splice( i, 1 ); // remove object from findings array to not process again
                    i = i - 1;
                }
            }
            if ( finding.name === "AM" || finding.name === "PM" ) {
                datePart = _extractAMPM( dateString );

                if ( datePart ) {
                    dateString = dateString.replace( new RegExp( datePart, "ig" ), replaceChar.repeat( finding.name.length ) + ( blankAfterFormat ? " " : "" ) ); // replace with fixed length 2 of AM/PM
                    _setDatePart( localDate, datePart, finding.name );
                    findings.splice( i, 1 ); // remove object from findings array to not process again
                    i = i - 1;
                }
            }
            // remove double spaces after specific replaced part, which could have been there since blankAfterFormat was added
            // added "replaceChar" to make it more unique within looping
            if ( datePart && blankAfterFormat ) {
                dateString = dateString.replace( new RegExp( _escapeRegExp( replaceChar ) + "  ", "ig" ), replaceChar + " " );
            }
        }

        // sort findings by start position
        findings.sort( function( a, b ) {
            return a.start - b.start;
        } );

        // handling for all other format mask parts
        for ( i = 0; i < findings.length; i++ ) {
            finding = findings[i];

            dateStringPart = dateString.substring( finding.start, finding.end );

            // remove all non alphanumeric chars (which are handled above, like MON, FMMON, DAY etc) & correct the positions of following findings
            dateStringPart = dateStringPart.replace( /[^a-zA-Z0-9]/ig, function ( match ) {
                _correctFollowFindings( findings, finding.start, - match.length );
                return "";
            } );

            _setDatePart( localDate, dateStringPart, finding.name );
        }

        // if a not valid date object is generated, throw an error
        if ( !apex.date.isValid( localDate ) ) {
            throw new Error( "Date Parsing Error" );
        }

        return localDate;
    }
});