BEGIN

    SELECT ds_condutas
    INTO :p310_condutas
    FROM tb_cache_epol c
    WHERE 1 = 1
        AND regexp_replace(regexp_replace(:p310_nr_caso, '[^0-9]', ''), '^([0-9]{4})0*', '\1')
        = regexp_replace(regexp_replace(c.ds_caso_epol, '[^0-9]', ''), '^([0-9]{4})0*', '\1')
    ORDER BY c.dt_cache DESC NULLS LAST;

EXCEPTION
    WHEN no_data_found THEN
        :P310_CONDUTAS := NULL;

END;
