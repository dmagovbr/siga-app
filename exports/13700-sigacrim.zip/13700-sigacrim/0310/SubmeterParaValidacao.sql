DECLARE
    temp NUMBER;
BEGIN

    -- DEPRECATED 20251224
    -- verifica flags
    SELECT GO_DATA_SAVED(:APP_ID, :P310_ID_OPERACAO) INTO TEMP FROM DUAL;
    IF (TEMP = 0) THEN RAISE NO_DATA_FOUND; END IF;

    -- Altera etapa para aguardando validação
    UPDATE tb_operacao SET id_etapa_operacao_fk = 300 WHERE id_operacao = :P310_ID_OPERACAO;

    -- insere tramite
    INSERT INTO TB_OPERACAO_TRAMITE(ID_OPERACAO_FK, ID_ETAPA_OPERACAO_FK, ST_USERNAME, DT_QUANDO, OB_TEXTO) VALUES (:P310_ID_OPERACAO, 300, :G_USERNAME, SYSDATE, '[Submetida para validação]');

EXCEPTION
    WHEN NO_DATA_FOUND THEN

        -- Levanta exceção com mensagem customizada
        raise_application_error(-20303, 'Não foi possível enviar para validação. Por favor, revise e salve novamente as abas ANDAMENTO, PRÉ-DEFLAGRAÇÃO, DEFLAGRAÇÃO E INFORMAÇÕES SETORIAIS.', FALSE);
END;