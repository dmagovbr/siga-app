// APEX - MÁSCARA EM TEMPO REAL (KEYUP)
// Evento: Key Release
// Item: P1_NR_INQUERITO_IPL

var valor = $v('P310_NR_CASO');

// limpa tudo que não é número
valor = valor.replace(/\D/g, '');

// limita tamanho (4 + 7)
valor = valor.substring(0, 11);

// separa
var ano = valor.substring(0, 4);
var seq = valor.substring(4);

// aplica máscara progressiva
var resultado = ano;

if (seq.length > 0) {
    resultado += '.' + seq;
}

$s('P310_NR_CASO', resultado);