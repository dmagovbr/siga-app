BEGIN

    -- se nao e proprietario nem pode atualizar como gestor nacional, ocorre erro
    IF GO_EH_PROPRIETARIO(:P310_ID_OPERACAO, :P310_NR_CASO, :G_MATRICULA, :G_TOKEN) = 0
        AND GO_PODE_ATUALIZAR_DRPJ(:P310_ID_OPERACAO, :G_USERNAME, :G_MATRICULA) = 0
    THEN
        RAISE VALUE_ERROR;
    END IF;

END;