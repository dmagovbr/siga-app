DECLARE

    -- Variáveis para operação anterior
    shuttle wwv_flow_global.VC_ARR2;
    last_id number;
BEGIN

    -- Gerenciamento de operação anterior
    MERGE INTO tb_resposta_etapa tgt
    USING (SELECT :P310_ID_OPERACAO AS id_op, 'operacao_anterior' AS cd_campo FROM dual) src
    ON (tgt.id_operacao_fk = src.id_op AND tgt.cd_campo_etapa_fk = src.cd_campo)
    WHEN MATCHED THEN
        UPDATE SET st_resposta_etapa = :ITEM_OPERACAO_ANTERIOR
    WHEN NOT MATCHED THEN
        INSERT (id_operacao_fk, cd_campo_etapa_fk, st_resposta_etapa) VALUES (:P310_ID_OPERACAO, 'operacao_anterior', :ITEM_OPERACAO_ANTERIOR);
    --
    SELECT id_resposta_etapa INTO last_id FROM tb_resposta_etapa WHERE id_operacao_fk = :P310_ID_OPERACAO AND cd_campo_etapa_fk = 'operacao_anterior';
    DELETE FROM tb_resposta_etapa_operacao_relacionada WHERE id_resposta_etapa_fk = last_id;
    IF (:ITEM_OPERACAO_ANTERIOR = 1) THEN
        shuttle := apex_util.string_to_table(:ITEM_OPERACAO_ANTERIOR_OPERACOES);
        FOR i IN 1..shuttle.count LOOP
            INSERT INTO tb_resposta_etapa_operacao_relacionada (id_resposta_etapa_fk, id_operacao_relacionada_fk) VALUES (last_id, shuttle(i));
        END LOOP;
    END IF;
EXCEPTION

    WHEN OTHERS THEN
        raise_application_error(-20002, 'Não foi possível salvar: ' || sqlerrm);
END;