DECLARE

BEGIN

    -- operacao_anterior
    BEGIN
        SELECT ST_RESPOSTA_ETAPA INTO :ITEM_OPERACAO_ANTERIOR FROM TB_RESPOSTA_ETAPA WHERE ID_OPERACAO_FK = :P310_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'operacao_anterior';
        SELECT listagg(ID_OPERACAO_RELACIONADA_FK, ':')
        INTO :ITEM_OPERACAO_ANTERIOR_OPERACOES
        FROM TB_RESPOSTA_ETAPA_OPERACAO_RELACIONADA tb LEFT JOIN TB_RESPOSTA_ETAPA tr ON tr.ID_RESPOSTA_ETAPA = tb.ID_RESPOSTA_ETAPA_FK
        WHERE ID_OPERACAO_FK = :P310_ID_OPERACAO AND CD_CAMPO_ETAPA_FK = 'operacao_anterior';
    EXCEPTION
        WHEN no_data_found THEN NULL;
    END;


EXCEPTION
    WHEN OTHERS THEN
        raise_application_error(-20303, 'Não foi possível recuperar os dados no momento (Cadastro). Caso o problema persista, por favor, entre em contato com o suporte.', FALSE);
END;