DECLARE

r_json string(32767);

BEGIN

    r_json := API_EPOL(:P310_NR_CASO, :G_TOKEN);
    apex_json.parse(r_json);

    :P310_HEADER_CASO              := apex_json.get_varchar2('caso'); --items[1].nr_inquerito
    :P310_HEADER_INSTAURACAO       := apex_json.get_varchar2('dataInstauracao'); --items[1].dt_instauracao
    :P310_HEADER_AREA_ATRIBUICAO   := apex_json.get_varchar2('areaAtribuicao.nome'); --items[1].ds_area_atribuicao

exception

        when no_data_found then
            :P310_HEADER_CASO            := '[no data]';
            :P310_HEADER_INSTAURACAO     := '[no data]';
            :P310_HEADER_AREA_ATRIBUICAO := '[no data]';

        when others then
            :P310_HEADER_CASO            := '[api error]';
            :P310_HEADER_INSTAURACAO     := '[api error]';
            :P310_HEADER_AREA_ATRIBUICAO := '[api error]';

    END;