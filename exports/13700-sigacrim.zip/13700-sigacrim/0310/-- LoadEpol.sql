DECLARE

    temp number;
    r_json string(32767);
    --
    nomePresidente varchar2(255);
    nomeEscrivao varchar2(255);

BEGIN
    -- Componente descontinuado em 22/12/2024 ana.acat.
    --
    r_json := API_EPOL(:P310_NR_CASO, :G_TOKEN);
    --r_json := API_EPOL('2024.1417', :G_TOKEN);
    if r_json is not JSON then
        RAISE_APPLICATION_ERROR(-20111,  r_json);
    end if;

     -- retornou vazio, nao achou dados epol
    if r_json is null or r_json = '' then RAISE NO_DATA_FOUND; end if;

    --
    apex_json.parse(r_json);

    -- 20240820 maia.dam favor nao alterar sem entender o impacto em todo o sistema;
    -- Alterar valores aqui sem alterar outros locais ira gerar inconsistencia;
    -- Este codigo é replicado no load da pagina (Processes: LoadEpol) e no botão Buscar Caso ao cadastrar operação (BuscarButton).
    :P310_ID_INQUERITO_     := apex_json.get_varchar2('id');
    :P310_NR_INQUERITO      := apex_json.get_varchar2('caso');
    :P310_DT_INSTAURACAO    := apex_json.get_varchar2('dataInstauracao');
    :P310_TIPO_PROCEDIMENTO := apex_json.get_varchar2('tipoCaso');
    :P310_AREA_ATRIBUICAO   := apex_json.get_varchar2('areaAtribuicao.nome');
    :P310_UNIDADE           := apex_json.get_varchar2('unidade.sigla');
    :P310_UF                := apex_json.get_varchar2('unidade.uf');

    --
    :P310_DELEGADO_MATRICULA := apex_json.get_varchar2('delegado.matricula');
    :P310_ESCRIVAO_MATRICULA := apex_json.get_varchar2('escrivao.matricula');

    --
    :P310_HEADER_CASO              := apex_json.get_varchar2('caso'); --items[1].nr_inquerito
    :P310_HEADER_INSTAURACAO       := apex_json.get_varchar2('dataInstauracao'); --items[1].dt_instauracao
    :P310_HEADER_AREA_ATRIBUICAO   := apex_json.get_varchar2('areaAtribuicao.nome'); --items[1].ds_area_atribuicao

    -- nova versão fn_cache_epol_v3 em uso.
    :P310_CACHE_ERROR              := fn_cache_epol_v2(:P310_ID_OPERACAO, :G_TOKEN);


    -- 20240816 ana.acat #2085 apenas tipos 'IPL', 'RE'
    IF UPPER(:P310_TIPO_PROCEDIMENTO) NOT IN ('IPL', 'RE') THEN
        RAISE_APPLICATION_ERROR(-20001, 'Tipo de procedimento inválido: ' || :P310_TIPO_PROCEDIMENTO);
    END IF;

    --INSERT INTO debug_log (log_message)
    --    VALUES (
    --        'LOADEPOL - P310_ID_INQUERITO_: ' || NVL(:P310_ID_INQUERITO_, 'NULL')
    --        || ', P310_NR_INQUERITO: ' || NVL(:P310_NR_INQUERITO, 'NULL')
    --        || ', P310_DT_INSTAURACAO: ' || NVL(:P310_DT_INSTAURACAO, 'NULL')
    --        || ', P310_TIPO_PROCEDIMENTO: ' || NVL(:P310_TIPO_PROCEDIMENTO, 'NULL')
    --        || ', P310_AREA_ATRIBUICAO: ' || NVL(:P310_AREA_ATRIBUICAO, 'NULL')
    --        || ', P310_UNIDADE: ' || NVL(:P310_UNIDADE, 'NULL')
    --        || ', P310_UF: ' || NVL(:P310_UF, 'NULL')
    --        || ', P310_DELEGADO_MATRICULA: ' || NVL(:P310_DELEGADO_MATRICULA, 'NULL')
    --        || ', P310_ESCRIVAO_MATRICULA: ' || NVL(:P310_ESCRIVAO_MATRICULA, 'NULL')
    --        || ', P310_HEADER_CASO: ' || NVL(:P310_HEADER_CASO, 'NULL')
    --        || ', P310_HEADER_INSTAURACAO: ' || NVL(:P310_HEADER_INSTAURACAO, 'NULL')
    --        || ', P310_HEADER_AREA_ATRIBUICAO: ' || NVL(:P310_HEADER_AREA_ATRIBUICAO, 'NULL')
    --    );
    --    COMMIT;

    -- atualiza cache - não está sendo utilizada na versão 18/12/2024 - A tabela cache está sendo atualizada pelo processo "Salvar_Tb_Cache"
    :P310_CACHE_ERROR := fn_cache_epol_v2(:P310_ID_OPERACAO, :G_TOKEN);

     -- usa a API para recuperar os nomes
    nomePresidente := RETORNAR_NOME_CORPORATIVO(:APP_CORPORATIVO_URL, :P310_DELEGADO_MATRICULA);
    nomeEscrivao := RETORNAR_NOME_CORPORATIVO(:APP_CORPORATIVO_URL, :P310_ESCRIVAO_MATRICULA);

    -- trata null
    nomePresidente := nvl(nomePresidente, '[API: nome não retornado]');
    nomeEscrivao := nvl(nomeEscrivao, '[API: nome não retornado]');

    -- passa nomes para itens do front
    :P310_DELEGADO := nomePresidente;
    :P310_ESCRIVAO := nomeEscrivao;
    :P310_PRESIDENTE_EQUIPE := nomePresidente;
    :P310_ESCRIVAO_EQUIPE := nomeEscrivao;

    exception

        when no_data_found then
            :P310_ID_INQUERITO_ := null;
            :P310_NR_INQUERITO := null;
            :P310_DT_INSTAURACAO := null;
            :P310_TIPO_PROCEDIMENTO := null;
            :P310_AREA_ATRIBUICAO := null;
            :P310_UNIDADE := null;
            :P310_UF := null;
            --
            :P310_DELEGADO := null;
            :P310_ESCRIVAO := null;
            :P310_PRESIDENTE_EQUIPE := null;
            :P310_ESCRIVAO_EQUIPE := null;
            :P310_DELEGADO_MATRICULA := null;
            :P310_ESCRIVAO_MATRICULA := null;
            :P310_CACHE_ERROR := null;

        WHEN OTHERS THEN

            :P310_API_ERROR := 'ATENÇÃO: ' || SQLERRM;

            :P310_ID_INQUERITO_ := null;
            :P310_NR_INQUERITO := null;
            :P310_DT_INSTAURACAO := null;
            :P310_TIPO_PROCEDIMENTO := null;
            :P310_AREA_ATRIBUICAO := null;
            :P310_UNIDADE := null;
            :P310_UF := null;
            --
            :P310_DELEGADO := null;
            :P310_ESCRIVAO := null;
            :P310_PRESIDENTE_EQUIPE := null;
            :P310_ESCRIVAO_EQUIPE := null;
            :P310_DELEGADO_MATRICULA := null;
            :P310_ESCRIVAO_MATRICULA := null;
            :P310_CACHE_ERROR := null;

END;