// exibe alerta em caso de erro na API
alert($v('P310_API_ERROR'));