DECLARE
  v_tipos tb_cache_epol.ds_condutas%TYPE;
BEGIN
  SELECT ds_condutas
  INTO   v_tipos
  FROM (
    SELECT c.ds_condutas
    FROM tb_cache_epol c
    WHERE regexp_replace(regexp_replace(:P310_NR_CASO, '[^0-9]', ''), '^([0-9]{4})0*', '\1')
          = regexp_replace(regexp_replace(c.ds_caso_epol, '[^0-9]', ''), '^([0-9]{4})0*', '\1')
    ORDER BY c.dt_cache DESC NULLS LAST
  )
  WHERE ROWNUM = 1;

  :P310_TIPOS_PENAIS := v_tipos;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    :P310_TIPOS_PENAIS := NULL;
END;
