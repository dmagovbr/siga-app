SELECT
    e.st_uf        AS uf,
    e.st_municipio AS municipio,
    COUNT(*)       AS total
FROM tb_dados_gpol_equipe e
WHERE e.id_deflagracao_gpol_fk = :P333_ID_DEFLAGRACAO_GPOL
GROUP BY
    e.st_uf,
    e.st_municipio
ORDER BY
    e.st_uf,
    e.st_municipio;
