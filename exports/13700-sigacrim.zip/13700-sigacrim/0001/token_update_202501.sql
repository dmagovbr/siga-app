-- atualiza ultimo acesso e token do usuario se a data atual passou 30 minutos da dt-update
UPDATE TB_USUARIO
SET DT_TOKEN_UPDATE = SYSDATE
    , DS_TOKEN = :G_TOKEN
WHERE 1 = 1 AND UPPER(ST_USERNAME) = UPPER(:G_USERNAME)
;