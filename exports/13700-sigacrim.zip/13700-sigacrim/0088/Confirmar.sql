/*
DECLARE
    temp NUMBER;
BEGIN

    temp := GO_SUBMETER_PARA_VALIDACAO(:P88_ID_OPERACAO, :G_USERNAME, :P88_OBSERVACAO);

END;
*/

DECLARE
    temp int := NULL;
BEGIN

    IF :P88_ST_VISIBILIDADE_PRIVADA = 1 THEN
        UPDATE tb_operacao
        SET id_visibilidade_fk = 1
        WHERE id_operacao = :P88_ID_OPERACAO;

    ELSE
        UPDATE tb_operacao
        SET id_visibilidade_fk = 2
        WHERE id_operacao = :P88_ID_OPERACAO;

    END IF;

    temp := go_submeter_para_validacao(:P88_ID_OPERACAO, :G_USERNAME, :P88_OBSERVACAO, :P88_ST_VISIBILIDADE_PRIVADA);

END;