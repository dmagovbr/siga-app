CREATE OR REPLACE FUNCTION upsert_resposta_etapa (
    p_id_operacao    IN number,
    p_cd_campo       IN varchar2,
    p_st_resposta    IN number     DEFAULT NULL,
    p_qt_resposta    IN number     DEFAULT NULL,
    p_ob_resposta    IN varchar2   DEFAULT NULL,
    p_ds_resposta    IN varchar2   DEFAULT NULL,
    p_vl_resposta    IN number     DEFAULT NULL,
    p_ds_meta_info   IN varchar2   DEFAULT NULL   -- ← adicionado (opcional)
)
    RETURN number
    IS
    v_id number;
BEGIN

    MERGE INTO tb_resposta_etapa r
    USING (SELECT p_id_operacao id_operacao, p_cd_campo cd_campo FROM dual) src
    ON (r.id_operacao_fk = src.id_operacao AND r.cd_campo_etapa_fk = src.cd_campo)
    WHEN MATCHED THEN
        UPDATE
        SET r.st_resposta_etapa = p_st_resposta
          , r.qt_resposta_etapa = p_qt_resposta
          , r.ob_resposta_etapa = p_ob_resposta
          , r.ds_resposta_etapa = p_ds_resposta
          , r.vl_resposta_etapa = p_vl_resposta
          , r.ds_meta_info      = p_ds_meta_info     -- ← atualizado
    WHEN NOT MATCHED THEN
        INSERT (
            id_operacao_fk,
            cd_campo_etapa_fk,
            st_resposta_etapa,
            qt_resposta_etapa,
            ob_resposta_etapa,
            ds_resposta_etapa,
            vl_resposta_etapa,
            ds_meta_info                               -- ← adicionado
        )
        VALUES (
            p_id_operacao,
            p_cd_campo,
            p_st_resposta,
            p_qt_resposta,
            p_ob_resposta,
            p_ds_resposta,
            p_vl_resposta,
            p_ds_meta_info                             -- ← adicionado
        );

    --
    SELECT id_resposta_etapa
      INTO v_id
      FROM tb_resposta_etapa
     WHERE id_operacao_fk = p_id_operacao
       AND cd_campo_etapa_fk = p_cd_campo;

    RETURN v_id;

END;
/