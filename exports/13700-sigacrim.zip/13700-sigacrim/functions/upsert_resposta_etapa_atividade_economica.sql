CREATE OR REPLACE PROCEDURE upsert_resposta_etapa_atividade_economica (
    p_id_resposta_etapa IN number
, p_flag IN number
, p_lista IN varchar2
) IS

    v_shuttle wwv_flow_global.VC_ARR2;

BEGIN

    --
    DELETE FROM tb_resposta_etapa_atividade_economica WHERE id_resposta_etapa_fk = p_id_resposta_etapa;

    --
    IF p_flag = 1 AND p_lista IS NOT NULL THEN
        v_shuttle := apex_util.string_to_table(p_lista);

        FOR i IN 1 .. v_shuttle.count LOOP
            INSERT INTO tb_resposta_etapa_atividade_economica (id_resposta_etapa_fk, id_atividade_economica_fk)
            VALUES (p_id_resposta_etapa, v_shuttle(i));
        END LOOP;

    END IF;

END;
/
