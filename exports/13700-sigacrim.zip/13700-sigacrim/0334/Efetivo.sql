select CD_TIPO_EFETIVO,
       QT_EFETIVOS
from tb_dados_gpol_equipe_efetivo
where 1 = 1
  and ID_EQUIPE_GPOL_FK = 1
;