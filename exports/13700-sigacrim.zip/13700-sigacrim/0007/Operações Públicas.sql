(

    ID_VISIBILIDADE_FK = 2 -- operações públicas

)

-- 20240913-2359 dma
and (lower(NO_OPERACAO) not like '%teste%')
    and (lower(NO_OPERACAO) not like '%testar%')
        and (lower(NO_OPERACAO) not like '%testando%')
            and (ID_ETAPA_OPERACAO_FK <= 9000)