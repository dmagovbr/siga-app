(
    -- proprietario
    (GO_EH_PROPRIETARIO(ID_OPERACAO, NULL, :G_MATRICULA, :G_TOKEN) = 1)

        or -- membro
        (GO_EH_MEMBRO(ID_OPERACAO, :G_MATRICULA) = 1)
)

-- 20240913-2359 dma
and (lower(NO_OPERACAO) not like '%teste%')
    and (lower(NO_OPERACAO) not like '%testar%')
        and (lower(NO_OPERACAO) not like '%testando%')
            and (ID_ETAPA_OPERACAO_FK <= 9000)